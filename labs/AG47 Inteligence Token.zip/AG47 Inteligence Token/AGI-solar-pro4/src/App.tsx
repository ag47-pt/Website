import { useEffect, useRef, useState } from "react";

// ─────────────────────────────────────────────
// Types & Data
// ─────────────────────────────────────────────

interface FAQItem {
  q: string;
  a: string;
}

const faqs: FAQItem[] = [
  {
    q: "O que é o AG Intelligence Token (AGI)?",
    a:
      "O AGI é um token utilitário que funciona como combustível dentro do ecossistema Organismo Cognitivo AG47 — uma rede descentralizada de agentes de IA que analisam dados, geram previsões e produzem inteligência coletiva. Diferente de tokens especulativos, o AGI tem valor intrínseco pelo seu uso real no sistema.",
  },
  {
    q: "Como o Organismo Cognitivo AG47 é diferente de uma IA centralizada?",
    a:
      "O AG47 é composto por múltiplos agentes de IA especializados que operam de forma colaborativa e transparente em uma rede descentralizada. Nenhuma entidade única controla o sistema, os dados são processados de forma distribuída e os resultados são auditáveis. Isso reduz pontos de falha únicos, viés centralizado e dependência de infraestrutura de um único fornecedor.",
  },
  {
    q: "Qual a utilidade real do token AGI?",
    a:
      "O AGI é usado para: (1) acessar agentes premium e análises avançadas; (2) comprar previsões geradas pela rede; (3) pagar processamento de dados; (4) participar da governança do protocolo; e (5) receber recompensas por contribuir com dados, modelos ou validação de resultados. Sem utilidade real, o token não tem raison d'être no ecossistema.",
  },
  {
    q: "Como funciona o Proof of Intelligence?",
    a:
      "O Proof of Intelligence é um mecanismo que recompensa agentes e participantes com base na qualidade e utilidade das contribuições feitas à rede — e não por simples posse de tokens. Agentes que geram análises precisas, validam resultados corretamente ou fornecem dados valiosos recebem AGI como recompensa, criando um ciclo virtuoso de qualidade e utilidade.",
  },
  {
    q: "O projeto está lançado ou é apenas uma ideia?",
    a:
      "O Organismo Cognitivo AG47 está em desenvolvimento ativo. A Fase 1 (MVP do organismo cognitivo) está em construção, com agentes iniciais operando em ambiente testnet. Integrar dados reais, automação e expansão multi-chain são os próximos passos. A página reflete o estado atual do projeto e sua roadmap pública.",
  },
  {
    q: "Como a queima de tokens funciona na prática?",
    a:
      "Uma parte das taxas geradas pelo uso da rede (análises, previsões, processamento) é convertida e queimada permanentemente, reduzindo o supply circulante ao longo do tempo. Isso cria deflação orgânica ligada à demanda real pelo uso do sistema — e não por mecanismos artificiais ou predatórios.",
  },
  {
    q: "Posso participar sem ser desenvolvedor ou especialista em IA?",
    a:
      "Sim. O ecossistema foi desenhado para diferentes perfis: usuários finais que consomem análises e previsões, validadores que auditam resultados, provedores de dados e desenvolvedores que criam novos agentes. Cada um contribui e é compensado de forma apropriada ao seu papel.",
  },
];

const roadmap = [
  {
    phase: "Fase 1",
    title: "MVP do Organismo Cognitivo",
    period: "Q1–Q2 2026",
    items: [
      "Deploy dos primeiros agentes especializados",
      "Protocolo de comunicação entre agentes",
      "Contratos inteligentes do token AGI",
      "Ambiente de teste (testnet)",
    ],
    done: true,
  },
  {
    phase: "Fase 2",
    title: "Integração com Dados Reais",
    period: "Q3–Q4 2026",
    items: [
      "Conectores para fontes de dados financeiros e de mercado",
      "Pipeline de ingestão e limpeza de dados",
      "Dashboard público de métricas da rede",
      "Lançamento da versão beta para usuários early adopter",
    ],
    done: false,
  },
  {
    phase: "Fase 3",
    title: "Automação e Execução",
    period: "2027",
    items: [
      "Agentes com capacidade de executar ações baseadas em análises",
      "API pública para integração de terceiros",
      "Programa de validação descentralizada",
      "Mecanismos avançados de queima e staking",
    ],
    done: false,
  },
  {
    phase: "Fase 4",
    title: "Expansão Multi-chain",
    period: "2027+",
    items: [
      "Bridging para múltiplas blockchains",
      "Ecossistema de agentes de terceiros",
      "Governança total descentralizada (DAO)",
      "Expansão para setores além de finanças",
    ],
    done: false,
  },
];

const stats = [
  { label: "Análises Processadas", value: 2847391, suffix: "", prefix: "", duration: 2000 },
  { label: "Agentes Ativos", value: 347, suffix: "", prefix: "", duration: 1500 },
  { label: "Preços Gerados (24h)", value: 12843, suffix: "", prefix: "", duration: 1800 },
  { label: "Capacidade de Processamento", value: 99.7, suffix: "%", prefix: "", duration: 1500 },
];

const problemCards = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.776c.112-.017.227-.026.344-.026h15.812c.117 0 .232.009.344.026m-16.5 0a2.25 2.25 0 0 0-1.883 2.542l.857 6a2.25 2.25 0 0 0 2.227 1.932H19.05a2.25 2.25 0 0 0 2.227-1.932l.857-6a2.25 2.25 0 0 0-1.883-2.542m-16.5 0V6A2.25 2.25 0 0 1 6 3.75h3.879a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 0 1.06.44H18A2.25 2.25 0 0 1 20.25 9v.776" />
      </svg>
    ),
    title: "Excesso de Dados, Escassez de Sinais",
    desc: "Geramos mais dados do que qualquer sistema humano consegue processar. A questão não é falta de informação — é incapacidade de extrair intelligência dela em escala.",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.455 2.456L21.75 6l-1.036.259a3.375 3.375 0 0 0-2.455 2.456Z" />
      </svg>
    ),
    title: "IA Centralizada é Black Box",
    desc: "Modelos de IA atuais são controlados por poucas empresas. Dados, pesos, decisões — tudo fechado. Não há transparência, não há auditoria, não há verdadeira confiança no resultado.",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
      </svg>
    ),
    title: "Decisões Sem Base Analítica",
    desc: "Sem acesso a análises estruturadas e imparciais, decisões são tomadas com informação incompleta — em finanças, operações, estratégia. O custo de decisões erradas é alto e silencioso.",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
      </svg>
    ),
    title: "Ferramentas Isoladas, Sem Redes",
    desc: "Cada ferramenta de IA atua em silos. Não há orquestração, não há aprendizado coletivo. A inteligência fica fragmentada em soluções desconectadas que não se beneficiam mutuamente.",
  },
];

const solutionFeatures = [
  {
    title: "Agentes Especializados",
    desc: "Cada agente do AG47 é otimizado para uma classe de problema: análise de séries temporais, NLP, previsão probabilística, detecção de anomalias. Eles não competem — eles colaboram.",
    color: "from-violet-500/20 to-indigo-500/10",
    border: "border-violet-500/20",
    glow: "shadow-violet-500/10",
  },
  {
    title: "Comunicação entre Agentes",
    desc: "Os agentes trocam informação, validam resultados uns dos outros e refinam previsões de forma iterativa. A inteligência coletiva emerge das colaborações, não de um único modelo gigante.",
    color: "from-cyan-500/20 to-blue-500/10",
    border: "border-cyan-500/20",
    glow: "shadow-cyan-500/10",
  },
  {
    title: "Transparência e Audibilidade",
    desc: "Cada análise gerada é rastreável: quais agentes participaram, quais dados foram usados, qual o nível de confiança. A rede é aberta para verificação — sem black boxes.",
    color: "from-emerald-500/20 to-teal-500/10",
    border: "border-emerald-500/20",
    glow: "shadow-emerald-500/10",
  },
  {
    title: "Token como Combustível",
    desc: "O AGI é o meio pelo qual a rede se auto-sustenta: paga processamento, recompensa agentes que contribuem com valor real, financia infraestrutura. A economia é deflacionária por design, ligada ao uso real.",
    color: "from-amber-500/20 to-orange-500/10",
    border: "border-amber-500/20",
    glow: "shadow-amber-500/10",
  },
];

const howItWorksSteps = [
  {
    num: "01",
    title: "Solicitação de Análise",
    desc: "Um usuário ou sistema submete uma consulta à rede: prever movimento de ativo, analisar sentimento de dadosNão estruturados, detectar padrão anômalo. A solicitação é criptografada e roteada para os agentes apropriados.",
  },
  {
    num: "02",
    title: "Processamento por Agentes",
    desc: "Vários agentes especializados processam a solicitação em paralelo — cada um com sua abordagem. Agentes de validação cruzam os resultados e atribuem níveis de confiança. O consenso emerge dos processos colaborativos.",
  },
  {
    num: "03",
    title: "Resultado e Confiança",
    desc: "O resultado é entregue com metadata completo: agents envolvidos, dados usados, intervalo de confiança, histórico de precisão. Transparência total — o usuário sabe o que está recebendo e como foi produzido.",
  },
  {
    num: "04",
    title: "Pagamento em AGI",
    desc: "A taxa da análise é paga em AGI. Parte é distribuída aos agentes que contribuíram, parte é queimada (burn), e parte mantida para sustentar a infraestrutura da rede. Quanto mais a rede é usada, mais tokens são removidos da circulação.",
  },
];

const utilityCards = [
  {
    title: "Acesso a Agentes Premium",
    desc: "Agentes de alta complexidade, com modelos mais sofisticados e maior poder computacional, são acessíveis apenas com stake ou pagamento em AGI.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.455 2.456L21.75 6l-1.036.259a3.375 3.375 0 0 0-2.455 2.456Z" />
      </svg>
    ),
  },
  {
    title: "Execução de Análises Avançadas",
    desc: "Cada análise complexa consome AGI como forma de pago. Quanto mais sofisticada a análise, maior o consumo — e maior o valor gerado para o usuário.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605" />
      </svg>
    ),
  },
  {
    title: "Compra de Previsões",
    desc: "Previsões geradas pela rede podem ser adquiridas diretamente. Cada previsão é assinada criptograficamente com o histórico de performance do agente que a gerou.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 13.5l-.825-.825A2.25 2.25 0 0 1 17.55 10.5H15a2.25 2.25 0 0 1-2.224-1.575A9 9 0 0 0 6.75 10.5c0 4.038 2.462 7.484 6 8.796V17.25a2.25 2.25 0 0 1-2.25 2.25h-6A2.25 2.25 0 0 1 3 17.25v-3.75c0-2.385 1.538-4.477 3.75-5.25L5.625 6.75a2.25 2.25 0 0 1 2.828-1.066A4.5 4.5 0 0 1 12 6.75v.75A2.25 2.25 0 0 1 14.25 9.75h3.75a2.25 2.25 0 0 1 2.132 1.575L19.5 13.5m-3.75 2.25h.008v.008h-.008v-.008Z" />
      </svg>
    ),
  },
  {
    title: "Pagamento por Processamento",
    desc: "Quando agentes exigem recursos computacionais intensivos, o AGI é usado para pagar o processamento distribuído — criando uma demanda orgânica e contínua pelo token.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 9.75 16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0 0 20.25 18V6A2.25 2.25 0 0 0 18 3.75H6A2.25 2.25 0 0 0 3.75 6v12A2.25 2.25 0 0 0 6 20.25Z" />
      </svg>
    ),
  },
  {
    title: "Governança do Protocolo",
    desc: "Detentores de AGI participam de decisões sobre mudanças no protocolo, alocação de fundos, atualizações de agentes e direcionamento do desenvolvimento da rede.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 12h-5.25m0 0a6.01 6.01 0 0 0 .75 2.25m-5.25 0V6m0 18v-3.75m-9-6.75h2.25a2.25 2.25 0 0 0 2.25-2.25V4.875a2.25 2.25 0 0 0-2.25-2.25H6.75A2.25 2.25 0 0 0 4.5 4.875v2.25c0 .593.237 1.15.659 1.591l9.54 9.54a2.25 2.25 0 0 0 3.182 0l6.75-6.75a2.25 2.25 0 0 0 0-3.182Z" />
      </svg>
    ),
  },
  {
    title: "Recompensas por Contribuição",
    desc: "Agentes e validadores que entregam resultados úteis e precisos recebem AGI. O Proof of Intelligence garante que a recompensa seja proporcional à contribuição real — não à posse.",
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z" />
      </svg>
    ),
  },
];

const tokenomicsData = {
  totalSupply: "100.000.000",
  totalSupplyUnit: "AGI",
  initialCirculating: "15%",
  initialCirculatingNote: "em lançamento",
  distribution: [
    { label: "Comunidade & Ecossistema", pct: 35, color: "bg-violet-500" },
    { label: "Desenvolvimento & Pesquisa", pct: 20, color: "bg-cyan-500" },
    { label: "Liquidez Inicial", pct: 15, color: "bg-blue-500" },
    { label: "Early Contributors", pct: 15, color: "bg-indigo-500" },
    { label: "Tesouraria & Governança", pct: 10, color: "bg-emerald-500" },
    { label: "Reserva de Emergência", pct: 5, color: "bg-slate-500" },
  ],
  mechanisms: [
    {
      title: "Queima Automática (Burn)",
      desc: "30% das taxas de análise são convertidas e queimadas permanentemente. A queima é ligada ao volume de uso real — não a horários ou eventos artificiais.",
    },
    {
      title: "Staking para Acesso Premium",
      desc: "Stake de AGI concede acesso a agentes premium, taxas reduzidas eボーナス de recompensa. O stake também funciona como signal de confiança na rede.",
    },
    {
      title: "Uso Obrigatório no Ecossistema",
      desc: "Para usar a rede — seja para solicitar análises, comprar previsões ou executar processamentos — é necessário utilizar AGI. Não há opção de pagamento alternativo dentro do sistema.",
    },
  ],
};

const comparisonData = [
  {
    feature: "Inteligência Coletiva",
    agi: "Sim — múltiplos agentes colaborando",
    others: "Não — ponto único de processamento",
  },
  {
    feature: "Transparência dos Resultados",
    agi: "Total — cada análise é auditável",
    others: "Black box — sem visibilidade interna",
  },
  {
    feature: "Controle Centralizado",
    agi: "Nenhum — governança descentralizada",
    others: "Sim — controlado por empresa única",
  },
  {
    feature: "Utilidade do Token",
    agi: "Uso real no ecossistema, sempre",
    others: "Especulação — sem função clara",
  },
  {
    feature: "Mecanismo de Recompensa",
    agi: "Proof of Intelligence (contribuição real)",
    others: "Posse ou hold — sem trabalho útil",
  },
  {
    feature: "Escalabilidade da Inteligência",
    agi: "Aditiva — mais agentes, mais inteligência",
    others: "Limitada ao modelo central",
  },
];

// ─────────────────────────────────────────────
// Specialized Components
// ─────────────────────────────────────────────

// Network particle visualization (canvas)
function NetworkVisual({
  className = "",
  style,
}: {
  className?: string;
  style?: React.CSSProperties;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nodesRef = useRef<{ x: number; y: number; vx: number; y0: number; phase: number }[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const dpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener("resize", resize);

    const w = canvas.offsetWidth;
    const h = canvas.offsetHeight;
    const cx = w / 2;
    const cy = h / 2;
    const maxR = Math.min(w, h) * 0.38;

    nodesRef.current = Array.from({ length: 70 }, (_, i) => {
      const angle = (i / 70) * Math.PI * 2;
      const r = maxR * (0.4 + Math.random() * 0.6);
      return {
        x: cx + Math.cos(angle) * r * (0.6 + Math.random() * 0.4),
        y: cy + Math.sin(angle) * r * (0.6 + Math.random() * 0.4),
        vx: (Math.random() - 0.5) * 0.35,
        y0: cy + Math.sin(angle) * r,
        phase: Math.random() * Math.PI * 2,
      };
    });

    let last = performance.now();
    let rafId = 0;

    const loop = (now: number) => {
      const dt = Math.min((now - last) / 16, 3);
      last = now;

      ctx.clearRect(0, 0, w, h);

      // Background glow
      const bgGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, maxR * 1.2);
      bgGrad.addColorStop(0, "rgba(124, 58, 237, 0.04)");
      bgGrad.addColorStop(0.5, "rgba(34, 211, 238, 0.02)");
      bgGrad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Update nodes
      nodesRef.current.forEach((n) => {
        n.x += n.vx * dt;
        n.y += Math.sin((now / 2000) + n.phase) * 0.12 * dt;
        if (n.x < cx - maxR) n.vx = Math.abs(n.vx);
        if (n.x > cx + maxR) n.vx = -Math.abs(n.vx);
      });

      // Draw connections
      const threshold = maxR * 0.45;
      nodesRef.current.forEach((a, i) => {
        for (let j = i + 1; j < nodesRef.current.length; j++) {
          const b = nodesRef.current[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < threshold) {
            const alpha = (1 - dist / threshold) * 0.22;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(124, 58, 237, ${alpha})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      });

      // Draw nodes
      nodesRef.current.forEach((n) => {
        const alpha = 0.5 + Math.sin((now / 1200) + n.phase) * 0.3;
        // Glow
        ctx.beginPath();
        ctx.arc(n.x, n.y, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(34, 211, 238, ${alpha * 0.25})`;
        ctx.fill();
        // Core
        ctx.beginPath();
        ctx.arc(n.x, n.y, 1.6, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(167, 139, 250, ${alpha})`;
        ctx.fill();
      });

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{ ...style, display: "block", position: "absolute", inset: 0, width: "100%", height: "100%" }}
      aria-hidden="true"
    />
  );
}

// Animated counter
function AnimatedCounter({
  value,
  suffix = "",
  duration = 2000,
}: {
  value: number;
  suffix?: string;
  duration?: number;
}) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const startTime = performance.now();
          const tick = (now: number) => {
            const progress = Math.min((now - startTime) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setDisplay(Math.floor(eased * value));
            if (progress < 1) requestAnimationFrame(tick);
            else setDisplay(value);
          };
          requestAnimationFrame(tick);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [value, duration]);

  return (
    <span ref={ref}>
      {display.toLocaleString("en-US")}
      {suffix}
    </span>
  );
}

// ─────────────────────────────────────────────
// Reusable UI Components
// ─────────────────────────────────────────────

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);

  const links = [
    { label: "Problema", href: "#problem" },
    { label: "Solução", href: "#solution" },
    { label: "Como Funciona", href: "#how" },
    { label: "Utilidade", href: "#utility" },
    { label: "Tokenomics", href: "#tokenomics" },
    { label: "Roadmap", href: "#roadmap" },
  ];

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 50,
        transition: "background 0.3s, border-color 0.3s",
        background: scrolled ? "rgba(8, 8, 15, 0.88)" : "transparent",
        backdropFilter: scrolled ? "blur(20px) saturate(180%)" : "none",
        borderBottom: scrolled ? "1px solid rgba(124, 58, 237, 0.12)" : "1px solid transparent",
      }}
    >
      <div
        className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4"
        style={{ maxWidth: "1280px" }}
      >
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{
              background: "linear-gradient(135deg, #7c3aed 0%, #22d3ee 100%)",
              boxShadow: "0 0 20px rgba(124, 58, 237, 0.3)",
            }}
          >
            <span className="text-white font-bold text-sm" style={{ letterSpacing: "-0.02em" }}>AG</span>
          </div>
          <span className="text-white font-semibold text-base tracking-tight" style={{ letterSpacing: "-0.02em" }}>
            AGI<span style={{ color: "#22d3ee", fontWeight: 300 }}>47</span>
          </span>
        </a>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm text-slate-400 hover:text-white px-3 py-2 rounded-lg transition-colors duration-200 hover:bg-white/5"
            >
              {l.label}
            </a>
          ))}
        </div>

        {/* Right */}
        <div className="flex items-center gap-3">
          <span className="hidden sm:block text-xs text-slate-500 border border-slate-700/50 px-2.5 py-1 rounded-full">
            Mainnet Beta
          </span>
          <a
            href="#footer"
            className="hidden sm:inline-flex text-sm text-slate-300 hover:text-white px-4 py-2 rounded-lg border border-slate-700/50 hover:border-violet-500/40 transition-all duration-200"
          >
            Contact
          </a>
          <a
            href="#hero"
            className="inline-flex items-center gap-2 text-sm font-medium text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 px-5 py-2 rounded-full transition-all duration-200 shadow-lg shadow-violet-500/20 hover:shadow-violet-500/30"
          >
            Get Started
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="m9 12.75 3 3m0 0 3-3m-3 3v-7.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
            </svg>
          </a>
          <button
            className="md:hidden text-slate-400 hover:text-white p-1"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menu"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              {menuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden px-6 pb-5 pt-2"
          style={{
            background: "rgba(8, 8, 15, 0.97)",
            backdropFilter: "blur(20px)",
            borderBottom: "1px solid rgba(124, 58, 237, 0.12)",
          }}
        >
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="block text-sm text-slate-300 py-2.5 px-3 rounded-lg hover:bg-white/5 hover:text-white transition-colors"
              onClick={() => setMenuOpen(false)}
            >
              {l.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden pt-20"
      style={{ background: "#08080f" }}
    >
      {/* Animated network background */}
      <NetworkVisual />

      {/* Gradient orbs */}
      <div
        className="absolute top-1/4 -left-40 h-[500px] w-[500px] rounded-full blur-[120px] pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(124,58,237,0.18) 0%, transparent 70%)" }}
      />
      <div
        className="absolute bottom-1/4 -right-40 h-[500px] w-[500px] rounded-full blur-[120px] pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(34,211,238,0.12) 0%, transparent 70%)" }}
      />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(124, 58, 237, 0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(124, 58, 237, 0.04) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-6 pb-20 pt-10" style={{ maxWidth: "1280px" }}>
        <div className="flex flex-col items-center text-center">
          {/* Badge */}
          <div className="mb-8 flex items-center gap-2 rounded-full border border-violet-500/20 bg-violet-500/5 px-4 py-1.5 backdrop-blur-sm animate-fade-in">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-violet-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-violet-500" />
            </span>
            <span className="text-xs font-medium text-violet-300 tracking-wide uppercase">
              Organismo Cognitivo AG47 — Em desenvolvimento ativo
            </span>
          </div>

          {/* Headline */}
          <h1
            className="max-w-4xl text-5xl font-bold leading-[1.1] text-white sm:text-6xl lg:text-7xl tracking-tight animate-fade-in"
            style={{ animationDelay: "0.1s", animationFillMode: "backwards" }}
          >
            The Infrastructure Layer for
            <br />
            <span
              className="block mt-2 bg-gradient-to-r from-violet-300 via-violet-100 to-cyan-200 bg-clip-text text-transparent"
              style={{ backgroundSize: "200% auto" }}
            >
              Decentralized Intelligence
            </span>
          </h1>

          {/* Subheadline */}
          <p
            className="mx-auto mt-6 max-w-2xl text-lg text-slate-400 leading-relaxed animate-fade-in"
            style={{ animationDelay: "0.2s", animationFillMode: "backwards" }}
          >
            O Organismo Cognitivo AG47 é uma rede de agentes de IA que trabalham juntos para gerar
            inteligência coletiva — e o token AGI é o combustível que faz esse sistema funcionar.
          </p>

          {/* CTA Buttons */}
          <div
            className="mt-10 flex flex-wrap items-center justify-center gap-4 animate-fade-in"
            style={{ animationDelay: "0.3s", animationFillMode: "backwards" }}
          >
            <a
              href="#how"
              className="inline-flex items-center gap-2 text-base font-medium text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 px-7 py-3.5 rounded-full transition-all duration-200 shadow-lg shadow-violet-500/20 hover:shadow-violet-500/30 hover:-translate-y-0.5"
            >
              Get Started
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="m9 12.75 3 3m0 0 3-3m-3 3v-7.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
              </svg>
            </a>
            <a
              href="#tokenomics"
              className="inline-flex items-center gap-2 text-base font-medium text-slate-300 bg-white/5 hover:bg-white/10 border border-slate-700/50 hover:border-violet-500/30 px-7 py-3.5 rounded-full transition-all duration-200"
            >
              <svg className="w-4 h-4 text-violet-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
              </svg>
              Read Whitepaper
            </a>
          </div>

          {/* Live metrics hint */}
          <div
            className="mt-16 flex items-center gap-8 text-xs text-slate-500 animate-fade-in"
            style={{ animationDelay: "0.4s", animationFillMode: "backwards" }}
          >
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              Rede ativa
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-violet-500" />
              347 agentes ativos
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-500" />
              2.8M+ análises processadas
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
        <div className="flex flex-col items-center gap-2 text-slate-600">
          <span className="text-[10px] tracking-widest uppercase">Scroll</span>
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
          </svg>
        </div>
      </div>
    </section>
  );
}

function ProblemSection() {
  return (
    <section id="problem" className="relative py-28 md:py-36" style={{ background: "#08080f" }}>
      <div className="mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        {/* Section header */}
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-violet-400"
            style={{ borderBottom: "1px solid rgba(124,58,237,0.3)", paddingBottom: 4 }}
          >
            O Problema
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            O mundo está cheio de dados.
            <br />
            <span className="text-slate-400">Mas inteligência é outra história.</span>
          </h2>
          <p className="mt-4 max-w-2xl text-slate-400 leading-relaxed text-base md:text-lg">
            A situação atual da IA e dos dados cria ineficiências sistêmicas que nenhuma ferramenta isolada consegue resolver.
          </p>
        </div>

        {/* Problem cards grid */}
        <div className="grid gap-5 md:grid-cols-2">
          {problemCards.map((card) => (
            <div
              key={card.title}
              className="group relative rounded-2xl border border-slate-800/60 bg-bg-card/50 p-7 transition-all duration-300 hover:border-violet-500/20 hover:bg-bg-card-hover/80 hover:shadow-lg hover:shadow-violet-500/5 reveal"
            >
              {/* Glow on hover */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100 pointer-events-none"
                style={{
                  background: "linear-gradient(135deg, rgba(124,58,237,0.05) 0%, transparent 50%, rgba(34,211,238,0.03) 100%)",
                }}
              />

              <div className="relative z-10 mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/10 text-violet-400 transition-colors group-hover:bg-violet-500/20 group-hover:text-violet-300">
                {card.icon}
              </div>
              <h3 className="relative z-10 text-lg font-semibold text-white mb-2">{card.title}</h3>
              <p className="relative z-10 text-sm text-slate-400 leading-relaxed">{card.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SolutionSection() {
  return (
    <section
      id="solution"
      className="relative py-28 md:py-36 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #08080f 0%, #0a0a18 50%, #08080f 100%)" }}
    >
      {/* Decorative background elements */}
      <div
        className="absolute top-0 right-0 h-[600px] w-[600px] rounded-full blur-[140px] pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(124,58,237,0.12) 0%, transparent 70%)" }}
      />
      <div
        className="absolute bottom-0 left-0 h-[400px] w-[400px] rounded-full blur-[100px] pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(34,211,238,0.08) 0%, transparent 70%)" }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        {/* Section header */}
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-cyan-400"
            style={{ borderBottom: "1px solid rgba(34,211,238,0.3)", paddingBottom: 4 }}
          >
            A Solução
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            O Organismo Cognitivo AG47
          </h2>
          <p className="mt-4 max-w-xl text-slate-400 leading-relaxed text-base md:text-lg">
            Um ecossistema onde agentes de IA especializados colaboram em uma rede descentralizada — gerando
            inteligência coletiva que nenhum agente isolado alcançaria.
          </p>
        </div>

        {/* Central visual: Agent network metaphor */}
        <div className="mb-20 reveal">
          <div
            className="relative overflow-hidden rounded-2xl border border-violet-500/10 bg-bg-card p-8 md:p-12"
            style={{
              boxShadow: "0 0 60px rgba(124,58,237,0.06), inset 0 0 60px rgba(124,58,237,0.03)",
            }}
          >
            {/* Network mini-visual */}
            <div className="flex flex-col items-center">
              {/* Center: AGI core */}
              <div
                className="relative mb-8 flex h-20 w-20 items-center justify-center rounded-full"
                style={{
                  background: "linear-gradient(135deg, rgba(124,58,237,0.2) 0%, rgba(34,211,238,0.1) 100%)",
                  boxShadow: "0 0 40px rgba(124,58,237,0.2), 0 0 80px rgba(34,211,238,0.08)",
                  border: "1px solid rgba(124,58,237,0.3)",
                }}
              >
                <div
                  className="absolute inset-0 rounded-full animate-pulse"
                  style={{ animationDuration: "3s" }}
                />
                <span className="relative text-2xl font-bold text-white" style={{ letterSpacing: "-0.03em" }}>AGI</span>
              </div>

              {/* Connector lines (CSS) */}
              <div className="absolute left-1/2 top-0 h-px w-[300px] -translate-x-1/2 bg-gradient-to-r from-transparent via-violet-500/20 to-transparent" />
              <div className="absolute left-1/2 bottom-0 h-px w-[300px] -translate-x-1/2 bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />
              <div className="absolute top-1/2 left-0 w-px h-[200px] -translate-y-1/2 bg-gradient-to-b from-transparent via-violet-500/15 to-transparent" />
              <div className="absolute top-1/2 right-0 w-px h-[200px] -translate-y-1/2 bg-gradient-to-b from-transparent via-cyan-500/15 to-transparent" />

              {/* Agent nodes around */}
              <div className="grid grid-cols-3 gap-4 md:gap-6 w-full max-w-lg mt-12">
                {solutionFeatures.slice(0, 3).map((f) => (
                  <div
                    key={f.title}
                    className="flex flex-col items-center text-center p-4 rounded-xl border border-slate-800/60 bg-bg-card/60 hover:border-violet-500/20 transition-all group"
                  >
                    <div
                      className="mb-3 flex h-8 w-8 items-center justify-center rounded-lg bg-violet-500/10 text-violet-400 group-hover:bg-violet-500/20 transition-colors"
                      style={{ border: "1px solid rgba(124,58,237,0.15)" }}
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.455 2.456L21.75 6l-1.036.259a3.375 3.375 0 0 0-2.455 2.456Z" />
                      </svg>
                    </div>
                    <span className="text-sm font-medium text-white">{f.title}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Feature cards */}
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {solutionFeatures.map((feature) => (
            <div
              key={feature.title}
              className="relative overflow-hidden rounded-2xl border bg-bg-card p-7 transition-all duration-300 hover:-translate-y-1 reveal stagger-children"
              style={{
                borderColor: "rgba(124,58,237,0.12)",
                boxShadow: "0 4px 24px rgba(0,0,0,0.3)",
              }}
            >
              <div
                className="mb-5 flex h-9 w-9 items-center justify-center rounded-lg"
                style={{
                  background: `linear-gradient(135deg, ${feature.color.match(/#[a-f0-9]{6}/)?.[0] ?? '#7c3aed'}20, ${feature.color.match(/#[a-f0-9]{6}/)?.[0] ?? '#22d3ee'}10)`,
                  color: "#a78bfa",
                }}
              >
                <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.455 2.456L21.75 6l-1.036.259a3.375 3.375 0 0 0-2.455 2.456Z" />
                </svg>
              </div>
              <h3 className="text-base font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection() {
  return (
    <section id="how" className="relative py-28 md:py-36" style={{ background: "#08080f" }}>
      {/* Dot pattern */}
      <div className="absolute inset-0 dot-pattern pointer-events-none opacity-60" />

      <div className="relative z-10 mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-violet-400"
            style={{ borderBottom: "1px solid rgba(124,58,237,0.3)", paddingBottom: 4 }}
          >
            Como Funciona
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            Do pedido à inteligência, em quatro passos
          </h2>
          <p className="mt-4 max-w-xl text-slate-400 leading-relaxed text-base md:text-lg">
            Um fluxo simples e auditável — cada etapa é rastreável na rede.
          </p>
        </div>

        {/* Step flow */}
        <div className="grid gap-6 md:grid-cols-4">
          {howItWorksSteps.map((step, i) => (
            <div key={step.num} className="relative reveal stagger-children">
              {/* Step number */}
              <div
                className="mb-5 flex h-10 w-10 items-center justify-center rounded-xl text-sm font-bold"
                style={{
                  background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(34,211,238,0.08))",
                  color: "#a78bfa",
                  border: "1px solid rgba(124,58,237,0.2)",
                  boxShadow: "0 0 20px rgba(124,58,237,0.08)",
                }}
              >
                {step.num}
              </div>

              {/* Connector line (except last) */}
              {i < howItWorksSteps.length - 1 && (
                <div
                  className="absolute top-5 left-[calc(50%+2rem)] w-[calc(100%-2rem)] h-px"
                  style={{ background: "linear-gradient(90deg, rgba(124,58,237,0.3), rgba(34,211,238,0.1) 80%, transparent)" }}
                />
              )}

              <h3 className="text-base font-semibold text-white mb-2">{step.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>

        {/* Proof of Intelligence callout */}
        <div
          className="mt-20 reveal rounded-2xl border border-cyan-500/10 bg-cyan-500/5 p-8 md:p-10"
          style={{
            boxShadow: "0 0 40px rgba(34,211,238,0.04), inset 0 0 40px rgba(34,211,238,0.02)",
          }}
        >
          <div className="flex flex-col md:flex-row items-start gap-6">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl"
              style={{
                background: "linear-gradient(135deg, rgba(34,211,238,0.15), rgba(124,58,237,0.1))",
                border: "1px solid rgba(34,211,238,0.2)",
              }}
            >
              <svg className="w-6 h-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Proof of Intelligence</h3>
              <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
                Diferente de Proof of Work (força bruta) ou Proof of Stake (posse de token),
                o{" "}
                <span className="text-cyan-300 font-medium">Proof of Intelligence</span>{" "}
                recompensa baseado na{" "}
                <span className="text-cyan-300 font-medium">contribuição útil e verificável</span>{" "}
                para a rede. Agentes que geram análises precisas, validam resultados corretamente
                ou fornecem dados valiosos recebem AGI — criando um ciclo onde a qualidade é
                economicamente recompensada.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function UtilitySection() {
  return (
    <section
      id="utility"
      className="relative py-28 md:py-36 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #08080f 0%, #0a0a18 50%, #08080f 100%)",
      }}
    >
      <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[400px] w-[800px] blurred-full pointer-events-none">
        {/* fallback using div */}
      </div>
      <div
        className="absolute top-[-100px] left-1/2 -translate-x-1/2 h-[500px] w-[800px] rounded-full blur-[120px] pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(124,58,237,0.1) 0%, transparent 70%)" }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-cyan-400"
            style={{ borderBottom: "1px solid rgba(34,211,238,0.3)", paddingBottom: 4 }}
          >
            Utilidade do Token
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            O AGI tem função real no ecossistema
          </h2>
          <p className="mt-4 max-w-xl text-slate-400 leading-relaxed text-base md:text-lg">
            Cada uso do token cria valor e demanda orgânica — não especulação artificially criada.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {utilityCards.map((card) => (
            <div
              key={card.title}
              className="group relative rounded-xl border border-slate-800/60 bg-bg-card/60 p-6 transition-all duration-300 hover:border-violet-500/20 hover:bg-bg-card-hover/80 hover:shadow-lg hover:shadow-violet-500/5 reveal"
            >
              <div
                className="mb-4 flex h-9 w-9 items-center justify-center rounded-lg bg-violet-500/10 text-violet-400 transition-colors group-hover:bg-violet-500/20 group-hover:text-violet-300"
              >
                {card.icon}
              </div>
              <h3 className="text-base font-semibold text-white mb-1.5">{card.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{card.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TokenomicsSection() {
  return (
    <section
      id="tokenomics"
      className="relative py-28 md:py-36"
      style={{ background: "#08080f" }}
    >
      {/* Background decoration */}
      <div
        className="absolute inset-0 blurred-full pointer-events-none opacity-40"
        style={{
          background: "radial-gradient(ellipse at 30% 50%, rgba(124,58,237,0.06) 0%, transparent 60%), radial-gradient(ellipse at 70% 50%, rgba(34,211,238,0.04) 0%, transparent 60%)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-amber-400"
            style={{ borderBottom: "1px solid rgba(251,191,36,0.3)", paddingBottom: 4 }}
          >
            Tokenomics
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            Economia desenhada para utilidade, não especulação
          </h2>
          <p className="mt-4 max-w-xl text-slate-400 leading-relaxed text-base md:text-lg">
            Parâmetros reais, mecanismos transparentes e uma distribuição que prioriza o longo prazo.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left: Supply overview */}
          <div className="lg:col-span-1 reveal">
            <div
              className="rounded-2xl border border-slate-800/60 bg-bg-card p-7 md:p-8"
              style={{ boxShadow: "0 4px 32px rgba(0,0,0,0.2)" }}
            >
              <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-6">
                Visão Geral do Supply
              </h3>

              <div className="mb-8">
                <div className="text-4xl md:text-5xl font-bold text-white tracking-tight">
                  {tokenomicsData.totalSupply}
                  <span className="text-lg font-normal text-slate-500"> {tokenomicsData.totalSupplyUnit}</span>
                </div>
                <p className="mt-2 text-sm text-slate-400">
                  Supply total fixo • {tokenomicsData.initialCirculating} em circulação inicial ({tokenomicsData.initialCirculatingNote})
                </p>
              </div>

              {/* Distribution bars */}
              <div className="space-y-4">
                {tokenomicsData.distribution.map((item) => (
                  <div key={item.label}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm text-slate-300">{item.label}</span>
                      <span className="text-sm font-mono text-slate-400">{item.pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-800/80 overflow-hidden">
                      <div
                        key={item.label}
                        className={`h-full rounded-full ${item.color} transition-all duration-1000`}
                        style={{ width: "0%" }}
                        data-pct={item.pct}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Mechanisms */}
          <div className="lg:col-span-2 reveal">
            <div className="space-y-6">
              <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider">
                Mecanismos Econômicos
              </h3>
              <div className="grid gap-5 md:grid-cols-2">
                {tokenomicsData.mechanisms.map((mech) => (
                  <div
                    key={mech.title}
                    className="rounded-xl border border-slate-800/60 bg-bg-card/60 p-6 transition-all hover:border-violet-500/15 hover:bg-bg-card-hover/80"
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-400"
                        style={{ border: "1px solid rgba(251,191,36,0.15)" }}
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
                        </svg>
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white mb-1.5">{mech.title}</h4>
                        <p className="text-sm text-slate-400 leading-relaxed">{mech.desc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ComparisonSection() {
  return (
    <section
      id="comparison"
      className="relative py-28 md:py-36"
      style={{ background: "linear-gradient(180deg, #08080f 0%, #0a0a18 50%, #08080f 100%)" }}
    >
      <div className="mx-auto max-w-5xl px-6">
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-violet-400"
            style={{ borderBottom: "1px solid rgba(124,58,237,0.3)", paddingBottom: 4 }}
          >
            Diferencial
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            AGI não é outro token. É infraestrutura.
          </h2>
        </div>

        {/* Comparison table */}
        <div
          className="rounded-2xl border border-slate-800/60 bg-bg-card overflow-hidden reveal"
          style={{ boxShadow: "0 4px 40px rgba(0,0,0,0.3)" }}
        >
          {/* Header */}
          <div
            className="grid grid-cols-3 gap-0"
            style={{
              background: "linear-gradient(135deg, rgba(124,58,237,0.08) 0%, rgba(34,211,238,0.04) 100%)",
              borderBottom: "1px solid rgba(124,58,237,0.12)",
            }}
          >
            <div className="px-6 py-5 text-left">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Critério</span>
            </div>
            <div className="px-6 py-5 text-center">
              <span className="text-xs font-medium text-violet-300 uppercase tracking-wider">AG Intelligence Token</span>
            </div>
            <div className="px-6 py-5 text-center">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Alternativas</span>
            </div>
          </div>

          {/* Rows */}
          {comparisonData.map((row, i) => (
            <div
              key={row.feature}
              className={`grid grid-cols-3 gap-0 items-center px-6 py-5 transition-colors border-b border-slate-800/40 last:border-b-0 ${
                i % 2 !== 0 ? "bg-white/[0.012]" : ""
              }`}
            >
              <div className="text-sm text-slate-300 font-medium">{row.feature}</div>
              <div className="text-center">
                <span className="inline-flex items-center gap-1.5 text-sm text-emerald-300">
                  <svg className="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                  </svg>
                  {row.agi}
                </span>
              </div>
              <div className="text-center">
                <span className="inline-flex items-center gap-1.5 text-sm text-slate-500">
                  <svg className="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="m6 18 6-6-6-6" />
                  </svg>
                  {row.others}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Summary CTA */}
        <div
          className="mt-12 reveal rounded-2xl border border-violet-500/10 bg-gradient-to-r from-violet-500/5 to-cyan-500/5 p-8 md:p-10 text-center"
          style={{ boxShadow: "0 0 40px rgba(124,58,237,0.04)" }}
        >
          <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            <span className="text-white font-semibold">AGI</span>{" "}
            <span className="text-slate-400">= infraestrutura + utilidade + economia funcional.</span>
            <br />
            <span className="text-sm text-slate-500 mt-2 block">
              Não é uma moeda especulativa — é o combustível de um sistema de inteligência que já está sendo construído.
            </span>
          </p>
        </div>
      </div>
    </section>
  );
}

function RoadmapSection() {
  return (
    <section
      id="roadmap"
      className="relative py-28 md:py-36 overflow-hidden"
      style={{ background: "#08080f" }}
    >
      <div
        className="absolute inset-0 blurred-full pointer-events-none opacity-30"
        style={{
          background: "radial-gradient(ellipse at 70% 30%, rgba(124,58,237,0.07) 0%, transparent 60%)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-6xl px-6" style={{ maxWidth: "1024px" }}>
        <div className="mb-16 reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-cyan-400"
            style={{ borderBottom: "1px solid rgba(34,211,238,0.3)", paddingBottom: 4 }}
          >
            Roadmap
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            Do MVP à infraestrutura global de IA
          </h2>
          <p className="mt-4 max-w-xl text-slate-400 leading-relaxed text-base md:text-lg">
            Um plano claro, com hitos mensuráveis — não promessas vazias.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div
            className="absolute left-[10%] top-0 h-full w-px"
            style={{ background: "linear-gradient(180deg, rgba(124,58,237,0.4) 0%, rgba(34,211,238,0.15) 50%, transparent 100%)" }}
          />

          <div className="grid gap-8 md:grid-cols-2">
            {roadmap.map((phase, i) => (
              <div
                key={phase.phase}
                className={`relative flex gap-6 pl-12 md:pl-0 reveal stagger-children ${
                  i % 2 === 1 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Dot on timeline */}
                <div
                  className="absolute left-[10%] top-6 z-10 flex h-4 w-4 items-center justify-center rounded-full border"
                  style={{
                    background: phase.done ? "#7c3aed" : "rgba(124,58,237,0.2)",
                    borderColor: phase.done ? "#7c3aed" : "rgba(124,58,237,0.4)",
                    boxShadow: phase.done ? "0 0 12px rgba(124,58,237,0.3)" : "none",
                  }}
                >
                  {phase.done && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                    </svg>
                  )}
                </div>

                {/* Content */}
                <div
                  className={`flex flex-col md:w-1/2 ${
                    i % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"
                  }`}
                >
                  <div
                    className={`mb-3 flex items-center gap-2 ${i % 2 !== 0 ? "md:flex-row-reverse" : ""}`}
                  >
                    <span
                      className={`text-xs font-bold uppercase tracking-wider ${
                        phase.done ? "text-violet-400" : "text-cyan-400"
                      }`}
                    >
                      {phase.phase}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        phase.done
                          ? "border border-violet-500/30 text-violet-300 bg-violet-500/5"
                          : "border border-cyan-500/20 text-cyan-300 bg-cyan-500/5"
                      }`}
                    >
                      {phase.period}
                    </span>
                  </div>

                  <h3
                    className={`text-lg font-semibold text-white mb-3 md:pr-4 ${i % 2 !== 0 ? "md:text-right" : ""}`}
                  >
                    {phase.title}
                  </h3>

                  <ul
                    className={`space-y-2 text-sm text-slate-400 md:pr-4 ${i % 2 !== 0 ? "md:text-right" : ""}`}
                  >
                    {phase.items.map((item) => (
                      <li key={item} className="flex items-start gap-2.5">
                        <span
                          className={`mt-1 shrink-0 w-1 rounded-full ${
                            phase.done ? "bg-violet-500" : "bg-slate-600"
                          }`}
                          style={{ height: 1 }}
                        />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function LiveMetricsSection() {
  useEffect(() => {
    const bars = document.querySelectorAll("[data-meter-bar]");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            const pct = parseFloat(el.getAttribute("data-meter-bar") || "0");
            el.style.width = `${pct}%`;
          }
        });
      },
      { threshold: 0.3 }
    );

    bars.forEach((b) => observer.observe(b));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      className="relative py-20 md:py-28"
      style={{ background: "#0a0a18" }}
    >
      <div className="mx-auto max-w-7xl px-6" style={{ maxWidth: "1280px" }}>
        <div className="mb-12 text-center reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-cyan-400"
            style={{ borderBottom: "1px solid rgba(34,211,238,0.3)", paddingBottom: 4 }}
          >
            Métricas em Tempo Real
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
            A rede já está processando
          </h2>
          <p className="mt-2 text-sm text-slate-500">Simulação de dados — ecossistema em construção ativa</p>
        </div>

        {/* Stats grid */}
        <div className="grid gap-4 md:grid-cols-4 reveal">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-xl border border-slate-800/60 bg-bg-card/60 p-6 text-center transition-all hover:border-violet-500/15 hover:bg-bg-card-hover/80"
            >
              <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-violet-300 to-cyan-300 bg-clip-text text-transparent mb-2">
                <AnimatedCounter value={stat.value} suffix={stat.suffix} duration={stat.duration} />
              </div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Activity bars */}
        <div className="mt-12 rounded-xl border border-slate-800/60 bg-bg-card/40 p-6 md:p-8 reveal">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-sm font-medium text-slate-300">Atividade dos Agentes — Últimas 24h</h3>
            <span className="text-xs text-slate-500">Por tipo de análise</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {[
              { label: "Análise de Mercado", pct: 94, color: "bg-violet-500" },
              { label: "NLP / Sentimento", pct: 78, color: "bg-cyan-500" },
              { label: "Detecção de Anomalias", pct: 63, color: "bg-emerald-500" },
              { label: "Previsão Probabilística", pct: 87, color: "bg-indigo-500" },
            ].map((bar) => (
              <div key={bar.label}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">{bar.label}</span>
                  <span className="text-sm font-mono text-slate-500">{bar.pct}%</span>
                </div>
                <div className="h-2 rounded-full bg-slate-800/80 overflow-hidden">
                  <div
                    data-meter-bar={bar.pct}
                    className={`h-full rounded-full ${bar.color} transition-all duration-1000 ease-out`}
                    style={{ width: "0%" }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQSection() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <section id="faq" className="relative py-28 md:py-36" style={{ background: "#08080f" }}>
      <div className="mx-auto max-w-3xl px-6" style={{ maxWidth: "768px" }}>
        <div className="mb-12 text-center reveal">
          <span
            className="mb-4 inline-block text-xs font-medium tracking-widest uppercase text-violet-400"
            style={{ borderBottom: "1px solid rgba(124,58,237,0.3)", paddingBottom: 4 }}
          >
            FAQ
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            Perguntas frequentes
          </h2>
        </div>

        <div className="space-y-3 reveal">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-xl border transition-all duration-200 overflow-hidden"
              style={{
                borderColor: openIdx === i ? "rgba(124,58,237,0.3)" : "rgba(124,58,237,0.08)",
                background: openIdx === i ? "rgba(124,58,237,0.04)" : "rgba(17,17,34,0.5)",
              }}
            >
              <button
                className="w-full flex items-center justify-between px-6 py-5 text-left cursor-pointer"
                onClick={() => setOpenIdx(openIdx === i ? null : i)}
                aria-expanded={openIdx === i}
              >
                <span className="text-sm font-medium text-white pr-4">{faq.q}</span>
                <svg
                  className={`w-4 h-4 text-violet-400 shrink-0 transition-transform duration-200 ${openIdx === i ? "rotate-180" : ""}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2.5}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                </svg>
              </button>
              {openIdx === i && (
                <div className="overflow-hidden transition-all duration-200">
                  <p className="px-6 pb-5 text-sm text-slate-400 leading-relaxed border-t border-slate-800/40 pt-4">
                    {faq.a}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer id="footer" className="relative border-t border-slate-800/40" style={{ background: "#06060e" }}>
      <div className="mx-auto max-w-7xl px-6 py-16" style={{ maxWidth: "1280px" }}>
        <div className="grid gap-12 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-1">
            <a href="#" className="flex items-center gap-2.5 mb-4">
              <div
                className="flex h-8 w-8 items-center justify-center rounded-lg"
                style={{
                  background: "linear-gradient(135deg, #7c3aed 0%, #22d3ee 100%)",
                  boxShadow: "0 0 20px rgba(124,58,237,0.2)",
                }}
              >
                <span className="text-white font-bold text-sm" style={{ letterSpacing: "-0.02em" }}>AG</span>
              </div>
              <span className="text-white font-semibold text-base">AGI<span style={{ color: "#22d3ee", fontWeight: 300 }}>47</span></span>
            </a>
            <p className="text-sm text-slate-500 leading-relaxed max-w-xs">
              O Organismo Cognitivo AG47 é uma rede descentralizada de agentes de IA colaborativos.
              O token AGI é utilitário, não especulativo.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-4">Protocolo</h4>
            <ul className="space-y-3">
              {["Documentação", "Whitepaper", "Contratos Inteligentes", "API Doc", "Status da Rede"].map((l) => (
                <li key={l}>
                  <a href="#" className="text-sm text-slate-400 hover:text-white transition-colors">{l}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-4">Comunidade</h4>
            <ul className="space-y-3">
              {["Discord", "GitHub", "X (Twitter)", "Telegram", "Forum"].map((l) => (
                <li key={l}>
                  <a href="#" className="text-sm text-slate-400 hover:text-white transition-colors">{l}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-4">Legal</h4>
            <ul className="space-y-3">
              {["Aviso Legal", "Política de Privacidade", "Termos de Uso", "Risk Disclosure"].map((l) => (
                <li key={l}>
                  <a href="#" className="text-sm text-slate-400 hover:text-white transition-colors">{l}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-slate-800/40 pt-8"
          style={{ background: "rgba(124,58,237,0.03)" }}
        >
          <p className="text-xs text-slate-600 text-center">
            &copy; {year} AG Intelligence Token. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-[10px] text-slate-700 tracking-wider uppercase border border-slate-800/40 px-2 py-1 rounded">
              Não é uma oferta financeira
            </span>
            <span className="text-[10px] text-slate-700 tracking-wider uppercase">
              Mainnet Beta
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─────────────────────────────────────────────
// Main App
// ─────────────────────────────────────────────

export default function App() {
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("active");
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" }
    );

    // Observe all .reveal elements
    const reveals = document.querySelectorAll<HTMLElement>(".reveal");
    reveals.forEach((el) => observerRef.current?.observe(el));

    return () => observerRef.current?.disconnect();
  }, []);

  // Animate distribution bars on mount
  useEffect(() => {
    const bars = document.querySelectorAll<HTMLDivElement>("[data-pct]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            const pct = el.getAttribute("data-pct");
            if (pct) {
              setTimeout(() => {
                el.style.width = `${pct}%`;
              }, 200);
            }
          }
        });
      },
      { threshold: 0.3 }
    );

    bars.forEach((b) => observer.observe(b));
    return () => observer.disconnect();
  }, []);

  return (
    <div
      className="min-h-screen"
      style={{
        background: "#08080f",
        color: "#ffffff",
        fontFamily: "'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      <Navbar />
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <HowItWorksSection />
      <UtilitySection />
      <TokenomicsSection />
      <ComparisonSection />
      <RoadmapSection />
      <LiveMetricsSection />
      <FAQSection />
      <Footer />
    </div>
  );
}
