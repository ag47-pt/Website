import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ProblemSection from './components/ProblemSection';
import SolutionSection from './components/SolutionSection';
import HowItWorksSection from './components/HowItWorksSection';
import TokenUtilitySection from './components/TokenUtilitySection';
import TokenomicsSection from './components/TokenomicsSection';
import DifferentiatorSection from './components/DifferentiatorSection';
import RoadmapSection from './components/RoadmapSection';
import MetricsSection from './components/MetricsSection';
import FAQSection from './components/FAQSection';
import CTASection from './components/CTASection';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-ag-darker text-ag-text">
      <Navbar />
      <main>
        <HeroSection />
        <div className="section-divider" />
        <ProblemSection />
        <div className="section-divider" />
        <SolutionSection />
        <div className="section-divider" />
        <HowItWorksSection />
        <div className="section-divider" />
        <TokenUtilitySection />
        <div className="section-divider" />
        <TokenomicsSection />
        <div className="section-divider" />
        <DifferentiatorSection />
        <div className="section-divider" />
        <RoadmapSection />
        <div className="section-divider" />
        <MetricsSection />
        <div className="section-divider" />
        <FAQSection />
        <div className="section-divider" />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
