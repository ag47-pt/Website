import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Rocket, Database, Bot, Globe, CheckCircle2, Circle } from 'lucide-react';

const phases = [
  {
    phase: 'Phase 1',
    title: 'Cognitive Organism MVP',
    quarter: 'Q1-Q2 2025',
    icon: Rocket,
    status: 'completed' as const,
    items: [
      'Core agent architecture deployment',
      'Multi-agent communication protocol',
      'AGI token smart contract (ERC-20)',
      'Initial testnet with 5 agent types',
      'Basic proof-of-intelligence validation',
    ],
  },
  {
    phase: 'Phase 2',
    title: 'Real Data Integration',
    quarter: 'Q3-Q4 2025',
    icon: Database,
    status: 'active' as const,
    items: [
      'Live data feeds from 100+ sources',
      'Expanded agent library (47 types)',
      'Mainnet deployment',
      'API marketplace launch',
      'Staking and governance implementation',
    ],
  },
  {
    phase: 'Phase 3',
    title: 'Automation & Execution',
    quarter: 'Q1-Q2 2026',
    icon: Bot,
    status: 'upcoming' as const,
    items: [
      'Autonomous agent deployment',
      'Self-optimizing network topology',
      'Advanced prediction markets',
      'Cross-agent learning protocols',
      'Enterprise integration layer',
    ],
  },
  {
    phase: 'Phase 4',
    title: 'Multi-Chain Expansion',
    quarter: 'Q3-Q4 2026',
    icon: Globe,
    status: 'planned' as const,
    items: [
      'Cross-chain agent deployment',
      'Interoperability with L1/L2 networks',
      'Decentralized identity for agents',
      'DAO governance maturity',
      'Global ecosystem expansion',
    ],
  },
];

function StatusIcon({ status }: { status: string }) {
  switch (status) {
    case 'completed':
      return <CheckCircle2 size={18} className="text-ag-success" />;
    case 'active':
      return <div className="w-[18px] h-[18px] rounded-full border-2 border-ag-purple animate-pulse" />;
    default:
      return <Circle size={18} className="text-ag-text-dim" />;
  }
}

export default function RoadmapSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="roadmap" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-purple/[0.02] to-transparent" />
      <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-ag-blue/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            ROADMAP
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Path to{' '}
            <span className="gradient-text">Collective Intelligence</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-2xl mx-auto leading-relaxed">
            A phased approach to building and scaling the AG47 Cognitive Organism — from initial deployment to
            global multi-chain infrastructure.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="hidden md:block absolute left-[50%] top-0 bottom-0 w-px roadmap-line transform -translate-x-1/2" />

          <div className="space-y-8 md:space-y-0">
            {phases.map((phase, index) => (
              <motion.div
                key={phase.phase}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 + index * 0.15 }}
                className={`relative md:grid md:grid-cols-2 md:gap-8 ${
                  index % 2 === 0 ? '' : 'md:flex-row-reverse'
                }`}
              >
                {/* Content card */}
                <div className={`md:col-span-1 ${index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'}`}>
                  <div className={`ag-card rounded-xl p-6 ${index % 2 === 0 ? '' : 'md:ml-auto'}`}>
                    <div className={`flex items-center gap-3 mb-3 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                      <div className={`p-2 rounded-lg bg-ag-purple/10 text-ag-purple ${phase.status === 'active' ? 'animate-pulse-glow' : ''}`}>
                        <phase.icon size={18} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-ag-purple">{phase.phase}</span>
                          <span className="text-xs text-ag-text-dim">{phase.quarter}</span>
                        </div>
                        <h4 className="text-base font-semibold">{phase.title}</h4>
                      </div>
                    </div>
                    <ul className={`space-y-2 ${index % 2 === 0 ? 'md:text-right' : ''}`}>
                      {phase.items.map((item) => (
                        <li key={item} className="flex items-center gap-2 text-sm text-ag-text-muted">
                          <StatusIcon status={phase.status} />
                          <span className={index % 2 === 0 ? 'md:order-first' : ''}>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Center dot */}
                <div className="hidden md:flex items-center justify-center relative z-10">
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    phase.status === 'completed' ? 'bg-ag-success border-ag-success' :
                    phase.status === 'active' ? 'bg-ag-purple border-ag-purple animate-pulse' :
                    'bg-ag-card border-ag-border-light'
                  }`} />
                </div>

                {/* Spacer for alternating layout */}
                <div className="hidden md:block md:col-span-1" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Mobile timeline (simplified) */}
        <div className="md:hidden space-y-6 mt-8">
          {phases.map((phase, index) => (
            <motion.div
              key={phase.phase}
              initial={{ opacity: 0, x: -10 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.1 + index * 0.1 }}
              className="ag-card rounded-xl p-5"
            >
              <div className="flex items-center gap-3 mb-3">
                <StatusIcon status={phase.status} />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-ag-purple">{phase.phase}</span>
                    <span className="text-xs text-ag-text-dim">{phase.quarter}</span>
                  </div>
                  <h4 className="text-sm font-semibold">{phase.title}</h4>
                </div>
              </div>
              <ul className="space-y-2">
                {phase.items.map((item) => (
                  <li key={item} className="text-xs text-ag-text-muted pl-6 relative">
                    <span className="absolute left-2 top-1.5 w-1 h-1 rounded-full bg-ag-purple/50" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
