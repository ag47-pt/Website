import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Crown,
  Search,
  BarChart3,
  Cpu,
  Vote,
  Gift,
} from 'lucide-react';

const utilities = [
  {
    icon: Crown,
    title: 'Premium Agent Access',
    description: 'Unlock specialized agents with advanced capabilities — financial forecasting, technical analysis, natural language processing, and more.',
    tag: 'ACCESS',
  },
  {
    icon: Search,
    title: 'Advanced Analysis Execution',
    description: 'Run deep multi-variable analyses that cross-reference hundreds of data sources simultaneously for comprehensive insights.',
    tag: 'COMPUTE',
  },
  {
    icon: BarChart3,
    title: 'Prediction Marketplace',
    description: 'Purchase specific prediction outputs from verified agents. Each prediction is scored by historical accuracy and consensus.',
    tag: 'MARKET',
  },
  {
    icon: Cpu,
    title: 'Processing Power Payment',
    description: 'Every computation requires AGI. The more intensive the analysis, the more tokens consumed. Payment is automatic and transparent.',
    tag: 'FUEL',
  },
  {
    icon: Vote,
    title: 'Protocol Governance',
    description: 'Vote on network parameters, agent deployment priorities, fee structures, and protocol upgrades. Holders shape the organism.',
    tag: 'GOVERNANCE',
  },
  {
    icon: Gift,
    title: 'Contribution Rewards',
    description: 'Earn AGI by contributing data, deploying agents, or improving the ecosystem. Value is rewarded proportionally to impact.',
    tag: 'REWARDS',
  },
];

export default function TokenUtilitySection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="token-utility" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-purple/[0.02] to-transparent" />
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-ag-purple/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            TOKEN UTILITY
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            AGI Is{' '}
            <span className="gradient-text">Functional Currency</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-3xl mx-auto leading-relaxed">
            AGI is not a speculative asset. It is a utility token designed to power the entire AG47 ecosystem.
            Every interaction within the network requires tokens, creating organic, demand-driven utility.
          </p>
        </motion.div>

        {/* Utility grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {utilities.map((utility, index) => (
            <motion.div
              key={utility.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.05 + index * 0.07 }}
              className="ag-card rounded-xl p-6 group relative overflow-hidden"
            >
              {/* Hover gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-ag-purple/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative z-10">
                {/* Tag */}
                <div className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold tracking-wider text-ag-purple bg-ag-purple/10 mb-4">
                  {utility.tag}
                </div>

                <div className="p-2.5 rounded-lg bg-ag-purple/10 text-ag-purple w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                  <utility.icon size={20} />
                </div>
                <h4 className="text-base font-semibold mb-2 group-hover:text-ag-purple-light transition-colors duration-300">
                  {utility.title}
                </h4>
                <p className="text-ag-text-muted text-sm leading-relaxed">
                  {utility.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mt-10 text-center"
        >
          <p className="text-ag-text-dim text-sm max-w-xl mx-auto">
            Token utility scales with network activity. As more agents are deployed and more queries are processed,
            demand for AGI increases organically.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
