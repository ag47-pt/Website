import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { ArrowRight, ShieldCheck, Code, BookOpen } from 'lucide-react';

export default function CTASection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="get-started" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-ag-purple/10 via-transparent to-ag-cyan/10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-ag-purple/10 rounded-full blur-[160px]" />

      <div className="relative z-10 container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="ag-card rounded-3xl p-8 sm:p-12 lg:p-16 text-center relative overflow-hidden"
        >
          {/* Corner accents */}
          <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-ag-purple/30 rounded-tl-3xl" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-b-2 border-r-2 border-ag-purple/30 rounded-br-3xl" />

          <div className="max-w-2xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="mb-6"
            >
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
                Start Building with{' '}
                <span className="gradient-text">Decentralized Intelligence</span>
              </h2>
              <p className="text-ag-text-muted text-lg leading-relaxed">
                Whether you're a developer, researcher, or enterprise — the AG47 ecosystem is open to you.
                Deploy agents, access analyses, or contribute to the protocol.
              </p>
            </motion.div>

            {/* CTA buttons */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10"
            >
              <a
                href="#"
                className="ag-btn-primary w-full sm:w-auto"
              >
                <span className="flex items-center justify-center gap-2">
                  <Code size={16} />
                  Start Building
                  <ArrowRight size={16} />
                </span>
              </a>
              <a
                href="#"
                className="ag-btn-secondary w-full sm:w-auto"
              >
                <span className="flex items-center justify-center gap-2">
                  <BookOpen size={16} />
                  Read Documentation
                </span>
              </a>
            </motion.div>

            {/* Trust badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.4 }}
              className="flex flex-wrap items-center justify-center gap-6 text-xs text-ag-text-dim"
            >
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-ag-success" />
                <span>Smart Contract Audited</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Code size={14} className="text-ag-cyan" />
                <span>Open Source (MIT)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-ag-success" />
                <span>No Pre-mine</span>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
