import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Activity,
  Server,
  Users,
  TrendingUp,
  Zap,
  BarChart3,
} from 'lucide-react';

function AnimatedCounter({ value, suffix = '' }: { value: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true });
  const motionValue = useMotionValue(0);
  const displayValue = useTransform(motionValue, (latest) =>
    Math.floor(latest).toLocaleString() + suffix
  );

  if (isInView) {
    animate(motionValue, value, { duration: 2, ease: 'easeOut' });
  }

  return <motion.span ref={ref}>{displayValue}</motion.span>;
}

const metrics = [
  {
    icon: Activity,
    value: 2847563,
    suffix: '',
    label: 'Analyses Processed',
    description: 'Total deep analyses completed by the organism',
  },
  {
    icon: Server,
    value: 47,
    suffix: '',
    label: 'Active Agents',
    description: 'Specialized AI agents running 24/7',
  },
  {
    icon: Users,
    value: 128450,
    suffix: '',
    label: 'Network Users',
    description: 'Unique users querying the network',
  },
  {
    icon: TrendingUp,
    value: 94,
    suffix: '%',
    label: 'Prediction Accuracy',
    description: 'Verified accuracy rate across all agents',
  },
  {
    icon: Zap,
    value: 892,
    suffix: 'M',
    label: 'AGI Tokens Burned',
    description: 'Total tokens permanently removed from supply',
  },
  {
    icon: BarChart3,
    value: 340,
    suffix: '+',
    label: 'Data Sources',
    description: 'Live data feeds integrated into the network',
  },
];

export default function MetricsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-ag-card/30" />
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="absolute top-0 left-1/4 w-[600px] h-[300px] bg-ag-purple/5 rounded-full blur-[150px]" />

      <div className="relative z-10 container-custom">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            LIVE METRICS
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Network in{' '}
            <span className="gradient-text">Real Time</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-xl mx-auto">
            Key performance indicators from the AG47 Cognitive Organism.
            Numbers update continuously as agents process data.
          </p>
        </motion.div>

        {/* Metrics grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.05 + index * 0.08 }}
              className="ag-card rounded-xl p-5 lg:p-6 group text-center"
            >
              <div className="mx-auto mb-3 w-10 h-10 rounded-lg bg-ag-purple/10 text-ag-purple flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <metric.icon size={20} />
              </div>
              <div className="text-2xl lg:text-3xl font-bold gradient-text mb-1 font-mono">
                <AnimatedCounter value={metric.value} suffix={metric.suffix} />
              </div>
              <div className="text-sm font-semibold text-ag-text mb-1">{metric.label}</div>
              <div className="text-xs text-ag-text-dim">{metric.description}</div>
            </motion.div>
          ))}
        </div>

        {/* Live indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.5 }}
          className="flex items-center justify-center gap-2 mt-8 text-xs text-ag-text-dim"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-ag-success opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-ag-success" />
          </span>
          <span>Network operational • Data refreshes every 60s</span>
        </motion.div>
      </div>
    </section>
  );
}
