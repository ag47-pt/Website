import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  User,
  Search,
  Cpu,
  FileOutput,
  Coins,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

const steps = [
  {
    icon: User,
    step: '01',
    title: 'Request Analysis',
    description: 'Submit a query to the AG47 network. Specify your domain, data scope, and desired output format.',
    color: 'from-ag-purple to-ag-purple-dark',
  },
  {
    icon: Search,
    step: '02',
    title: 'Agent Discovery',
    description: 'The organism routes your request to the most relevant agents. Multiple specialists are assigned in parallel.',
    color: 'from-ag-blue to-ag-purple',
  },
  {
    icon: Cpu,
    step: '03',
    title: 'Distributed Processing',
    description: 'Agents analyze data from multiple sources, cross-validate findings, and build consensus on results.',
    color: 'from-ag-cyan to-ag-blue',
  },
  {
    icon: FileOutput,
    step: '04',
    title: 'Synthesized Output',
    description: 'Results are compiled into structured intelligence — predictions, insights, and actionable recommendations.',
    color: 'from-ag-blue to-ag-cyan',
  },
  {
    icon: Coins,
    step: '05',
    title: 'Token Settlement',
    description: 'AGI tokens are consumed for processing, distributed to contributing agents, and burned as protocol fees.',
    color: 'from-ag-purple to-ag-cyan',
  },
];

function ProofOfIntelligenceCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="ag-card rounded-2xl p-6 lg:p-8 mt-8 lg:mt-0"
    >
      <div className="flex items-center gap-3 mb-5">
        <div className="p-2.5 rounded-lg bg-ag-purple/10 text-ag-purple">
          <CheckCircle2 size={20} />
        </div>
        <h3 className="text-xl font-bold">
          Proof of <span className="gradient-text">Intelligence</span>
        </h3>
      </div>
      <p className="text-ag-text-muted text-sm leading-relaxed mb-5">
        Unlike proof of work or proof of stake, PoI rewards agents based on the
        <strong className="text-ag-text"> measurable quality and usefulness</strong> of their contributions.
      </p>
      <div className="space-y-3">
        {[
          'Agents earn tokens for verified useful outputs',
          'Quality scores are validated by consensus mechanisms',
          'Poor-performing agents lose reputation and rewards',
          'Token burn rate scales with network intelligence quality',
        ].map((item, i) => (
          <div key={i} className="flex items-start gap-3">
            <div className="mt-0.5 w-4 h-4 rounded-full bg-ag-purple/20 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 size={10} className="text-ag-purple" />
            </div>
            <span className="text-sm text-ag-text-muted">{item}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default function HowItWorksSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="how-it-works" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-blue/[0.02] to-transparent" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-ag-cyan/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            HOW IT WORKS
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            From Query to{' '}
            <span className="gradient-text">Intelligence</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-2xl mx-auto leading-relaxed">
            A streamlined pipeline that transforms raw data requests into structured, actionable intelligence —
            powered by AGI tokens at every step.
          </p>
        </motion.div>

        {/* Flow steps */}
        <div className="relative">
          {/* Desktop flow */}
          <div className="hidden lg:grid lg:grid-cols-5 gap-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.1 + index * 0.1 }}
                className="relative"
              >
                {/* Arrow between cards */}
                {index < steps.length - 1 && (
                  <div className="absolute top-10 -right-2 z-10 text-ag-border-light">
                    <ArrowRight size={16} />
                  </div>
                )}
                <div className="ag-card rounded-xl p-5 text-center group h-full">
                  <div className={`w-12 h-12 mx-auto mb-4 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <step.icon size={22} className="text-white" />
                  </div>
                  <div className="text-xs font-mono text-ag-purple mb-1">{step.step}</div>
                  <h4 className="text-sm font-semibold mb-2 group-hover:text-ag-purple-light transition-colors duration-300">
                    {step.title}
                  </h4>
                  <p className="text-ag-text-dim text-xs leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Mobile flow */}
          <div className="lg:hidden space-y-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.1 + index * 0.1 }}
                className="ag-card rounded-xl p-5 flex items-start gap-4"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center flex-shrink-0`}>
                  <step.icon size={18} className="text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-ag-purple">{step.step}</span>
                    <h4 className="text-sm font-semibold">{step.title}</h4>
                  </div>
                  <p className="text-ag-text-dim text-xs leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* PoI Card */}
        <div className="mt-12">
          <ProofOfIntelligenceCard />
        </div>
      </div>
    </section>
  );
}
