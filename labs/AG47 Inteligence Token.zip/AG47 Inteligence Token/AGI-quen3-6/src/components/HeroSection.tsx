import { motion } from 'framer-motion';
import { ArrowRight, BookOpen, ChevronDown, Shield, Zap, Brain } from 'lucide-react';
import { useRef, useEffect } from 'react';

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener('resize', resize);

    const count = Math.min(60, Math.floor(canvas.offsetWidth / 25));
    const nodes: { x: number; y: number; vx: number; vy: number }[] = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.offsetWidth,
      y: Math.random() * canvas.offsetHeight,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
    }));

    const animate = () => {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      nodes.forEach((node) => {
        let nx = node.x + node.vx;
        let ny = node.y + node.vy;
        if (nx < 0 || nx > canvas.offsetWidth) node.vx *= -1;
        if (ny < 0 || ny > canvas.offsetHeight) node.vy *= -1;
        node.x = nx;
        node.y = ny;
      });

      nodes.forEach((node, i) => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(139, 92, 246, 0.6)';
        ctx.fill();

        nodes.slice(i + 1).forEach((other) => {
          const dx = node.x - other.x;
          const dy = node.y - other.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 150) {
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(other.x, other.y);
            ctx.strokeStyle = `rgba(139, 92, 246, ${0.12 * (1 - dist / 150)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        });
      });

      requestAnimationFrame(animate);
    };
    animate();

    return () => window.removeEventListener('resize', resize);
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

export default function HeroSection() {
  const containerVariants = {
    hidden: {},
    visible: {
      transition: { staggerChildren: 0.15, delayChildren: 0.3 },
    },
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden noise">
      {/* Particle background */}
      <div className="absolute inset-0 z-0">
        <ParticleCanvas />
      </div>

      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-gradient-radial from-ag-purple/5 via-transparent to-transparent z-0" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-ag-purple/8 rounded-full blur-[160px] z-0" />

      {/* Grid */}
      <div className="absolute inset-0 grid-bg z-0 opacity-50" />

      {/* Content */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 container-custom text-center py-32 lg:py-20"
      >
        {/* Badge */}
        <motion.div variants={itemVariants} className="flex justify-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-ag-purple/10 border border-ag-purple/20 text-ag-purple-light text-sm font-medium">
            <Shield size={14} />
            <span>Proof of Intelligence Protocol</span>
            <span className="px-1.5 py-0.5 bg-ag-purple/20 rounded-full text-xs font-semibold">v2.0</span>
          </div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={itemVariants}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.1] mb-6"
        >
          The Infrastructure Layer for{' '}
          <span className="gradient-text">Decentralized</span>{' '}
          <br className="hidden sm:block" />
          <span className="gradient-text">Intelligence</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          variants={itemVariants}
          className="text-lg sm:text-xl text-ag-text-muted max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          AGI powers the AG47 Cognitive Organism — a distributed network of AI agents that analyze, predict, and produce
          collective intelligence. A utility-first token for real computational work.
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
        >
          <a
            href="#get-started"
            className="ag-btn-primary w-full sm:w-auto text-center"
          >
            <span className="flex items-center justify-center gap-2">
              Get Started
              <ArrowRight size={16} />
            </span>
          </a>
          <a
            href="#whitepaper"
            className="ag-btn-secondary w-full sm:w-auto text-center"
          >
            <span className="flex items-center justify-center gap-2">
              <BookOpen size={16} />
              Read Whitepaper
            </span>
          </a>
        </motion.div>

        {/* Feature pills */}
        <motion.div
          variants={itemVariants}
          className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-sm text-ag-text-dim"
        >
          {[
            { icon: Brain, text: 'Multi-Agent Network' },
            { icon: Zap, text: 'Real-Time Processing' },
            { icon: Shield, text: 'Audit Verified' },
          ].map((item) => (
            <div key={item.text} className="flex items-center gap-2">
              <item.icon size={16} className="text-ag-purple" />
              {item.text}
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="text-ag-text-dim"
        >
          <ChevronDown size={20} />
        </motion.div>
      </motion.div>
    </section>
  );
}
