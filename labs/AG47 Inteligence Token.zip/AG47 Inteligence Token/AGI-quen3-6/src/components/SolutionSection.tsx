import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Network,
  Cpu,
  ArrowDownUp,
  Sparkles,
  Layers,
  GitMerge,
} from 'lucide-react';

function CognitiveNetworkSVG() {
  return (
    <svg viewBox="0 0 400 300" className="w-full h-full opacity-40">
      <defs>
        <linearGradient id="nodeGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#06b6d4" />
        </linearGradient>
        <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.3" />
          <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.3" />
        </linearGradient>
      </defs>

      {/* Connections */}
      {[
        [200, 60, 100, 130], [200, 60, 300, 130], [200, 60, 150, 200],
        [200, 60, 250, 200], [100, 130, 150, 200], [100, 130, 60, 200],
        [300, 130, 250, 200], [300, 130, 340, 200], [150, 200, 200, 260],
        [250, 200, 200, 260], [150, 200, 100, 260], [250, 200, 300, 260],
        [60, 200, 100, 260], [340, 200, 300, 260],
        [100, 130, 300, 130], [150, 200, 250, 200],
      ].map(([x1, y1, x2, y2], i) => (
        <line
          key={i}
          x1={x1} y1={y1} x2={x2} y2={y2}
          stroke="url(#lineGrad)"
          strokeWidth="1"
          strokeDasharray="4 4"
          className="animate-dash"
        />
      ))}

      {/* Nodes */}
      {[
        [200, 60, 8], [100, 130, 6], [300, 130, 6],
        [60, 200, 4], [150, 200, 5], [250, 200, 5], [340, 200, 4],
        [100, 260, 4], [200, 260, 7], [300, 260, 4],
      ].map(([cx, cy, r], i) => (
        <g key={i}>
          <circle
            cx={cx} cy={cy} r={Number(r)}
            fill="url(#nodeGrad1)"
            opacity="0.8"
            className="animate-node"
          >
            <animate attributeName="r" values={`${Number(r)};${Number(r) + 2};${Number(r)}`} dur={`${2 + i * 0.2}s`} repeatCount="indefinite" />
          </circle>
          <circle
            cx={cx} cy={cy} r={Number(r) + 4}
            fill="none"
            stroke="#8b5cf6"
            strokeWidth="0.5"
            opacity="0.3"
          />
        </g>
      ))}
    </svg>
  );
}

export default function SolutionSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const features = [
    {
      icon: Network,
      title: 'Multi-Agent Architecture',
      description: 'Dozens of specialized AI agents working in parallel, each optimized for specific analytical domains — from market analysis to pattern detection.',
    },
    {
      icon: Cpu,
      title: 'Proof of Intelligence',
      description: 'Agents earn AGI tokens based on the quality and usefulness of their contributions. Intelligence is validated through consensus, not speculation.',
    },
    {
      icon: ArrowDownUp,
      title: 'Collective Intelligence',
      description: 'Individual agent outputs are synthesized into unified intelligence products — predictions, analyses, and actionable insights.',
    },
    {
      icon: Sparkles,
      title: 'Token as Fuel',
      description: 'AGI is the operational currency. Every computation, analysis, and prediction requires token expenditure, creating real utility and demand.',
    },
    {
      icon: Layers,
      title: 'Open Infrastructure',
      description: 'Built on open protocols. Anyone can deploy agents, submit data, or build tools on top of the AG47 ecosystem.',
    },
    {
      icon: GitMerge,
      title: 'Continuous Learning',
      description: 'The organism evolves. Agent weights update continuously based on real-world validation. The system gets smarter with every interaction.',
    },
  ];

  return (
    <section id="solution" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-purple/[0.02] to-transparent" />
      <div className="absolute top-1/3 left-0 w-[400px] h-[400px] bg-ag-purple/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            THE SOLUTION
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Meet the{' '}
            <span className="gradient-text">AG47 Cognitive Organism</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-3xl mx-auto leading-relaxed">
            A living, evolving network of AI agents that analyze data, generate predictions, and produce collective
            intelligence — powered by the AGI utility token.
          </p>
        </motion.div>

        {/* Main visual + text */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="ag-card rounded-2xl p-8 lg:p-12 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-ag-purple/5 to-ag-cyan/5" />
              <div className="relative h-[300px] lg:h-[350px]">
                <CognitiveNetworkSVG />
              </div>
              <div className="relative mt-4 flex items-center justify-center gap-2 text-xs text-ag-text-dim font-mono">
                <span className="w-2 h-2 bg-ag-success rounded-full animate-pulse" />
                <span>47 agents active • Processing live data</span>
              </div>
            </div>
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-2xl lg:text-3xl font-bold mb-4">
              Intelligence as an{' '}
              <span className="gradient-text">Organism</span>
            </h3>
            <p className="text-ag-text-muted leading-relaxed mb-6">
              AG47 is not a single model. It is a coordinated organism — dozens of specialized agents that work together
              like cells in a body. Each agent has a role, communicates through shared protocols, and contributes to the
              collective output.
            </p>
            <p className="text-ag-text-muted leading-relaxed mb-8">
              AGI tokens power every action. They are consumed when you request analysis, earned when agents contribute
              value, and burned when computations complete. This is not a store of value — it is a store of <em>work</em>.
            </p>

            {/* Key stats */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { value: '47', label: 'Agent Types' },
                { value: '∞', label: 'Scalability' },
                { value: '24/7', label: 'Operation' },
              ].map((stat) => (
                <div key={stat.label} className="text-center p-4 rounded-xl bg-ag-card border border-ag-border/50">
                  <div className="text-xl font-bold gradient-text">{stat.value}</div>
                  <div className="text-xs text-ag-text-dim mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Feature grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.1 + index * 0.08 }}
              className="ag-card rounded-xl p-6 group"
            >
              <div className="p-2.5 rounded-lg bg-ag-purple/10 text-ag-purple w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                <feature.icon size={20} />
              </div>
              <h4 className="text-base font-semibold mb-2 group-hover:text-ag-purple-light transition-colors duration-300">
                {feature.title}
              </h4>
              <p className="text-ag-text-muted text-sm leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
