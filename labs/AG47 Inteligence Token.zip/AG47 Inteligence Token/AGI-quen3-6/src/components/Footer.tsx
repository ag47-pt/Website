import { MessageCircle, ExternalLink, Mail } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-ag-border/50 bg-ag-darker">
      <div className="container-custom py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="relative w-8 h-8">
                <svg viewBox="0 0 32 32" className="w-full h-full">
                  <defs>
                    <linearGradient id="logoGradFooter" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#8b5cf6" />
                      <stop offset="100%" stopColor="#06b6d4" />
                    </linearGradient>
                  </defs>
                  <polygon points="16,2 30,28 2,28" fill="none" stroke="url(#logoGradFooter)" strokeWidth="2" />
                  <circle cx="16" cy="17" r="4" fill="url(#logoGradFooter)" />
                  <line x1="16" y1="13" x2="16" y2="8" stroke="url(#logoGradFooter)" strokeWidth="1.5" />
                  <line x1="19.5" y1="19" x2="24" y2="23" stroke="url(#logoGradFooter)" strokeWidth="1.5" />
                  <line x1="12.5" y1="19" x2="8" y2="23" stroke="url(#logoGradFooter)" strokeWidth="1.5" />
                </svg>
              </div>
              <span className="text-lg font-bold">
                <span className="gradient-text">AGI</span>
              </span>
            </div>
            <p className="text-ag-text-dim text-sm max-w-md leading-relaxed mb-6">
              The infrastructure layer for decentralized intelligence. AGI powers the AG47 Cognitive Organism —
              a distributed network of AI agents analyzing, predicting, and producing collective intelligence.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="w-9 h-9 rounded-lg bg-ag-card border border-ag-border flex items-center justify-center text-ag-text-dim hover:text-ag-purple hover:border-ag-purple/50 transition-all duration-200" aria-label="X/Twitter">
                <span className="text-xs font-bold">𝕏</span>
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-ag-card border border-ag-border flex items-center justify-center text-ag-text-dim hover:text-ag-purple hover:border-ag-purple/50 transition-all duration-200" aria-label="GitHub">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" /></svg>
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-ag-card border border-ag-border flex items-center justify-center text-ag-text-dim hover:text-ag-purple hover:border-ag-purple/50 transition-all duration-200" aria-label="Discord">
                <MessageCircle size={16} />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-ag-card border border-ag-border flex items-center justify-center text-ag-text-dim hover:text-ag-purple hover:border-ag-purple/50 transition-all duration-200" aria-label="Email">
                <Mail size={16} />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-ag-text mb-4">Protocol</h4>
            <ul className="space-y-3">
              {[
                'Whitepaper',
                'Documentation',
                'API Reference',
                'Smart Contracts',
                'Audit Reports',
                'Brand Kit',
              ].map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-ag-text-dim hover:text-ag-purple transition-colors inline-flex items-center gap-1.5 group">
                    {link}
                    <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-ag-text mb-4">Community</h4>
            <ul className="space-y-3">
              {[
                'Governance Portal',
                'Developer Grants',
                'Bug Bounty',
                'Community Forum',
                'Blog',
                'Careers',
              ].map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-ag-text-dim hover:text-ag-purple transition-colors inline-flex items-center gap-1.5 group">
                    {link}
                    <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-ag-border/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ag-text-dim">
            © {currentYear} AG Intelligence Token. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-ag-text-dim">
            <a href="#" className="hover:text-ag-purple transition-colors">Terms of Service</a>
            <span>•</span>
            <a href="#" className="hover:text-ag-purple transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#" className="hover:text-ag-purple transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
