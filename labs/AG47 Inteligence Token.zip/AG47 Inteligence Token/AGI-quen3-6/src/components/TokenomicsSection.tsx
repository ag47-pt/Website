import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Flame, Lock, RefreshCw } from 'lucide-react';

const distribution = [
  { label: 'Community & Ecosystem', percentage: 40, color: '#8b5cf6', description: 'Rewards, airdrops, grants, and ecosystem incentives' },
  { label: 'Development', percentage: 20, color: '#3b82f6', description: 'Core protocol development and agent research' },
  { label: 'Liquidity', percentage: 15, color: '#06b6d4', description: 'DEX liquidity pools and market making' },
  { label: 'Team & Advisors', percentage: 10, color: '#10b981', description: 'Vested over 36 months with 12-month cliff' },
  { label: 'Reserve', percentage: 15, color: '#4b5563', description: 'Strategic reserve for future protocol needs' },
];

const mechanisms = [
  {
    icon: Flame,
    title: 'Token Burn',
    description: 'A percentage of every transaction fee is permanently burned. Network activity directly reduces supply, creating deflationary pressure through real usage.',
  },
  {
    icon: Lock,
    title: 'Staking',
    description: 'Stake AGI to participate in governance, receive priority processing, and earn network revenue shares. Lock-up periods determine reward multipliers.',
  },
  {
    icon: RefreshCw,
    title: 'Mandatory Usage',
    description: 'AGI is required for every network operation. There is no way to use the AG47 ecosystem without tokens, ensuring continuous demand.',
  },
];

function TokenomicsChart() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Calculate cumulative percentages for conic gradient
  const segments: string[] = [];
  let cumulative = 0;
    distribution.forEach((item) => {
    const start = (cumulative / 100) * 360;
    cumulative += item.percentage;
    const end = (cumulative / 100) * 360;
    segments.push(`${item.color} ${start}deg ${end}deg`);
  });

  return (
    <div className="flex flex-col items-center">
      {/* Chart */}
      <div className="relative w-48 h-48 sm:w-56 sm:h-56 mb-8">
        <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
          {distribution.map((item, index) => {
            const startAngle = distribution.slice(0, index).reduce((sum, d) => sum + d.percentage, 0) / 100 * 360;
            const endAngle = (startAngle + item.percentage / 100 * 360);
            const radius = hoveredIndex === index ? 85 : 80;
            const cx = 100;
            const cy = 100;

            const startRad = (startAngle * Math.PI) / 180;
            const endRad = (endAngle * Math.PI) / 180;

            const x1 = cx + radius * Math.cos(startRad);
            const y1 = cy + radius * Math.sin(startRad);
            const x2 = cx + radius * Math.cos(endRad);
            const y2 = cy + radius * Math.sin(endRad);

            const largeArc = endAngle - startAngle > 180 ? 1 : 0;

            return (
              <motion.path
                key={item.label}
                d={`M ${cx} ${cy} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`}
                fill={item.color}
                opacity={hoveredIndex !== null && hoveredIndex !== index ? 0.3 : 0.85}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                className="cursor-pointer"
                initial={{ scale: 0.9 }}
                animate={{ scale: hoveredIndex === index ? 1.05 : 1 }}
                transition={{ duration: 0.2 }}
              />
            );
          })}
          {/* Inner circle for donut */}
          <circle cx="100" cy="100" r="50" fill="#0a0a1a" />
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl font-bold gradient-text">
            {hoveredIndex !== null ? `${distribution[hoveredIndex].percentage}%` : '1B'}
          </span>
          <span className="text-xs text-ag-text-dim">
            {hoveredIndex !== null ? distribution[hoveredIndex].label : 'Total Supply'}
          </span>
        </div>
      </div>

      {/* Legend */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
        {distribution.map((item, index) => (
          <div
            key={item.label}
            className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-200 cursor-pointer ${
              hoveredIndex === index ? 'bg-ag-purple/10' : 'hover:bg-ag-card-hover'
            }`}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: item.color }} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-ag-text">{item.label}</span>
                <span className="text-sm font-bold text-ag-text ml-2">{item.percentage}%</span>
              </div>
              <p className="text-xs text-ag-text-dim truncate">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TokenomicsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="tokenomics" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-blue/[0.02] to-transparent" />
      <div className="absolute bottom-1/3 left-0 w-[400px] h-[400px] bg-ag-cyan/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            TOKENOMICS
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Supply Designed for{' '}
            <span className="gradient-text">Sustainability</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-3xl mx-auto leading-relaxed">
            No pre-mine for founders. No hidden allocations. A transparent distribution model where community and
            development represent the vast majority of supply.
          </p>
        </motion.div>

        {/* Token details */}
        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12 items-start">
          {/* Left: Token details */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <div className="ag-card rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-4">Token Specifications</h3>
                <div className="space-y-3">
                  {[
                    ['Token Name', 'AG Intelligence Token'],
                    ['Symbol', 'AGI'],
                    ['Total Supply', '1,000,000,000 (1B)'],
                    ['Decimals', '18'],
                    ['Type', 'Utility / Governance'],
                    ['Standard', 'ERC-20 (Ethereum L2)'],
                    ['Pre-mine', 'None'],
                  ].map(([label, value]) => (
                    <div key={label} className="flex items-center justify-between text-sm">
                      <span className="text-ag-text-dim">{label}</span>
                      <span className="text-ag-text font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Mechanisms */}
              <div className="space-y-4">
                {mechanisms.map((mech, index) => (
                  <motion.div
                    key={mech.title}
                    initial={{ opacity: 0, y: 10 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.1 + index * 0.1 }}
                    className="ag-card rounded-xl p-5 group"
                  >
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-ag-purple/10 text-ag-purple flex-shrink-0 group-hover:scale-110 transition-transform">
                        <mech.icon size={18} />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold mb-1 group-hover:text-ag-purple-light transition-colors">
                          {mech.title}
                        </h4>
                        <p className="text-xs text-ag-text-dim leading-relaxed">
                          {mech.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right: Chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-3"
          >
            <div className="ag-card rounded-2xl p-6 lg:p-8">
              <h3 className="text-lg font-semibold mb-6 text-center">Distribution Breakdown</h3>
              <TokenomicsChart />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
