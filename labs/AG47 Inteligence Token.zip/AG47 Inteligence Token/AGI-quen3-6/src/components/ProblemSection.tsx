import { motion } from 'framer-motion';
import { Database, Lock, AlertTriangle, BrainCircuit } from 'lucide-react';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const problems = [
  {
    icon: Database,
    title: 'Data Overload',
    description:
      'The world generates 328+ petabytes of data daily. The bottleneck isn\'t data collection — it\'s extracting structured intelligence from the noise.',
    stat: '328 PB/day',
    statLabel: 'global data generation',
  },
  {
    icon: BrainCircuit,
    title: 'Unstructured Intelligence',
    description:
      'Current systems process data in silos. There is no unified framework for cross-domain analysis, making holistic intelligence impossible.',
    stat: '0 unified',
    statLabel: 'cross-domain frameworks',
  },
  {
    icon: Lock,
    title: 'Centralized AI Monopolies',
    description:
      'Three corporations control 70%+ of AI infrastructure. Centralization creates single points of failure, bias, and censorship risk.',
    stat: '70%+',
    statLabel: 'controlled by 3 companies',
  },
  {
    icon: AlertTriangle,
    title: 'Poor Decision Making',
    description:
      'Organizations make multi-million dollar decisions on incomplete analysis. Without continuous intelligent processing, decisions are guesses.',
    stat: '87%',
    statLabel: 'decisions lack real-time data',
  },
];

function Counter({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-right">
      <div className="text-2xl font-bold gradient-text">{value}</div>
      <div className="text-xs text-ag-text-dim mt-0.5">{label}</div>
    </div>
  );
}

export default function ProblemSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="problem" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-ag-blue/5 rounded-full blur-[120px]" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            THE PROBLEM
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Why Current Systems{' '}
            <span className="gradient-text">Fail at Scale</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-2xl mx-auto leading-relaxed">
            The intersection of massive data growth and centralized AI infrastructure has created systemic vulnerabilities
            that affect every industry and every decision.
          </p>
        </motion.div>

        {/* Problem cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 lg:gap-6">
          {problems.map((problem, index) => (
            <motion.div
              key={problem.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="ag-card rounded-2xl p-6 lg:p-8 relative overflow-hidden group"
            >
              {/* Card accent line */}
              <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-ag-purple/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="p-3 rounded-xl bg-ag-purple/10 text-ag-purple group-hover:bg-ag-purple/20 transition-colors duration-300">
                  <problem.icon size={24} />
                </div>
                <Counter value={problem.stat} label={problem.statLabel} />
              </div>
              <h3 className="text-xl font-semibold mb-3 group-hover:text-ag-purple-light transition-colors duration-300">
                {problem.title}
              </h3>
              <p className="text-ag-text-muted leading-relaxed text-sm">
                {problem.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Bottom statement */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-12 text-center"
        >
          <p className="text-ag-text-dim text-sm max-w-xl mx-auto">
            These aren\'t isolated problems — they reinforce each other, creating a system that becomes less intelligent
            as it grows.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
