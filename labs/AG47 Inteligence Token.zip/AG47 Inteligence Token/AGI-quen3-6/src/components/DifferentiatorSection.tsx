import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Check, X, Minus } from 'lucide-react';

const comparisonData = [
  {
    feature: 'Token Purpose',
    agi: 'Utility — powers computation',
    others: 'Speculation — price-only focus',
  },
  {
    feature: 'AI Infrastructure',
    agi: 'Decentralized multi-agent network',
    others: 'Centralized API monopolies',
  },
  {
    feature: 'Value Generation',
    agi: 'Real computation & analysis output',
    others: 'Marketing & hype cycles',
  },
  {
    feature: 'Token Economics',
    agi: 'Burn + utility-driven demand',
    others: 'Inflationary with no sink',
  },
  {
    feature: 'Governance',
    agi: 'On-chain, token-weighted voting',
    others: 'Centralized team decisions',
  },
  {
    feature: 'Transparency',
    agi: 'Open-source, audited, public data',
    others: 'Black-box, no verification',
  },
  {
    feature: 'Longevity',
    agi: 'Self-sustaining ecosystem',
    others: 'Dependent on market sentiment',
  },
  {
    feature: 'Accessibility',
    agi: 'Permissionless, anyone can deploy agents',
    others: 'Invite-only, rate-limited APIs',
  },
];

function ComparisonRow({ row, index, isInView }: { row: (typeof comparisonData)[0]; index: number; isInView: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.3, delay: 0.05 + index * 0.05 }}
      className={`grid grid-cols-3 gap-4 py-4 px-4 rounded-lg ${
        index % 2 === 0 ? 'bg-ag-card/50' : ''
      } hover:bg-ag-purple/5 transition-colors duration-200`}
    >
      <div className="text-sm font-medium text-ag-text">{row.feature}</div>
      <div className="text-sm flex items-center gap-2">
        <Check size={14} className="text-ag-success flex-shrink-0" />
        <span className="text-ag-text">{row.agi}</span>
      </div>
      <div className="text-sm flex items-center gap-2">
        <X size={14} className="text-ag-text-dim flex-shrink-0" />
        <span className="text-ag-text-dim">{row.others}</span>
      </div>
    </motion.div>
  );
}

export default function DifferentiatorSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="differentiator" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-purple/[0.02] to-transparent" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            WHY AGI
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Built Different by{' '}
            <span className="gradient-text">Design</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-3xl mx-auto leading-relaxed">
            AGI isn\'t trying to be the next speculative token or another centralized AI wrapper. It is purpose-built
            infrastructure for a new paradigm.
          </p>
        </motion.div>

        {/* Equation display */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex justify-center mb-12"
        >
          <div className="ag-card rounded-2xl p-6 lg:p-8 inline-flex items-center gap-4 lg:gap-6 flex-wrap justify-center">
            <span className="text-ag-text-muted text-sm font-mono">AGI =</span>
            <div className="px-4 py-2 rounded-lg bg-ag-purple/10 text-ag-purple-light font-semibold text-sm">
              Infrastructure
            </div>
            <Minus size={16} className="text-ag-text-dim" />
            <div className="px-4 py-2 rounded-lg bg-ag-blue/10 text-ag-blue-light font-semibold text-sm">
              Utility
            </div>
            <Minus size={16} className="text-ag-text-dim" />
            <div className="px-4 py-2 rounded-lg bg-ag-cyan/10 text-ag-cyan-light font-semibold text-sm">
              Functional Economy
            </div>
          </div>
        </motion.div>

        {/* Comparison table */}
        <div className="max-w-4xl mx-auto">
          {/* Table header */}
          <div className="grid grid-cols-3 gap-4 pb-4 mb-2 border-b border-ag-border text-center">
            <div className="text-xs text-ag-text-dim uppercase tracking-wider font-medium">Feature</div>
            <div className="text-xs text-ag-purple uppercase tracking-wider font-semibold flex items-center justify-center gap-1.5">
              <Check size={12} />
              AGI Token
            </div>
            <div className="text-xs text-ag-text-dim uppercase tracking-wider font-medium flex items-center justify-center gap-1.5">
              <X size={12} />
              Typical Projects
            </div>
          </div>

          {/* Rows */}
          <div>
            {comparisonData.map((row, index) => (
              <ComparisonRow key={row.feature} row={row} index={index} isInView={isInView} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
