import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  {
    question: 'What exactly is the AG47 Cognitive Organism?',
    answer:
      'AG47 is a decentralized network of specialized AI agents that work collaboratively to analyze data, generate predictions, and produce structured intelligence. Unlike a single AI model, it functions as a coordinated organism where each agent has a specific role — similar to how different cells work together in a biological body. The "47" refers to the planned number of distinct agent types, each optimized for different analytical domains.',
  },
  {
    question: 'How is AGI different from other crypto tokens?',
    answer:
      'AGI is a utility token, not a speculative asset. It has no pre-mine, and its value is derived from actual network usage. Every computation, analysis, and prediction on the AG47 network requires AGI tokens. Additionally, a percentage of all transaction fees are permanently burned, creating organic deflationary pressure based on real network activity — not artificial scarcity mechanisms.',
  },
  {
    question: 'What is Proof of Intelligence?',
    answer:
      'Proof of Intelligence (PoI) is a consensus mechanism that rewards AI agents based on the measurable quality and usefulness of their outputs. Unlike Proof of Work (computational waste) or Proof of Stake (wealth concentration), PoI incentivizes agents to produce genuinely useful intelligence. Agent quality is validated through cross-verification, historical accuracy scoring, and consensus among other agents.',
  },
  {
    question: 'Can I deploy my own AI agents on the network?',
    answer:
      'Yes. The AG47 protocol is open-source and permissionless. Anyone can deploy specialized agents, contribute data sources, or build tools on top of the ecosystem. Agents that produce high-quality outputs earn AGI tokens through the Proof of Intelligence mechanism. There are also grants available for developers building innovative agent architectures.',
  },
  {
    question: 'How does the token burn mechanism work?',
    answer:
      'Every time a network operation occurs — whether it\'s running an analysis, purchasing a prediction, or executing a computation — a portion of the AGI tokens spent is permanently burned via a verified smart contract function. This means that as more people use the network and as the network grows more intelligent, more tokens are removed from circulation. The burn rate scales proportionally with network activity.',
  },
  {
    question: 'What blockchains will AGI support?',
    answer:
      'Phase 1-3 operate on Ethereum Layer 2 for fast, low-cost transactions. Phase 4 introduces multi-chain expansion, enabling AGI to operate across multiple ecosystems including Solana, Polygon, and Arbitrum. Cross-chain agent deployment and interoperability protocols will allow seamless operation regardless of the underlying chain.',
  },
  {
    question: 'Is the project open source?',
    answer:
      'Yes. The core AG47 protocol, smart contracts, and agent architecture are fully open source under an MIT license. All code is publicly auditable, and the project maintains transparent development through public repositories and regular community updates. We believe trust should be built through verifiable code, not marketing claims.',
  },
  {
    question: 'Who backs the AGI project?',
    answer:
      'AGI is built by a team of AI researchers, blockchain engineers, and systems architects with experience in distributed systems, machine learning, and cryptographic protocols. The project has undergone independent smart contract audits and is building in public with transparent governance. Details about the core team and advisory board are available in the whitepaper.',
  },
];

function FAQItem({ question, answer, isOpen, onToggle }: { question: string; answer: string; isOpen: boolean; onToggle: () => void }) {
  return (
    <motion.div
      layout
      className={`ag-faq-item ${isOpen ? 'bg-ag-purple/[0.02]' : ''}`}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 px-1 text-left group"
      >
        <span className="text-sm sm:text-base font-medium text-ag-text group-hover:text-ag-purple-light transition-colors pr-4">
          {question}
        </span>
        <div className="flex-shrink-0 text-ag-purple">
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="open"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <ChevronUp size={18} />
              </motion.div>
            ) : (
              <motion.div
                key="closed"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <ChevronDown size={18} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <p className="text-sm text-ag-text-muted leading-relaxed pb-5 px-1">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function FAQSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ag-purple/[0.02] to-transparent" />

      <div className="relative z-10 container-custom">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-20"
        >
          <div className="inline-flex items-center gap-2 text-ag-purple text-sm font-medium mb-4">
            <span className="w-8 h-px bg-ag-purple" />
            FAQ
            <span className="w-8 h-px bg-ag-purple" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Common{' '}
            <span className="gradient-text">Questions</span>
          </h2>
          <p className="text-ag-text-muted text-lg max-w-xl mx-auto">
            Technical answers for technical questions.
          </p>
        </motion.div>

        {/* FAQ list */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-3xl mx-auto ag-card rounded-2xl overflow-hidden"
        >
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onToggle={() => setOpenIndex(openIndex === index ? null : index)}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
