import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Problem', href: '#problem' },
    { label: 'Solution', href: '#solution' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Tokenomics', href: '#tokenomics' },
    { label: 'Roadmap', href: '#roadmap' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#020208]/90 backdrop-blur-xl border-b border-ag-border/50 shadow-lg shadow-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="container-custom flex items-center justify-between h-16 lg:h-20">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="relative w-8 h-8">
            <svg viewBox="0 0 32 32" className="w-full h-full">
              <defs>
                <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8b5cf6" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
              </defs>
              <polygon points="16,2 30,28 2,28" fill="none" stroke="url(#logoGrad)" strokeWidth="2" />
              <circle cx="16" cy="17" r="4" fill="url(#logoGrad)" />
              <line x1="16" y1="13" x2="16" y2="8" stroke="url(#logoGrad)" strokeWidth="1.5" />
              <line x1="19.5" y1="19" x2="24" y2="23" stroke="url(#logoGrad)" strokeWidth="1.5" />
              <line x1="12.5" y1="19" x2="8" y2="23" stroke="url(#logoGrad)" strokeWidth="1.5" />
            </svg>
          </div>
          <span className="text-lg font-bold tracking-tight">
            <span className="gradient-text">AGI</span>
            <span className="text-ag-text-muted ml-1 text-sm font-normal hidden sm:inline">Intelligence Token</span>
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm text-ag-text-muted hover:text-ag-text px-3 py-2 rounded-lg hover:bg-ag-purple/5 transition-all duration-200"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA + Mobile toggle */}
        <div className="flex items-center gap-3">
          <a
            href="#get-started"
            className="hidden sm:inline-flex items-center gap-2 text-sm font-medium bg-gradient-to-r from-ag-purple to-ag-accent hover:from-ag-purple-light hover:to-ag-blue text-white px-5 py-2.5 rounded-xl transition-all duration-300 shadow-lg shadow-ag-purple/20 hover:shadow-ag-purple/40"
          >
            Launch App
          </a>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden text-ag-text-muted hover:text-ag-text p-2"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-ag-darker/95 backdrop-blur-xl border-t border-ag-border"
          >
            <div className="container-custom py-4 flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="text-ag-text-muted hover:text-ag-text px-4 py-3 rounded-lg hover:bg-ag-purple/5 transition-all"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#get-started"
                onClick={() => setMobileOpen(false)}
                className="mt-2 text-center text-sm font-medium bg-gradient-to-r from-ag-purple to-ag-accent text-white px-5 py-3 rounded-xl"
              >
                Launch App
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
