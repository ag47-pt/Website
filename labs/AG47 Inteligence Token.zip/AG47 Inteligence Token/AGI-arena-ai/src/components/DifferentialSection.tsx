import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { X, Check, Minus } from "lucide-react";

const comparisonData = [
  {
    feature: "Token Utility",
    speculative: { text: "None — pure speculation", status: "bad" as const },
    centralizedAI: { text: "Credits or subscription", status: "neutral" as const },
    agi: { text: "Native fuel for all operations", status: "good" as const },
  },
  {
    feature: "AI Model Access",
    speculative: { text: "No AI functionality", status: "bad" as const },
    centralizedAI: { text: "Proprietary, black-box", status: "neutral" as const },
    agi: { text: "Open, multi-agent, verifiable", status: "good" as const },
  },
  {
    feature: "Data Ownership",
    speculative: { text: "N/A", status: "bad" as const },
    centralizedAI: { text: "Platform owns your data", status: "bad" as const },
    agi: { text: "Users retain full ownership", status: "good" as const },
  },
  {
    feature: "Revenue Model",
    speculative: { text: "Greater fool theory", status: "bad" as const },
    centralizedAI: { text: "SaaS margins", status: "neutral" as const },
    agi: { text: "Network usage generates fees", status: "good" as const },
  },
  {
    feature: "Governance",
    speculative: { text: "Team-controlled", status: "bad" as const },
    centralizedAI: { text: "Corporate decisions", status: "neutral" as const },
    agi: { text: "Token-weighted DAO", status: "good" as const },
  },
  {
    feature: "Transparency",
    speculative: { text: "Anonymous teams common", status: "bad" as const },
    centralizedAI: { text: "Closed source", status: "neutral" as const },
    agi: { text: "On-chain verification", status: "good" as const },
  },
  {
    feature: "Scalability",
    speculative: { text: "N/A", status: "bad" as const },
    centralizedAI: { text: "Limited by infrastructure", status: "neutral" as const },
    agi: { text: "Distributed agent network", status: "good" as const },
  },
  {
    feature: "Censorship Resistance",
    speculative: { text: "N/A", status: "bad" as const },
    centralizedAI: { text: "Subject to restrictions", status: "bad" as const },
    agi: { text: "Fully decentralized", status: "good" as const },
  },
];

function StatusIcon({ status }: { status: "good" | "neutral" | "bad" }) {
  if (status === "good")
    return (
      <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
        <Check size={12} className="text-emerald-400" />
      </div>
    );
  if (status === "neutral")
    return (
      <div className="w-5 h-5 rounded-full bg-amber-500/10 flex items-center justify-center flex-shrink-0">
        <Minus size={12} className="text-amber-400" />
      </div>
    );
  return (
    <div className="w-5 h-5 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0">
      <X size={12} className="text-red-400" />
    </div>
  );
}

export default function DifferentialSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="differential" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-neon-blue uppercase tracking-[0.3em] mb-4 block">
            Why AGI
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Infrastructure, Not Hype
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            See how AG Intelligence Token compares to speculative tokens and
            centralized AI platforms across every dimension that matters.
          </p>
        </motion.div>

        {/* Comparison Table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass-card rounded-2xl overflow-hidden"
        >
          {/* Table Header */}
          <div className="grid grid-cols-4 gap-4 p-4 sm:p-6 border-b border-white/5 bg-white/[0.02]">
            <div className="text-xs font-mono text-white/30 uppercase tracking-wider">
              Feature
            </div>
            <div className="text-xs font-mono text-red-400/60 uppercase tracking-wider text-center">
              Speculative Tokens
            </div>
            <div className="text-xs font-mono text-amber-400/60 uppercase tracking-wider text-center">
              Centralized AI
            </div>
            <div className="text-xs font-mono text-emerald-400/60 uppercase tracking-wider text-center">
              AGI Token
            </div>
          </div>

          {/* Table Rows */}
          {comparisonData.map((row, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ duration: 0.4, delay: 0.3 + i * 0.05 }}
              className={`grid grid-cols-4 gap-4 p-4 sm:p-6 border-b border-white/5 last:border-0 hover:bg-white/[0.02] transition-colors ${
                i % 2 === 0 ? "" : "bg-white/[0.01]"
              }`}
            >
              <div className="text-sm font-medium text-white/60">
                {row.feature}
              </div>
              <div className="flex items-center gap-2 justify-center">
                <StatusIcon status={row.speculative.status} />
                <span className="text-xs text-white/30 hidden sm:inline">
                  {row.speculative.text}
                </span>
              </div>
              <div className="flex items-center gap-2 justify-center">
                <StatusIcon status={row.centralizedAI.status} />
                <span className="text-xs text-white/30 hidden sm:inline">
                  {row.centralizedAI.text}
                </span>
              </div>
              <div className="flex items-center gap-2 justify-center">
                <StatusIcon status={row.agi.status} />
                <span className="text-xs text-white/40 hidden sm:inline font-medium">
                  {row.agi.text}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12"
        >
          {[
            {
              emoji: "🏗️",
              title: "Infrastructure",
              description: "Not a meme — a protocol for decentralized intelligence computation.",
            },
            {
              emoji: "⚡",
              title: "Utility",
              description: "Every token has a purpose: pay for compute, access agents, govern the network.",
            },
            {
              emoji: "💰",
              title: "Functional Economy",
              description: "Real revenue from real usage. Deflationary mechanics tied to network growth.",
            },
          ].map((card, i) => (
            <div
              key={i}
              className="glass-card rounded-xl p-6 text-center group hover:border-neon-purple/20 transition-all duration-300"
            >
              <div className="text-3xl mb-4">{card.emoji}</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {card.title}
              </h3>
              <p className="text-sm text-white/40">{card.description}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
