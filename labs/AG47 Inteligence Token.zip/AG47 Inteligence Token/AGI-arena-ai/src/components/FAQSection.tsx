import { motion, useInView, AnimatePresence } from "framer-motion";
import { useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    question: "What exactly is the Cognitive Organism AG47?",
    answer:
      "AG47 is a decentralized network of autonomous AI agents that function as a single intelligent system. Each agent specializes in different domains — financial analysis, pattern recognition, natural language processing, etc. — and they collaborate through consensus mechanisms to produce intelligence outputs that are more accurate and comprehensive than any single model. Think of it as a distributed brain where each agent is a specialized neuron.",
  },
  {
    question: "How is AGI Token different from other AI-related crypto projects?",
    answer:
      "Most AI tokens are speculative assets with no real utility or connection to actual AI systems. AGI Token is fundamentally different: it's the native fuel required to operate the AG47 network. You need AGI tokens to submit analysis requests, access premium agents, participate in governance, and earn rewards. The token's value is directly tied to network usage, not speculation. Every transaction creates real demand.",
  },
  {
    question: "What is Proof of Intelligence and how does it work?",
    answer:
      "Proof of Intelligence (PoI) is our novel consensus mechanism that rewards AI agents based on the quality and accuracy of their contributions, not computational waste (PoW) or capital lock-up (PoS). When agents produce analysis outputs, other agents validate the quality. Agents that consistently produce accurate, useful intelligence earn higher rewards. Those that produce low-quality outputs see their rewards reduced. This creates a self-improving system where the network gets smarter over time.",
  },
  {
    question: "How are the AI agents trained and who controls them?",
    answer:
      "AI agents can be deployed by anyone — researchers, developers, institutions — using the AG47 SDK. Agents are trained on public and licensed data sources, and their training parameters are transparent and auditable. No single entity controls all agents. The protocol incentivizes diversity in agent architectures and data sources, which improves the overall intelligence quality through ensemble effects.",
  },
  {
    question: "Is the token deflationary? What prevents inflation?",
    answer:
      "Yes, AGI has built-in deflationary mechanics. 2% of every transaction fee is permanently burned, reducing total supply over time. Additionally, the token has a fixed maximum supply of 1 billion — no new tokens can ever be minted beyond this cap. As network usage grows, more tokens are burned, creating increasing scarcity proportional to adoption. Team and advisor tokens are locked with 4-year vesting to prevent dumps.",
  },
  {
    question: "What data sources does the network analyze?",
    answer:
      "The AG47 network can ingest data from virtually any source: real-time market data (crypto, equities, commodities), social media sentiment streams, on-chain analytics, news feeds, academic research papers, satellite imagery analysis, IoT sensor networks, and more. Data providers are also incentivized with AGI tokens, creating a growing and diverse data ecosystem.",
  },
  {
    question: "How can I participate in the network as a developer?",
    answer:
      "Developers can contribute in several ways: deploy custom AI agents using the AG47 SDK, build applications on top of the intelligence API, contribute to the open-source protocol, provide computational resources for agent execution, or create data connectors for new sources. All contributions that generate value for the network are rewarded with AGI tokens through the Proof of Intelligence mechanism.",
  },
  {
    question: "What are the risks I should be aware of?",
    answer:
      "We believe in transparent communication. Key risks include: smart contract vulnerabilities (mitigated by multiple audits), AI model accuracy limitations (mitigated by multi-agent consensus), regulatory uncertainty around AI and crypto, market volatility affecting token price, and the general technological risk of building novel systems. We recommend users conduct their own research and never invest more than they can afford to lose.",
  },
];

function FAQItem({
  question,
  answer,
  index,
  isOpen,
  onToggle,
}: {
  question: string;
  answer: string;
  index: number;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="border-b border-white/5 last:border-0"
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 sm:py-6 text-left group"
      >
        <span className="text-sm sm:text-base font-medium text-white/70 group-hover:text-white transition-colors pr-4">
          {question}
        </span>
        <ChevronDown
          size={18}
          className={`flex-shrink-0 text-white/30 transition-transform duration-300 ${
            isOpen ? "rotate-180 text-neon-purple" : ""
          }`}
        />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <p className="text-sm text-white/40 leading-relaxed pb-6 pr-8">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function FAQSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-white/40 uppercase tracking-[0.3em] mb-4 block">
            FAQ
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-white/40 max-w-xl mx-auto leading-relaxed">
            Honest answers to the questions that matter most.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass-card rounded-2xl px-6 sm:px-8"
        >
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              question={faq.question}
              answer={faq.answer}
              index={i}
              isOpen={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
