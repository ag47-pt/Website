import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Flame, Lock, Repeat, Wallet } from "lucide-react";

const distribution = [
  { label: "Community & Ecosystem", percentage: 40, color: "#00d4ff", description: "Mining rewards, airdrops, grants, and community incentives" },
  { label: "Development Fund", percentage: 20, color: "#a855f7", description: "Protocol development, research, and infrastructure" },
  { label: "Liquidity & Markets", percentage: 15, color: "#6366f1", description: "DEX liquidity, market making, and exchange listings" },
  { label: "Team & Advisors", percentage: 12, color: "#7c3aed", description: "4-year vesting with 12-month cliff" },
  { label: "Treasury Reserve", percentage: 8, color: "#06b6d4", description: "Strategic reserve for partnerships and emergencies" },
  { label: "Public Sale", percentage: 5, color: "#10b981", description: "Initial token offering and launch allocation" },
];

const mechanisms = [
  {
    icon: <Flame size={22} />,
    title: "Token Burn",
    description:
      "2% of every transaction fee is permanently burned, reducing total supply over time and creating deflationary pressure proportional to network usage.",
    stat: "2%",
    statLabel: "burn per tx",
    color: "text-orange-400",
    borderColor: "border-orange-500/20",
    bgColor: "bg-orange-500/5",
  },
  {
    icon: <Lock size={22} />,
    title: "Staking Mechanism",
    description:
      "Stake AGI tokens to earn rewards, participate in governance, and unlock premium network features. Minimum 30-day lock period with variable APY based on network activity.",
    stat: "8-15%",
    statLabel: "variable APY",
    color: "text-neon-purple",
    borderColor: "border-neon-purple/20",
    bgColor: "bg-neon-purple/5",
  },
  {
    icon: <Repeat size={22} />,
    title: "Mandatory Usage",
    description:
      "All network operations — analyses, predictions, agent access — require AGI tokens. This creates constant buy pressure from actual users, not speculators.",
    stat: "100%",
    statLabel: "utility-driven demand",
    color: "text-neon-blue",
    borderColor: "border-neon-blue/20",
    bgColor: "bg-neon-blue/5",
  },
  {
    icon: <Wallet size={22} />,
    title: "Vesting Schedules",
    description:
      "Team and advisor tokens are locked with a 12-month cliff and 4-year linear vesting. No insider dumps. Aligned incentives for long-term value creation.",
    stat: "4 Years",
    statLabel: "vesting period",
    color: "text-emerald-400",
    borderColor: "border-emerald-500/20",
    bgColor: "bg-emerald-500/5",
  },
];

export default function TokenomicsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="tokenomics" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute top-1/2 left-1/3 w-[500px] h-[500px] bg-neon-purple/5 rounded-full blur-[150px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-amber-400 uppercase tracking-[0.3em] mb-4 block">
            Tokenomics
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Designed for Sustainability
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            A carefully designed token economy that rewards real participation,
            penalizes speculation, and aligns incentives for long-term network health.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Token Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="glass-card rounded-2xl p-8"
          >
            <h3 className="text-xl font-bold text-white mb-6">Token Overview</h3>
            <div className="space-y-4">
              {[
                { label: "Token Name", value: "AG Intelligence Token" },
                { label: "Symbol", value: "AGI" },
                { label: "Network", value: "Ethereum (ERC-20) + Layer 2" },
                { label: "Total Supply", value: "1,000,000,000 AGI" },
                { label: "Initial Circulating", value: "150,000,000 AGI (15%)" },
                { label: "Decimals", value: "18" },
              ].map((item, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between py-3 border-b border-white/5 last:border-0"
                >
                  <span className="text-sm text-white/40">{item.label}</span>
                  <span className="text-sm font-medium text-white font-mono">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Distribution Chart */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-card rounded-2xl p-8"
          >
            <h3 className="text-xl font-bold text-white mb-6">Token Distribution</h3>
            <div className="space-y-4">
              {distribution.map((item, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-sm text-white/70">{item.label}</span>
                    </div>
                    <span className="text-sm font-bold font-mono text-white">
                      {item.percentage}%
                    </span>
                  </div>
                  <div className="relative h-2 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={inView ? { width: `${item.percentage}%` } : {}}
                      transition={{ duration: 1, delay: 0.3 + i * 0.1, ease: "easeOut" }}
                      className="absolute inset-y-0 left-0 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                  </div>
                  <p className="text-[11px] text-white/25 mt-1 ml-6">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Mechanisms */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {mechanisms.map((mech, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }}
              className="glass-card glass-card-hover rounded-2xl p-6 transition-all duration-500 group"
            >
              <div className="flex items-start gap-4">
                <div
                  className={`flex-shrink-0 w-11 h-11 rounded-xl ${mech.bgColor} border ${mech.borderColor} flex items-center justify-center ${mech.color}`}
                >
                  {mech.icon}
                </div>
                <div className="flex-1">
                  <h4 className="text-lg font-semibold text-white mb-2">
                    {mech.title}
                  </h4>
                  <p className="text-sm text-white/40 leading-relaxed mb-3">
                    {mech.description}
                  </p>
                  <div className="flex items-center gap-2 pt-3 border-t border-white/5">
                    <span className={`text-xl font-bold font-mono ${mech.color}`}>
                      {mech.stat}
                    </span>
                    <span className="text-[10px] text-white/25 uppercase tracking-wider">
                      {mech.statLabel}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
