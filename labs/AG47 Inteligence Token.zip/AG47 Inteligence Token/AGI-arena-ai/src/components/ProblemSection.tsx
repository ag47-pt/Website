import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Database, BrainCog, Lock, TrendingDown } from "lucide-react";

const problems = [
  {
    icon: <Database size={24} />,
    title: "Data Overload",
    description:
      "Every day, 2.5 quintillion bytes of data are created. 99% is never analyzed, creating massive blind spots in decision-making across industries.",
    stat: "2.5 EB/day",
    statLabel: "data created",
  },
  {
    icon: <BrainCog size={24} />,
    title: "No Structured Intelligence",
    description:
      "Raw data without structured analysis is noise. Organizations drown in information but starve for actionable intelligence and reliable predictions.",
    stat: "73%",
    statLabel: "decisions lack data backing",
  },
  {
    icon: <Lock size={24} />,
    title: "Centralized AI Monopoly",
    description:
      "A handful of corporations control AI infrastructure, models, and data pipelines. This creates single points of failure, bias, and restricted access.",
    stat: "5 Corps",
    statLabel: "control 90% of AI compute",
  },
  {
    icon: <TrendingDown size={24} />,
    title: "Poor Decision Outcomes",
    description:
      "Without distributed intelligence, critical decisions — financial, medical, geopolitical — rely on incomplete models and biased centralized systems.",
    stat: "$3.1T",
    statLabel: "annual cost of poor decisions",
  },
];

export default function ProblemSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="problem" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-neon-purple uppercase tracking-[0.3em] mb-4 block">
            The Problem
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Intelligence Is Broken
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            The world generates unprecedented amounts of data, yet our ability to
            transform it into meaningful intelligence remains fragmented,
            centralized, and fundamentally limited.
          </p>
        </motion.div>

        {/* Problem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {problems.map((problem, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * i }}
              className="glass-card glass-card-hover rounded-2xl p-8 transition-all duration-500 group cursor-default"
            >
              <div className="flex items-start gap-5">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/20 flex items-center justify-center text-red-400 group-hover:text-red-300 transition-colors">
                  {problem.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {problem.title}
                  </h3>
                  <p className="text-white/40 leading-relaxed text-sm mb-4">
                    {problem.description}
                  </p>
                  <div className="flex items-center gap-3 pt-3 border-t border-white/5">
                    <span className="text-2xl font-bold font-mono gradient-text">
                      {problem.stat}
                    </span>
                    <span className="text-xs text-white/30 uppercase tracking-wider">
                      {problem.statLabel}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
