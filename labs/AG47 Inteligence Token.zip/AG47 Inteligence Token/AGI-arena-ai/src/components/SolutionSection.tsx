import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Bot, Workflow, Coins, ShieldCheck, Layers, Zap } from "lucide-react";

const features = [
  {
    icon: <Bot size={22} />,
    title: "Autonomous AI Agents",
    description:
      "Specialized agents continuously analyze data streams, identify patterns, and generate structured intelligence reports without human intervention.",
  },
  {
    icon: <Workflow size={22} />,
    title: "Collective Reasoning",
    description:
      "Agents collaborate through consensus mechanisms, cross-validating findings and producing higher-confidence outputs than any single model.",
  },
  {
    icon: <Coins size={22} />,
    title: "Token-Powered Economy",
    description:
      "AGI token is the native fuel — used to request analyses, reward contributors, stake for governance, and access premium intelligence layers.",
  },
  {
    icon: <ShieldCheck size={22} />,
    title: "Verifiable Outputs",
    description:
      "Every analysis is cryptographically signed and auditable on-chain, ensuring transparency and enabling trustless intelligence markets.",
  },
  {
    icon: <Layers size={22} />,
    title: "Modular Architecture",
    description:
      "Plug in custom data sources, train specialized agents, or build applications on top of the intelligence layer through open APIs.",
  },
  {
    icon: <Zap size={22} />,
    title: "Real-Time Processing",
    description:
      "Distributed compute across the network enables near-instant analysis of complex datasets, from financial markets to scientific research.",
  },
];

export default function SolutionSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="solution" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-neon-purple/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-1/3 left-0 w-[400px] h-[400px] bg-neon-blue/5 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-neon-blue uppercase tracking-[0.3em] mb-4 block">
            The Solution
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Meet the Cognitive Organism{" "}
            <span className="gradient-text">AG47</span>
          </h2>
          <p className="text-lg text-white/40 max-w-3xl mx-auto leading-relaxed">
            A decentralized network of AI agents that work together as a single
            intelligent organism — analyzing, reasoning, and producing
            actionable intelligence at scale.
          </p>
        </motion.div>

        {/* Architecture Diagram */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass-card rounded-2xl p-8 sm:p-12 mb-16 relative overflow-hidden"
        >
          <div className="absolute inset-0 opacity-[0.02]" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, #a855f7 1px, transparent 1px),
                             radial-gradient(circle at 75% 75%, #00d4ff 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }} />
          
          <div className="relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
              {/* Input Layer */}
              <div className="text-center lg:text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-blue/10 border border-neon-blue/20 text-neon-blue text-xs font-mono mb-4">
                  <div className="w-1.5 h-1.5 rounded-full bg-neon-blue animate-pulse" />
                  INPUT LAYER
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Data Ingestion</h3>
                <p className="text-sm text-white/40 leading-relaxed">
                  Multi-source data feeds flow into the organism: market data, social signals,
                  on-chain analytics, research papers, and real-time event streams.
                </p>
                <div className="mt-4 flex flex-wrap gap-2 justify-center lg:justify-start">
                  {["APIs", "Oracles", "Feeds", "Scrapers"].map((s) => (
                    <span key={s} className="px-2 py-1 text-[10px] font-mono text-white/30 border border-white/10 rounded">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Core */}
              <div className="text-center">
                <div className="relative inline-block">
                  <div className="w-40 h-40 mx-auto rounded-full border-2 border-neon-purple/30 flex items-center justify-center relative">
                    <div className="absolute inset-2 rounded-full border border-neon-indigo/20 animate-spin" style={{ animationDuration: '20s' }} />
                    <div className="absolute inset-4 rounded-full border border-neon-blue/20 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-neon-purple/20 to-neon-blue/20 flex items-center justify-center">
                      <span className="text-2xl font-bold font-mono gradient-text">AG47</span>
                    </div>
                  </div>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-purple/10 border border-neon-purple/20 text-neon-purple text-xs font-mono mt-4 mb-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-neon-purple animate-pulse" />
                  PROCESSING CORE
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Agent Network</h3>
                <p className="text-sm text-white/40 leading-relaxed max-w-xs mx-auto">
                  Autonomous agents analyze, cross-validate, debate, and reach consensus on intelligence outputs.
                </p>
              </div>

              {/* Output Layer */}
              <div className="text-center lg:text-right">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono mb-4">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  OUTPUT LAYER
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Intelligence Delivery</h3>
                <p className="text-sm text-white/40 leading-relaxed">
                  Structured predictions, risk assessments, trend analyses, and actionable reports
                  delivered via API, dashboard, or smart contracts.
                </p>
                <div className="mt-4 flex flex-wrap gap-2 justify-center lg:justify-end">
                  {["Reports", "Predictions", "Alerts", "Signals"].map((s) => (
                    <span key={s} className="px-2 py-1 text-[10px] font-mono text-white/30 border border-white/10 rounded">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Connecting Lines (Desktop) */}
            <div className="hidden lg:block absolute top-1/2 left-[33%] right-[33%] -translate-y-1/2 h-px">
              <div className="absolute left-0 w-full h-px bg-gradient-to-r from-neon-blue/30 via-neon-purple/30 to-emerald-500/30" />
            </div>
          </div>
        </motion.div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="glass-card glass-card-hover rounded-xl p-6 transition-all duration-500 group cursor-default"
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-blue/10 to-neon-purple/10 border border-neon-purple/20 flex items-center justify-center text-neon-blue group-hover:text-neon-purple transition-colors mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-white/40 leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
