import { motion } from "framer-motion";
import { ArrowRight, FileText, Activity, Cpu, Network } from "lucide-react";
import AnimatedCounter from "./AnimatedCounter";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-neon-purple/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-neon-blue/10 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-indigo/5 rounded-full blur-[150px]" />
      </div>

      {/* Grid Pattern */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), 
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-5xl mx-auto">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-neon-purple/30 bg-neon-purple/5 mb-8"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-medium text-white/70 tracking-wide uppercase">
              Cognitive Organism AG47 — Live on Testnet
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.1] mb-6"
          >
            <span className="text-white">The Infrastructure Layer for</span>
            <br />
            <span className="gradient-text">Decentralized Intelligence</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg sm:text-xl text-white/50 max-w-3xl mx-auto mb-10 leading-relaxed"
          >
            AGI Token powers a network of autonomous AI agents that analyze data,
            generate predictions, and produce collective intelligence — all
            decentralized, verifiable, and owned by the community.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20"
          >
            <a
              href="#solution"
              className="group relative px-8 py-4 rounded-xl text-base font-semibold text-white overflow-hidden w-full sm:w-auto"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-neon-blue via-neon-purple to-neon-indigo opacity-90 group-hover:opacity-100 transition-opacity" />
              <span className="relative flex items-center justify-center gap-2">
                Get Started
                <ArrowRight
                  size={18}
                  className="group-hover:translate-x-1 transition-transform"
                />
              </span>
            </a>
            <a
              href="#"
              className="group px-8 py-4 rounded-xl text-base font-semibold text-white/80 hover:text-white border border-white/10 hover:border-white/20 transition-all w-full sm:w-auto flex items-center justify-center gap-2 bg-white/[0.02] hover:bg-white/[0.05]"
            >
              <FileText size={18} />
              Read Whitepaper
            </a>
          </motion.div>

          {/* Live Stats */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto"
          >
            <StatCard
              icon={<Activity size={18} />}
              value={2847593}
              label="Analyses Processed"
              suffix=""
            />
            <StatCard
              icon={<Cpu size={18} />}
              value={1284}
              label="Active AI Agents"
              suffix=""
            />
            <StatCard
              icon={<Network size={18} />}
              value={47}
              label="Data Sources"
              suffix="+"
            />
            <StatCard
              icon={<Activity size={18} />}
              value={99.7}
              label="Network Uptime"
              suffix="%"
              decimals={1}
            />
          </motion.div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-dark-900 to-transparent" />
    </section>
  );
}

function StatCard({
  icon,
  value,
  label,
  suffix = "",
  decimals = 0,
}: {
  icon: React.ReactNode;
  value: number;
  label: string;
  suffix?: string;
  decimals?: number;
}) {
  return (
    <div className="glass-card rounded-xl p-4 text-center group hover:border-neon-purple/20 transition-all duration-300">
      <div className="flex items-center justify-center gap-2 mb-2 text-neon-blue/70">
        {icon}
      </div>
      <div className="text-2xl sm:text-3xl font-bold text-white mb-1 font-mono">
        <AnimatedCounter end={value} decimals={decimals} />
        {suffix}
      </div>
      <div className="text-xs text-white/40 uppercase tracking-wider">{label}</div>
    </div>
  );
}
