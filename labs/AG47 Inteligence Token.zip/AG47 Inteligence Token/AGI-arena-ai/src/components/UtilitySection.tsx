import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  KeyRound,
  BarChart3,
  Eye,
  Server,
  Vote,
  Gift,
} from "lucide-react";

const utilities = [
  {
    icon: <KeyRound size={22} />,
    title: "Access Premium Agents",
    description:
      "Unlock specialized AI agents with domain expertise in quantitative finance, biotech research, geopolitical analysis, and more.",
    tag: "Access",
  },
  {
    icon: <BarChart3 size={22} />,
    title: "Execute Advanced Analyses",
    description:
      "Run complex multi-agent analyses, backtesting scenarios, and cross-domain correlation studies powered by the full AG47 network.",
    tag: "Compute",
  },
  {
    icon: <Eye size={22} />,
    title: "Purchase Predictions",
    description:
      "Access the intelligence marketplace to buy high-confidence predictions, signals, and structured intelligence reports.",
    tag: "Intelligence",
  },
  {
    icon: <Server size={22} />,
    title: "Pay for Processing",
    description:
      "Use tokens to pay for computational resources, data processing, and custom model training within the decentralized network.",
    tag: "Infrastructure",
  },
  {
    icon: <Vote size={22} />,
    title: "Governance Participation",
    description:
      "Stake AGI tokens to vote on protocol upgrades, agent parameters, fee structures, and treasury allocation decisions.",
    tag: "Governance",
  },
  {
    icon: <Gift size={22} />,
    title: "Contribution Rewards",
    description:
      "Earn AGI tokens by contributing data, training agents, validating outputs, or providing computational resources to the network.",
    tag: "Rewards",
  },
];

export default function UtilitySection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="utility" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute bottom-1/3 right-1/4 w-[500px] h-[500px] bg-neon-blue/5 rounded-full blur-[130px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-emerald-400 uppercase tracking-[0.3em] mb-4 block">
            Token Utility
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Real Utility, Not Speculation
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            Every AGI token represents actual access and value within the
            ecosystem. The token is required to interact with the network —
            creating organic, usage-driven demand.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {utilities.map((utility, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="glass-card glass-card-hover rounded-2xl p-6 transition-all duration-500 group cursor-default relative overflow-hidden"
            >
              {/* Subtle corner glow */}
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-neon-purple/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative z-10">
                <div className="flex items-center justify-between mb-5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-neon-blue/10 to-neon-purple/10 border border-white/5 flex items-center justify-center text-neon-blue group-hover:text-neon-purple transition-colors">
                    {utility.icon}
                  </div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-white/20 px-2 py-1 rounded bg-white/[0.03] border border-white/5">
                    {utility.tag}
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {utility.title}
                </h3>
                <p className="text-sm text-white/40 leading-relaxed">
                  {utility.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Token Flow Summary */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 glass-card rounded-2xl p-8 sm:p-10"
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="text-center lg:text-left">
              <div className="text-xs font-mono text-neon-purple uppercase tracking-wider mb-2">
                Token Lifecycle
              </div>
              <h3 className="text-2xl font-bold text-white">
                Circular Economy
              </h3>
            </div>
            <div className="lg:col-span-2 flex flex-wrap items-center justify-center gap-3 text-sm">
              {[
                { label: "Users Pay", color: "text-neon-blue" },
                { label: "→", color: "text-white/20" },
                { label: "Agents Earn", color: "text-neon-purple" },
                { label: "→", color: "text-white/20" },
                { label: "Tokens Staked", color: "text-neon-indigo" },
                { label: "→", color: "text-white/20" },
                { label: "Fees Burned", color: "text-amber-400" },
                { label: "→", color: "text-white/20" },
                { label: "Supply Decreases", color: "text-emerald-400" },
              ].map((item, i) => (
                <span
                  key={i}
                  className={`${item.color} font-medium ${item.label === "→" ? "text-lg" : "px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/5"}`}
                >
                  {item.label}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
