import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { User, Search, Cpu, FileCheck, Coins, ArrowDown } from "lucide-react";

const steps = [
  {
    icon: <User size={24} />,
    number: "01",
    title: "User Submits Request",
    description:
      "A user or application submits an intelligence request — a question, dataset, or analysis task — and deposits AGI tokens as payment.",
    detail: "Requests are encrypted and routed to the most relevant agent cluster.",
    color: "from-neon-blue to-cyan-400",
    borderColor: "border-neon-blue/30",
    bgColor: "bg-neon-blue/5",
  },
  {
    icon: <Search size={24} />,
    number: "02",
    title: "Agents Analyze & Process",
    description:
      "Specialized AI agents within the AG47 organism independently analyze the request using diverse models, data sources, and reasoning strategies.",
    detail: "Multiple agents work in parallel to ensure comprehensive coverage.",
    color: "from-neon-purple to-violet-400",
    borderColor: "border-neon-purple/30",
    bgColor: "bg-neon-purple/5",
  },
  {
    icon: <Cpu size={24} />,
    number: "03",
    title: "Consensus & Validation",
    description:
      "Agents cross-validate results through a consensus mechanism. Outliers are flagged, high-confidence outputs are weighted, and a final report is compiled.",
    detail: "This is the Proof of Intelligence layer — quality determines rewards.",
    color: "from-neon-indigo to-blue-400",
    borderColor: "border-neon-indigo/30",
    bgColor: "bg-neon-indigo/5",
  },
  {
    icon: <FileCheck size={24} />,
    number: "04",
    title: "Intelligence Delivered",
    description:
      "The verified intelligence output — predictions, reports, risk scores — is delivered to the user via API, webhook, or on-chain settlement.",
    detail: "Results include confidence scores and full audit trails.",
    color: "from-emerald-400 to-green-400",
    borderColor: "border-emerald-500/30",
    bgColor: "bg-emerald-500/5",
  },
  {
    icon: <Coins size={24} />,
    number: "05",
    title: "Tokens Distributed",
    description:
      "AGI tokens are distributed to contributing agents, data providers, and validators based on their Proof of Intelligence score and contribution quality.",
    detail: "A portion of tokens is burned, creating deflationary pressure.",
    color: "from-amber-400 to-yellow-400",
    borderColor: "border-amber-500/30",
    bgColor: "bg-amber-500/5",
  },
];

export default function HowItWorksSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="how-it-works" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-neon-indigo/5 rounded-full blur-[150px]" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-xs font-mono text-neon-indigo uppercase tracking-[0.3em] mb-4 block">
            How It Works
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            From Request to Intelligence
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            A transparent, verifiable pipeline that transforms raw data into
            actionable intelligence through decentralized AI consensus.
          </p>
        </motion.div>

        {/* Proof of Intelligence Box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass-card rounded-2xl p-6 sm:p-8 mb-16 border-neon-purple/20"
        >
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-neon-purple/20 to-neon-blue/20 border border-neon-purple/30 flex items-center justify-center">
              <span className="text-lg">🧠</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                Proof of Intelligence
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neon-purple/10 border border-neon-purple/20 text-neon-purple">
                  PoI
                </span>
              </h3>
              <p className="text-sm text-white/40 leading-relaxed">
                Unlike Proof of Work or Proof of Stake, our Proof of Intelligence
                mechanism rewards agents based on the <strong className="text-white/60">quality and accuracy</strong> of
                their contributions. Agents that produce useful, validated
                intelligence earn more tokens. Low-quality outputs are
                penalized, creating a self-improving system where the network
                gets smarter over time.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Steps */}
        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-6 sm:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-neon-blue/30 via-neon-purple/30 to-amber-400/30 hidden sm:block" />

          <div className="space-y-8">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.15 * i }}
                className="relative"
              >
                <div className="flex items-start gap-6 sm:gap-8">
                  {/* Icon */}
                  <div
                    className={`relative z-10 flex-shrink-0 w-12 h-12 sm:w-16 sm:h-16 rounded-2xl ${step.bgColor} border ${step.borderColor} flex items-center justify-center`}
                  >
                    <div className={`bg-gradient-to-br ${step.color} bg-clip-text`}>
                      {step.icon}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 glass-card glass-card-hover rounded-xl p-6 transition-all duration-300">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-xs font-mono text-white/20">{step.number}</span>
                      <h3 className="text-lg font-semibold text-white">{step.title}</h3>
                    </div>
                    <p className="text-sm text-white/40 leading-relaxed mb-3">
                      {step.description}
                    </p>
                    <p className="text-xs text-white/25 italic border-t border-white/5 pt-3">
                      {step.detail}
                    </p>
                  </div>
                </div>

                {/* Arrow between steps */}
                {i < steps.length - 1 && (
                  <div className="flex justify-center sm:ml-8 py-2">
                    <ArrowDown size={16} className="text-white/10" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
