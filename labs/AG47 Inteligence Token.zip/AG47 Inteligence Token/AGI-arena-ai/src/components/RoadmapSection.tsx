import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { FlaskConical, Database, Rocket, Globe } from "lucide-react";

const phases = [
  {
    icon: <FlaskConical size={22} />,
    phase: "Phase 1",
    title: "Cognitive MVP",
    timeline: "Q1 – Q2 2025",
    status: "active" as const,
    statusLabel: "In Progress",
    description:
      "Launch the foundational cognitive organism with core AI agent capabilities and initial token deployment.",
    milestones: [
      "Core AG47 agent framework deployed",
      "Token smart contract audit & launch",
      "First 50 specialized AI agents operational",
      "Developer SDK (alpha) released",
      "Testnet intelligence marketplace live",
      "Community governance framework established",
    ],
    color: "from-neon-blue to-cyan-400",
    borderColor: "border-neon-blue/30",
    glowColor: "bg-neon-blue/10",
  },
  {
    icon: <Database size={22} />,
    phase: "Phase 2",
    title: "Real-World Data Integration",
    timeline: "Q3 – Q4 2025",
    status: "upcoming" as const,
    statusLabel: "Upcoming",
    description:
      "Connect the organism to live data feeds and establish partnerships for real-world intelligence applications.",
    milestones: [
      "Integration with 20+ real-time data sources",
      "Oracle network for on-chain data verification",
      "Partnerships with DeFi protocols",
      "Proof of Intelligence v2 consensus mechanism",
      "Intelligence marketplace (mainnet)",
      "1,000+ active AI agents in the network",
    ],
    color: "from-neon-purple to-violet-400",
    borderColor: "border-neon-purple/30",
    glowColor: "bg-neon-purple/10",
  },
  {
    icon: <Rocket size={22} />,
    phase: "Phase 3",
    title: "Automation & Execution",
    timeline: "Q1 – Q2 2026",
    status: "planned" as const,
    statusLabel: "Planned",
    description:
      "Enable agents to not just analyze but autonomously execute strategies and automate complex workflows.",
    milestones: [
      "Autonomous execution layer for DeFi strategies",
      "Cross-domain agent collaboration protocols",
      "Enterprise API and B2B partnerships",
      "Advanced prediction market integration",
      "Agent training marketplace",
      "Governance v2 with delegation",
    ],
    color: "from-neon-indigo to-blue-400",
    borderColor: "border-neon-indigo/30",
    glowColor: "bg-neon-indigo/10",
  },
  {
    icon: <Globe size={22} />,
    phase: "Phase 4",
    title: "Multi-Chain Expansion",
    timeline: "Q3 2026+",
    status: "planned" as const,
    statusLabel: "Planned",
    description:
      "Expand the AG47 organism across multiple blockchains and establish AGI as the standard for decentralized intelligence.",
    milestones: [
      "Cross-chain deployment (Solana, Arbitrum, Base)",
      "Inter-chain intelligence routing",
      "10,000+ active AI agents globally",
      "Self-evolving agent architectures",
      "Institutional-grade intelligence products",
      "Full decentralization of protocol governance",
    ],
    color: "from-emerald-400 to-green-400",
    borderColor: "border-emerald-500/30",
    glowColor: "bg-emerald-500/10",
  },
];

function StatusBadge({ status, label }: { status: string; label: string }) {
  const styles = {
    active:
      "bg-emerald-500/10 border-emerald-500/30 text-emerald-400",
    upcoming:
      "bg-amber-500/10 border-amber-500/30 text-amber-400",
    planned:
      "bg-white/5 border-white/10 text-white/40",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-mono uppercase tracking-wider ${
        styles[status as keyof typeof styles]
      }`}
    >
      {status === "active" && (
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
      )}
      {label}
    </span>
  );
}

export default function RoadmapSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="roadmap" className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute top-1/2 right-1/4 w-[500px] h-[500px] bg-neon-indigo/5 rounded-full blur-[150px]" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-neon-indigo uppercase tracking-[0.3em] mb-4 block">
            Roadmap
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Building in Public
          </h2>
          <p className="text-lg text-white/40 max-w-2xl mx-auto leading-relaxed">
            A pragmatic roadmap focused on delivering real technology milestones,
            not marketing promises.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-4 sm:left-6 top-0 bottom-0 w-px bg-gradient-to-b from-neon-blue/30 via-neon-purple/20 to-emerald-500/20" />

          <div className="space-y-10">
            {phases.map((phase, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.15 * i }}
                className="relative pl-14 sm:pl-20"
              >
                {/* Timeline Dot */}
                <div
                  className={`absolute left-0 sm:left-2 top-6 w-8 h-8 sm:w-8 sm:h-8 rounded-full ${phase.glowColor} border ${phase.borderColor} flex items-center justify-center z-10`}
                >
                  <div
                    className={`w-3 h-3 rounded-full bg-gradient-to-br ${phase.color}`}
                  />
                </div>

                <div className="glass-card glass-card-hover rounded-2xl p-6 sm:p-8 transition-all duration-500">
                  {/* Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-xs font-mono text-white/20">
                          {phase.phase}
                        </span>
                        <StatusBadge
                          status={phase.status}
                          label={phase.statusLabel}
                        />
                      </div>
                      <h3 className="text-xl font-bold text-white">
                        {phase.title}
                      </h3>
                    </div>
                    <span className="text-xs font-mono text-white/30 bg-white/[0.03] px-3 py-1.5 rounded-lg border border-white/5 whitespace-nowrap">
                      {phase.timeline}
                    </span>
                  </div>

                  <p className="text-sm text-white/40 leading-relaxed mb-5">
                    {phase.description}
                  </p>

                  {/* Milestones Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {phase.milestones.map((milestone, j) => (
                      <div
                        key={j}
                        className="flex items-center gap-2 text-sm"
                      >
                        <div
                          className={`w-1 h-1 rounded-full bg-gradient-to-r ${phase.color} flex-shrink-0`}
                        />
                        <span className="text-white/30 text-xs">
                          {milestone}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
