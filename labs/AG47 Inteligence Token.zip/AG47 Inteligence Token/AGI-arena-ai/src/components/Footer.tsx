export default function Footer() {
  return (
    <footer className="relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-8 h-8">
                <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-neon-blue via-neon-purple to-neon-indigo" />
                <div className="absolute inset-[2px] rounded-[6px] bg-dark-900 flex items-center justify-center">
                  <span className="text-xs font-bold font-mono gradient-text">AG</span>
                </div>
              </div>
              <span className="text-white font-semibold text-sm">
                AG Intelligence
              </span>
            </div>
            <p className="text-xs text-white/30 leading-relaxed max-w-xs">
              Decentralized intelligence infrastructure for the next era of
              AI-driven decision making.
            </p>
          </div>

          {/* Protocol */}
          <div>
            <h4 className="text-xs font-mono text-white/50 uppercase tracking-wider mb-4">
              Protocol
            </h4>
            <ul className="space-y-2">
              {["Documentation", "Whitepaper", "GitHub", "SDK", "API Reference"].map(
                (link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-white/30 hover:text-white transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Community */}
          <div>
            <h4 className="text-xs font-mono text-white/50 uppercase tracking-wider mb-4">
              Community
            </h4>
            <ul className="space-y-2">
              {["Discord", "Telegram", "X (Twitter)", "Forum", "Blog"].map(
                (link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-white/30 hover:text-white transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-xs font-mono text-white/50 uppercase tracking-wider mb-4">
              Resources
            </h4>
            <ul className="space-y-2">
              {[
                "Tokenomics",
                "Audits",
                "Brand Assets",
                "Bug Bounty",
                "Contact",
              ].map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-sm text-white/30 hover:text-white transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/20">
            © 2025 AG Intelligence Token. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a
              href="#"
              className="text-xs text-white/20 hover:text-white/40 transition-colors"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="text-xs text-white/20 hover:text-white/40 transition-colors"
            >
              Terms of Service
            </a>
            <a
              href="#"
              className="text-xs text-white/20 hover:text-white/40 transition-colors"
            >
              Cookie Policy
            </a>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-8 p-4 rounded-lg bg-white/[0.02] border border-white/5">
          <p className="text-[10px] text-white/15 leading-relaxed">
            <strong className="text-white/25">Disclaimer:</strong> AG Intelligence Token (AGI) is a utility token
            designed for use within the AG47 ecosystem. It is not a security,
            investment contract, or financial instrument. Token value may
            fluctuate and past performance does not guarantee future results.
            Users should conduct their own research and consult professional
            advisors before participating. This website does not constitute
            financial advice.
          </p>
        </div>
      </div>
    </footer>
  );
}
