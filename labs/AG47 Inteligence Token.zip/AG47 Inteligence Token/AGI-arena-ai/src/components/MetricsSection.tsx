import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import AnimatedCounter from "./AnimatedCounter";

interface LiveMetric {
  label: string;
  value: number;
  suffix: string;
  prefix: string;
  decimals: number;
  change: string;
  positive: boolean;
}

const baseMetrics: LiveMetric[] = [
  {
    label: "Total Analyses Processed",
    value: 2847593,
    suffix: "",
    prefix: "",
    decimals: 0,
    change: "+12,847 today",
    positive: true,
  },
  {
    label: "Active AI Agents",
    value: 1284,
    suffix: "",
    prefix: "",
    decimals: 0,
    change: "+47 this week",
    positive: true,
  },
  {
    label: "Network Accuracy Score",
    value: 94.7,
    suffix: "%",
    prefix: "",
    decimals: 1,
    change: "+0.3% improvement",
    positive: true,
  },
  {
    label: "Tokens Burned",
    value: 4217830,
    suffix: "",
    prefix: "",
    decimals: 0,
    change: "deflationary ↓",
    positive: true,
  },
  {
    label: "Active Stakers",
    value: 18429,
    suffix: "",
    prefix: "",
    decimals: 0,
    change: "+234 this week",
    positive: true,
  },
  {
    label: "Total Value Locked",
    value: 47.2,
    suffix: "M",
    prefix: "$",
    decimals: 1,
    change: "+$2.1M this month",
    positive: true,
  },
];

export default function MetricsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [tick, setTick] = useState(0);

  // Simulate live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative py-24 sm:py-32">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute bottom-1/3 left-1/3 w-[500px] h-[500px] bg-neon-blue/5 rounded-full blur-[150px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-neon-blue uppercase tracking-[0.3em] mb-4 block">
            Network Metrics
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Live Network Dashboard
          </h2>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-emerald-400 font-mono">
              LIVE — Last updated {tick > 0 ? `${tick * 5}s ago` : "just now"}
            </span>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {baseMetrics.map((metric, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="glass-card rounded-xl p-5 sm:p-6 group hover:border-neon-purple/20 transition-all duration-300"
            >
              <div className="text-xs text-white/30 uppercase tracking-wider mb-3 font-mono">
                {metric.label}
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white font-mono mb-2">
                {metric.prefix}
                <AnimatedCounter end={metric.value} decimals={metric.decimals} />
                {metric.suffix}
              </div>
              <div
                className={`text-xs font-mono ${
                  metric.positive ? "text-emerald-400/60" : "text-red-400/60"
                }`}
              >
                {metric.change}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mini Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-8 glass-card rounded-2xl p-6 sm:p-8"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-sm font-mono text-white/40 uppercase tracking-wider">
              Agent Activity — Last 24h
            </h3>
            <div className="flex items-center gap-4 text-[10px] font-mono text-white/30">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-neon-blue" />
                Analyses
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-neon-purple" />
                Predictions
              </div>
            </div>
          </div>

          {/* Simulated Chart */}
          <div className="flex items-end gap-1 h-32 sm:h-40">
            {Array.from({ length: 48 }).map((_, i) => {
              const height1 = 30 + Math.sin(i * 0.3) * 20 + Math.random() * 30;
              const height2 = 20 + Math.cos(i * 0.4) * 15 + Math.random() * 20;
              return (
                <div key={i} className="flex-1 flex flex-col gap-0.5 items-stretch justify-end h-full">
                  <div
                    className="rounded-t-sm bg-neon-blue/40 transition-all duration-500"
                    style={{ height: `${height1}%` }}
                  />
                  <div
                    className="rounded-b-sm bg-neon-purple/30"
                    style={{ height: `${height2}%` }}
                  />
                </div>
              );
            })}
          </div>

          <div className="flex justify-between mt-3 text-[10px] font-mono text-white/20">
            <span>00:00</span>
            <span>06:00</span>
            <span>12:00</span>
            <span>18:00</span>
            <span>23:59</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
