import ParticleNetwork from "./components/ParticleNetwork";
import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import ProblemSection from "./components/ProblemSection";
import SolutionSection from "./components/SolutionSection";
import HowItWorksSection from "./components/HowItWorksSection";
import UtilitySection from "./components/UtilitySection";
import TokenomicsSection from "./components/TokenomicsSection";
import DifferentialSection from "./components/DifferentialSection";
import RoadmapSection from "./components/RoadmapSection";
import MetricsSection from "./components/MetricsSection";
import FAQSection from "./components/FAQSection";
import CTASection from "./components/CTASection";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-dark-900 text-white noise-bg">
      <ParticleNetwork />
      <Navbar />
      <main>
        <HeroSection />
        <ProblemSection />
        <SolutionSection />
        <HowItWorksSection />
        <UtilitySection />
        <TokenomicsSection />
        <DifferentialSection />
        <MetricsSection />
        <RoadmapSection />
        <FAQSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
