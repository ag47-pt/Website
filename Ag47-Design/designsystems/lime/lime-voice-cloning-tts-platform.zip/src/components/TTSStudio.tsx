'use client';

import React, { useState, useEffect } from 'react';
import {
  Wand2,
  Play,
  Pause,
  Download,
  Copy,
  Trash2,
  Sliders,
  Mic,
  Volume2,
  Sparkles,
  Zap,
  Info,
  Layers,
  Check,
  Music,
  Clock,
  Square,
} from 'lucide-react';
import { speakTextWebSpeech, stopSpeech, createAudioBlobFromText } from '@/lib/audioSynth';

export interface VoiceModel {
  id: number;
  name: string;
  description: string;
  category: string;
  language: string;
  gender: string;
  age: string;
  tags: string[];
  isPreset: boolean;
  avatarUrl?: string;
  qualityScore: number;
  noiseLevel: string;
  clarityScore: number;
  stabilityDefault: number;
  similarityDefault: number;
  pitchShiftDefault: number;
  speedDefault: number;
}

interface TTSStudioProps {
  voices: VoiceModel[];
  selectedVoiceId?: number;
  onSelectVoice: (id: number) => void;
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const TTSStudio: React.FC<TTSStudioProps> = ({
  voices,
  selectedVoiceId,
  onSelectVoice,
  addToast,
}) => {
  // Active selected voice
  const activeVoice = voices.find((v) => v.id === selectedVoiceId) || voices[0] || null;

  // Form parameters
  const [text, setText] = useState(
    'O Lima Voice Engine transforma qualquer amostra de áudio em um modelo de fala com controle total de emoção, velocidade e tonalidade.'
  );
  const [emotion, setEmotion] = useState('neutral');
  const [speed, setSpeed] = useState(1.0);
  const [pitch, setPitch] = useState(0.0);
  const [stability, setStability] = useState(75);
  const [similarity, setSimilarity] = useState(85);

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [latestGen, setLatestGen] = useState<any>(null);
  const [isPlayingCurrent, setIsPlayingCurrent] = useState(false);

  // History state
  const [history, setHistory] = useState<any[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [playingHistoryId, setPlayingHistoryId] = useState<number | null>(null);

  // Fetch history from API
  const fetchHistory = async () => {
    setLoadingHistory(true);
    try {
      const res = await fetch('/api/tts/history');
      const data = await res.json();
      if (data.success) {
        setHistory(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  // Sync default sliders when voice changes
  useEffect(() => {
    if (activeVoice) {
      setStability(activeVoice.stabilityDefault || 75);
      setSimilarity(activeVoice.similarityDefault || 85);
      setPitch(activeVoice.pitchShiftDefault || 0);
      setSpeed(activeVoice.speedDefault || 1.0);
    }
  }, [selectedVoiceId]);

  // Insert SSML or Expression tags
  const insertTag = (tag: string) => {
    setText((prev) => prev + ` ${tag} `);
  };

  // Trigger speech synthesis
  const handleGenerateTTS = async () => {
    if (!activeVoice) {
      addToast('Nenhuma voz selecionada', 'Escolha uma voz para continuar.', 'warning');
      return;
    }
    if (!text.trim()) {
      addToast('Texto vazio', 'Digite o texto que deseja converter em áudio.', 'warning');
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch('/api/tts/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceId: activeVoice.id,
          text,
          language: activeVoice.language,
          emotion,
          speed,
          pitch,
          stability,
          similarity,
        }),
      });

      const result = await res.json();
      if (result.success) {
        setLatestGen(result.data);
        addToast('Áudio gerado!', 'Síntese de voz finalizada com sucesso.', 'success');
        fetchHistory();

        // Autoplay generated audio via Web Speech
        setIsPlayingCurrent(true);
        speakTextWebSpeech(text, {
          lang: activeVoice.language,
          pitch: pitch,
          rate: speed,
          onEnd: () => setIsPlayingCurrent(false),
        });
      } else {
        addToast('Erro na síntese', result.error || 'Tente novamente.', 'error');
      }
    } catch (err) {
      console.error(err);
      addToast('Erro ao sintetizar', 'Não foi possível conectar ao servidor.', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  // Play current synthesized speech
  const togglePlayCurrent = () => {
    if (isPlayingCurrent) {
      stopSpeech();
      setIsPlayingCurrent(false);
    } else {
      setIsPlayingCurrent(true);
      speakTextWebSpeech(latestGen ? latestGen.text : text, {
        lang: activeVoice?.language || 'pt-BR',
        pitch: pitch,
        rate: speed,
        onEnd: () => setIsPlayingCurrent(false),
      });
    }
  };

  // Play item from history
  const togglePlayHistory = (item: any) => {
    if (playingHistoryId === item.id) {
      stopSpeech();
      setPlayingHistoryId(null);
    } else {
      stopSpeech();
      setPlayingHistoryId(item.id);
      speakTextWebSpeech(item.text, {
        lang: item.language || 'pt-BR',
        pitch: item.pitch || 0,
        rate: item.speed || 1.0,
        onEnd: () => setPlayingHistoryId(null),
      });
    }
  };

  // Download synthesized audio as WAV file
  const handleDownloadWav = async (itemText?: string) => {
    const textToSynth = itemText || text;
    try {
      addToast('Gerando WAV...', 'Preparando arquivo de áudio para download.', 'info');
      const blob = await createAudioBlobFromText(textToSynth, pitch, speed);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lima_voice_${activeVoice?.name || 'speech'}_${Date.now()}.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      addToast('Download concluído!', 'Arquivo WAV salvo com sucesso.', 'success');
    } catch (err) {
      console.error(err);
      addToast('Erro no download', 'Falha ao processar arquivo WAV.', 'error');
    }
  };

  // Delete history item
  const handleDeleteHistory = async (id: number) => {
    try {
      const res = await fetch(`/api/tts/history/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setHistory((prev) => prev.filter((item) => item.id !== id));
        addToast('Excluído!', 'Item removido do histórico.', 'info');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const emotions = [
    { id: 'neutral', label: 'Neutro' },
    { id: 'energetic', label: 'Energético' },
    { id: 'calm', label: 'Calmo' },
    { id: 'dramatic', label: 'Dramático' },
    { id: 'cheerful', label: 'Alegre' },
    { id: 'serious', label: 'Sério' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Banner Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Estúdio de Síntese
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--text)] font-mono">
              Neural TTS v1.2
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Text to Speech Studio
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Converta texto em áudio natural com qualquer voz clonada e controle preciso de dinâmica vocal.
          </p>
        </div>

        {/* Selected Voice Card Trigger */}
        {activeVoice && (
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-[var(--surface)] border border-[var(--lime)]/50 shadow-sm shrink-0">
            <div className="w-11 h-11 rounded-xl bg-[var(--purple)] text-white font-bold font-display flex items-center justify-center text-lg overflow-hidden shrink-0">
              {activeVoice.avatarUrl ? (
                <img src={activeVoice.avatarUrl} alt={activeVoice.name} className="w-full h-full object-cover" />
              ) : (
                activeVoice.name.charAt(0).toUpperCase()
              )}
            </div>
            <div>
              <div className="text-xs font-mono uppercase text-[var(--lime)] font-bold">
                Voz Selecionada
              </div>
              <div className="text-sm font-bold font-display text-[var(--text)]">
                {activeVoice.name}
              </div>
              <div className="text-[11px] text-[var(--muted)]">
                {activeVoice.language} • {activeVoice.category}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Script & Synthesis Controls Column */}
        <div className="lg:col-span-8 space-y-6">
          {/* Script Editor Card */}
          <div className="lima-card space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold font-display text-[var(--text)] flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-[var(--lime)]" />
                Script de Fala
              </label>
              <span className="text-xs font-mono text-[var(--subtle)]">
                {text.length} caracteres
              </span>
            </div>

            {/* SSML Tag Shortcuts */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <span className="text-[10px] font-mono text-[var(--subtle)] uppercase shrink-0">
                Inserir Expressão:
              </span>
              <button
                onClick={() => insertTag('[pausa 0.5s]')}
                className="px-2 py-1 rounded bg-[var(--surface2)] hover:bg-[var(--border)] text-[11px] font-mono text-[var(--text)] border border-[var(--border)] shrink-0 transition-colors"
              >
                + [pausa]
              </button>
              <button
                onClick={() => insertTag('[sussurro]')}
                className="px-2 py-1 rounded bg-[var(--surface2)] hover:bg-[var(--border)] text-[11px] font-mono text-[var(--purple)] border border-[var(--purple)]/30 shrink-0 transition-colors"
              >
                + [sussurro]
              </button>
              <button
                onClick={() => insertTag('[risada]')}
                className="px-2 py-1 rounded bg-[var(--surface2)] hover:bg-[var(--border)] text-[11px] font-mono text-amber-400 border border-amber-400/30 shrink-0 transition-colors"
              >
                + [risada]
              </button>
              <button
                onClick={() => insertTag('[ênfase]')}
                className="px-2 py-1 rounded bg-[var(--surface2)] hover:bg-[var(--border)] text-[11px] font-mono text-[var(--lime)] border border-[var(--lime)]/30 shrink-0 transition-colors"
              >
                + [ênfase]
              </button>
            </div>

            {/* Textarea */}
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={5}
              placeholder="Digite ou cole aqui o texto que você deseja transformar em fala..."
              className="w-full lima-input resize-y font-body text-base leading-relaxed"
            />

            {/* Emotion Selector Pills */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--subtle)] mb-2">
                Tom Emocional
              </label>
              <div className="flex flex-wrap gap-2">
                {emotions.map((em) => (
                  <button
                    key={em.id}
                    onClick={() => setEmotion(em.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      emotion === em.id
                        ? 'bg-[var(--purple)] text-white shadow-sm font-bold'
                        : 'bg-[var(--surface2)] text-[var(--muted)] hover:text-[var(--text)] border border-[var(--border)]'
                    }`}
                  >
                    {em.label}
                  </button>
                ))}
              </div>
            </div>

            {/* CTA Submit Button */}
            <div className="pt-2 flex justify-end">
              <button
                onClick={handleGenerateTTS}
                disabled={isGenerating || !text.trim()}
                className="btn-primary px-8 py-3 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>Sintetizando Áudio...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Gerar Áudio Sintetizado</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Audio Output Visual Player Panel */}
          {latestGen && (
            <div className="lima-card border-[var(--lime)]/50 bg-[var(--surface2)]/80 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
                <div className="flex items-center gap-2">
                  <Music className="w-4 h-4 text-[var(--lime)]" />
                  <span className="text-sm font-bold font-display text-[var(--text)]">
                    Áudio Sintetizado Gerado
                  </span>
                </div>
                <span className="text-xs font-mono text-[var(--muted)]">
                  {latestGen.duration}s de duração • {latestGen.characterCount} chars
                </span>
              </div>

              {/* Animated Waveform Bars */}
              <div className="h-16 bg-[var(--bg)] p-3 rounded-xl border border-[var(--border)] flex items-center justify-between gap-1">
                {Array.from({ length: 36 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-full bg-[var(--lime)] rounded-full transition-all ${
                      isPlayingCurrent ? 'animate-pulse' : 'opacity-60'
                    }`}
                    style={{
                      height: isPlayingCurrent ? `${(i % 5 + 1) * 18}%` : '35%',
                    }}
                  />
                ))}
              </div>

              {/* Controls bar */}
              <div className="flex items-center justify-between gap-3">
                <button
                  onClick={togglePlayCurrent}
                  className="btn-primary px-5 py-2 rounded-xl text-xs flex items-center gap-2"
                >
                  {isPlayingCurrent ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-black" />
                      <span>Pausar</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-black" />
                      <span>Ouvir Áudio</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(latestGen.text);
                      addToast('Copiado!', 'Texto do script copiado para a área de transferência.', 'info');
                    }}
                    className="btn-secondary px-3 py-2 rounded-xl text-xs flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Script</span>
                  </button>

                  <button
                    onClick={() => handleDownloadWav(latestGen.text)}
                    className="btn-accent px-4 py-2 rounded-xl text-xs flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download WAV</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Voice Parameters & Voice Selection Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          {/* Dynamic Sliders Card */}
          <div className="lima-card space-y-5">
            <h3 className="text-base font-bold font-display text-[var(--text)] flex items-center gap-2 border-b border-[var(--border)] pb-3">
              <Sliders className="w-4 h-4 text-[var(--purple)]" />
              Ajustes Finos de Voz
            </h3>

            {/* Speed Multiplier */}
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[var(--subtle)]">Velocidade (Speed)</span>
                <span className="text-[var(--lime)] font-mono">{speed.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full accent-[var(--lime)] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[var(--subtle)] font-mono mt-1">
                <span>0.5x (Lento)</span>
                <span>1.0x</span>
                <span>2.0x (Rápido)</span>
              </div>
            </div>

            {/* Pitch Shift */}
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[var(--subtle)]">Tom de Voz (Pitch)</span>
                <span className="text-[var(--purple)] font-mono">
                  {pitch > 0 ? `+${pitch.toFixed(1)}` : pitch.toFixed(1)} st
                </span>
              </div>
              <input
                type="range"
                min="-1.0"
                max="1.0"
                step="0.1"
                value={pitch}
                onChange={(e) => setPitch(parseFloat(e.target.value))}
                className="w-full accent-[var(--purple)] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[var(--subtle)] font-mono mt-1">
                <span>Grave (-1.0)</span>
                <span>Neutro</span>
                <span>Agudo (+1.0)</span>
              </div>
            </div>

            {/* Stability */}
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[var(--subtle)]">Estabilidade Neural</span>
                <span className="text-[var(--text)] font-mono">{stability}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={stability}
                onChange={(e) => setStability(parseInt(e.target.value, 10))}
                className="w-full accent-[var(--lime)] cursor-pointer"
              />
              <p className="text-[10px] text-[var(--subtle)] mt-1">
                Maior estabilidade reduz variações de entonação.
              </p>
            </div>

            {/* Similarity */}
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[var(--subtle)]">Similaridade com Amostra</span>
                <span className="text-[var(--text)] font-mono">{similarity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={similarity}
                onChange={(e) => setSimilarity(parseInt(e.target.value, 10))}
                className="w-full accent-[var(--lime)] cursor-pointer"
              />
            </div>
          </div>

          {/* Quick Voice Selector List */}
          <div className="lima-card space-y-3">
            <h3 className="text-sm font-bold font-display text-[var(--text)] flex items-center justify-between border-b border-[var(--border)] pb-2">
              <span>Selecione a Voz Base</span>
              <span className="text-xs text-[var(--muted)] font-mono font-normal">
                {voices.length} disponíveis
              </span>
            </h3>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {voices.map((v) => {
                const isSelected = v.id === activeVoice?.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => onSelectVoice(v.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                      isSelected
                        ? 'border-[var(--lime)] bg-[var(--surface2)] shadow-sm'
                        : 'border-[var(--border)] bg-[var(--bg)] hover:border-[var(--subtle)]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-[var(--purple)] text-white font-bold flex items-center justify-center text-xs shrink-0">
                        {v.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold font-display text-[var(--text)] truncate">
                          {v.name}
                        </div>
                        <div className="text-[10px] text-[var(--muted)] truncate">
                          {v.language} • {v.category}
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-[var(--lime)] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Generation History List */}
      <div className="lima-card space-y-4">
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
          <h3 className="text-lg font-bold font-display text-[var(--text)] flex items-center gap-2">
            <Clock className="w-4 h-4 text-[var(--lime)]" />
            Histórico de Sínteses Recentes
          </h3>
          <button
            onClick={fetchHistory}
            className="text-xs text-[var(--muted)] hover:text-[var(--text)] font-mono"
          >
            Atualizar Lista
          </button>
        </div>

        {history.length === 0 ? (
          <div className="text-center py-10 text-xs text-[var(--muted)]">
            Nenhuma síntese realizada ainda. Use o estúdio acima para gerar seu primeiro áudio.
          </div>
        ) : (
          <div className="space-y-3">
            {history.map((item) => {
              const isPlaying = playingHistoryId === item.id;
              return (
                <div
                  key={item.id}
                  className="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)] hover:border-[var(--lime)]/40 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <button
                      onClick={() => togglePlayHistory(item)}
                      className="w-10 h-10 rounded-xl bg-[var(--lime)] hover:scale-105 transition-transform flex items-center justify-center text-black shrink-0 mt-0.5"
                    >
                      {isPlaying ? (
                        <Square className="w-4 h-4 fill-black" />
                      ) : (
                        <Play className="w-4 h-4 fill-black ml-0.5" />
                      )}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold font-display text-[var(--text)]">
                          {item.voiceName}
                        </span>
                        <span className="text-[10px] px-2 py-0.2 rounded-full bg-[var(--surface2)] text-[var(--purple)] font-mono">
                          {item.emotion || 'neutro'}
                        </span>
                        <span className="text-[10px] text-[var(--subtle)] font-mono">
                          {item.duration}s
                        </span>
                      </div>
                      <p className="text-xs text-[var(--muted)] line-clamp-2 mt-1">
                        "{item.text}"
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                    <button
                      onClick={() => handleDownloadWav(item.text)}
                      className="p-2 rounded-lg bg-[var(--surface2)] text-[var(--text)] hover:bg-[var(--border)] transition-colors"
                      title="Download WAV"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteHistory(item.id)}
                      className="p-2 rounded-lg bg-[var(--surface2)] text-[var(--muted)] hover:text-[var(--red)] hover:bg-[var(--red)]/10 transition-colors"
                      title="Excluir"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
