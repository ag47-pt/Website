'use client';

import React, { useState, useEffect } from 'react';
import {
  Code2,
  Copy,
  Check,
  Key,
  Plus,
  Trash2,
  Terminal,
  Cpu,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface DeveloperStudioProps {
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const DeveloperStudio: React.FC<DeveloperStudioProps> = ({ addToast }) => {
  const [activeLang, setActiveLang] = useState<'curl' | 'node' | 'python' | 'react'>('node');
  const [copied, setCopied] = useState(false);
  const [keys, setKeys] = useState<any[]>([]);
  const [loadingKeys, setLoadingKeys] = useState(true);
  const [newKeyName, setNewKeyName] = useState('');
  const [isCreatingKey, setIsCreatingKey] = useState(false);

  const fetchKeys = async () => {
    setLoadingKeys(true);
    try {
      const res = await fetch('/api/api-keys');
      const data = await res.json();
      if (data.success) {
        setKeys(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingKeys(false);
    }
  };

  useEffect(() => {
    fetchKeys();
  }, []);

  const handleGenerateKey = async () => {
    try {
      const res = await fetch('/api/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newKeyName || 'Chave do App' }),
      });
      const data = await res.json();
      if (data.success) {
        addToast('Chave API criada!', 'Nova chave gerada com sucesso.', 'success');
        setIsCreatingKey(false);
        setNewKeyName('');
        fetchKeys();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRevokeKey = async (id: number) => {
    if (!confirm('Deseja revogar esta chave de API?')) return;
    try {
      const res = await fetch(`/api/api-keys/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        addToast('Chave revogada', 'A chave de API foi invalidada.', 'info');
        fetchKeys();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const snippets = {
    node: `import { LimaVoiceClient } from '@lima-ai/voice-sdk';

const lima = new LimaVoiceClient({
  apiKey: process.env.LIMA_API_KEY,
});

async function main() {
  const audioBuffer = await lima.tts.generate({
    voiceId: 1, // Mariana Silva
    text: "O Lima Voice Engine transforma voz em alta fidelidade.",
    emotion: "energetic",
    speed: 1.0,
    pitch: 0.0,
  });

  console.log("Áudio sintetizado:", audioBuffer.byteLength, "bytes");
}

main();`,

    curl: `curl -X POST https://api.lima.ai/v1/tts/generate \\
  -H "Authorization: Bearer lima_live_9f82d1..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "voiceId": 1,
    "text": "O Lima Voice Engine transforma voz em alta fidelidade.",
    "emotion": "energetic",
    "speed": 1.0
  }'`,

    python: `from lima_voice import LimaVoiceClient

client = LimaVoiceClient(api_key="lima_live_9f82d1...")

audio = client.tts.generate(
    voice_id=1,
    text="O Lima Voice Engine transforma voz em alta fidelidade.",
    emotion="energetic",
    speed=1.0
)

with open("output.wav", "wb") as f:
    f.write(audio.content)`,

    react: `import { useLimaVoice } from '@lima-ai/react';

export function VoicePlayer() {
  const { speak, isSynthesizing } = useLimaVoice({
    voiceId: 1,
    apiKey: process.env.NEXT_PUBLIC_LIMA_KEY,
  });

  return (
    <button 
      onClick={() => speak("Olá mundo com Lima Voice Engine!")}
      className="btn-primary px-4 py-2 rounded-xl"
    >
      {isSynthesizing ? 'Sintetizando...' : 'Falar com Voz Clonada'}
    </button>
  );
}`,
  };

  const currentSnippet = snippets[activeLang];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentSnippet);
    setCopied(true);
    addToast('Código copiado!', 'Snippet pronto para ser colado em seu projeto.', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Developer Hub & SDK
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--text)] font-mono">
              API REST & SDKs
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Developer Studio & API
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Integre clonagem de voz e geração de áudio no seu app em poucas linhas de código.
          </p>
        </div>
      </div>

      {/* Code Snippet Interactive Playground */}
      <div className="lima-card space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--border)] pb-4">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[var(--lime)]" />
            <span className="font-bold font-display text-base">SDK Exemplo de Integração</span>
          </div>

          {/* Language Tabs */}
          <div className="flex items-center gap-1 bg-[var(--bg)] p-1 rounded-xl border border-[var(--border)]">
            {(['node', 'curl', 'python', 'react'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setActiveLang(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase font-bold transition-all ${
                  activeLang === lang
                    ? 'bg-[var(--lime)] text-black'
                    : 'text-[var(--muted)] hover:text-[var(--text)]'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Snippet Block */}
        <div className="relative bg-[#0A0A0A] p-5 rounded-xl border border-[var(--border)] overflow-x-auto font-mono text-xs text-lime-300 leading-relaxed">
          <button
            onClick={handleCopyCode}
            className="absolute top-3 right-3 p-2 rounded-lg bg-[var(--surface2)] text-[var(--text)] hover:border-[var(--lime)] border border-[var(--border)] transition-colors flex items-center gap-1.5 text-xs"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[var(--lime)]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copiado!' : 'Copiar Código'}</span>
          </button>
          <pre>{currentSnippet}</pre>
        </div>
      </div>

      {/* API Keys Table */}
      <div className="lima-card space-y-4">
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-[var(--purple)]" />
            <h3 className="text-lg font-bold font-display">Chaves de API (API Keys)</h3>
          </div>

          <button
            onClick={() => setIsCreatingKey(true)}
            className="btn-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>Gerar Nova Chave</span>
          </button>
        </div>

        {/* Keys Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[var(--border)] text-[var(--subtle)] uppercase">
                <th className="py-3 px-2">Identificador</th>
                <th className="py-3 px-2">Chave de Produção</th>
                <th className="py-3 px-2">Requisições</th>
                <th className="py-3 px-2 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {keys.map((k) => (
                <tr key={k.id} className="hover:bg-[var(--surface2)]/50 transition-colors">
                  <td className="py-3 px-2 font-bold font-display text-sm text-[var(--text)]">
                    {k.name}
                  </td>
                  <td className="py-3 px-2 text-[var(--lime)]">
                    {k.key.substring(0, 16)}••••••••••••
                  </td>
                  <td className="py-3 px-2 text-[var(--muted)]">
                    {k.requestsCount} reqs
                  </td>
                  <td className="py-3 px-2 text-right">
                    <button
                      onClick={() => handleRevokeKey(k.id)}
                      className="p-1.5 rounded-lg text-[var(--subtle)] hover:text-[var(--red)] hover:bg-[var(--red)]/10 transition-colors"
                      title="Revogar Chave"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Key Modal */}
      {isCreatingKey && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 space-y-4">
            <h3 className="text-lg font-bold font-display">Gerar Chave de API</h3>
            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--subtle)] mb-1">
                Nome de Referência
              </label>
              <input
                type="text"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder="Ex: Servidor de Produção - App Mobile"
                className="w-full lima-input"
              />
            </div>
            <div className="flex justify-end gap-2 pt-4 border-t border-[var(--border)]">
              <button
                onClick={() => setIsCreatingKey(false)}
                className="btn-secondary px-4 py-2 rounded-xl text-xs"
              >
                Cancelar
              </button>
              <button
                onClick={handleGenerateKey}
                className="btn-primary px-5 py-2 rounded-xl text-xs font-bold"
              >
                Gerar Chave
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
