'use client';

import React, { useState, useEffect } from 'react';
import { Search, Mic, Wand2, BookOpen, Key, Palette, ArrowRight, X } from 'lucide-react';

interface CmdKModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: string) => void;
  onOpenCustomizer: () => void;
}

export const CmdKModal: React.FC<CmdKModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenCustomizer,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else onNavigate('search-modal-open');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, onNavigate]);

  if (!isOpen) return null;

  const commands = [
    {
      id: 'tts',
      title: 'Studio Text to Speech',
      description: 'Sintetize voz a partir de texto com parâmetros personalizados',
      icon: Wand2,
      tab: 'tts',
      badge: 'Ferramenta',
    },
    {
      id: 'clone',
      title: 'Clonar Nova Voz (Voice Cloner)',
      description: 'Grave ou envie amostra de áudio para extrair voz neural',
      icon: Mic,
      tab: 'cloner',
      badge: 'Laboratório',
    },
    {
      id: 'library',
      title: 'Biblioteca de Vozes Clonas',
      description: 'Explore vozes padrão e seus modelos clonados ativos',
      icon: BookOpen,
      tab: 'library',
      badge: 'Acervo',
    },
    {
      id: 'developer',
      title: 'Developer SDK & API Keys',
      description: 'Documentação cURL, Python, Node e gestão de chaves',
      icon: Key,
      tab: 'developer',
      badge: 'Dev',
    },
    {
      id: 'design-system',
      title: 'Lima Design System v1.2',
      description: 'Tokens, componentes interativos e diretrizes do sistema',
      icon: Palette,
      tab: 'design-system',
      badge: 'Sistema',
    },
  ];

  const filtered = commands.filter(
    (c) =>
      c.title.toLowerCase().includes(query.toLowerCase()) ||
      c.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-start justify-center pt-20 px-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Busca rápida Cmd+K"
    >
      <div
        className="w-full max-w-xl bg-[var(--surface)] border border-[var(--border)] rounded-2xl shadow-2xl overflow-hidden text-[var(--text)] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Search Field */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[var(--border)] bg-[var(--bg)]">
          <Search className="w-5 h-5 text-[var(--subtle)]" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Digite o que deseja buscar ou comando (ex: clonar, studio, api)..."
            className="flex-1 bg-transparent border-none text-base outline-none text-[var(--text)] placeholder:text-[var(--subtle)] font-body"
            autoFocus
          />
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-xs text-[var(--subtle)] bg-[var(--surface2)] border border-[var(--border)] rounded font-mono">
            ESC
          </kbd>
          <button
            onClick={onClose}
            className="text-[var(--subtle)] hover:text-[var(--text)] p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-2 max-h-[360px] overflow-y-auto space-y-1">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-[var(--muted)] text-sm">
              Nenhum comando ou voz encontrado para "{query}"
            </div>
          ) : (
            filtered.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.tab);
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[var(--surface2)] transition-colors text-left group border border-transparent hover:border-[var(--lime)]/30"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-[var(--bg)] border border-[var(--border)] flex items-center justify-center text-[var(--lime)] group-hover:bg-[var(--lime)] group-hover:text-black transition-colors shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-[var(--text)] font-display flex items-center gap-2">
                        {item.title}
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--surface2)] text-[var(--muted)] font-mono">
                          {item.badge}
                        </span>
                      </div>
                      <p className="text-xs text-[var(--muted)] truncate mt-0.5">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[var(--subtle)] group-hover:text-[var(--lime)] group-hover:translate-x-1 transition-all" />
                </button>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-[var(--border)] bg-[var(--bg)] flex items-center justify-between text-xs text-[var(--subtle)]">
          <span>Lima System Navigator</span>
          <div className="flex items-center gap-2">
            <span>Usar <kbd className="px-1.5 py-0.5 bg-[var(--surface2)] rounded">↑</kbd> <kbd className="px-1.5 py-0.5 bg-[var(--surface2)] rounded">↓</kbd> para navegar</span>
          </div>
        </div>
      </div>
    </div>
  );
};
