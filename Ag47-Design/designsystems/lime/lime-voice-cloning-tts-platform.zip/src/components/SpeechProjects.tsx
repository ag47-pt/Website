'use client';

import React, { useState, useEffect } from 'react';
import {
  FolderKanban,
  Plus,
  Play,
  Download,
  Trash2,
  Clock,
  Layers,
  Sparkles,
  CheckCircle2,
  UserCheck,
} from 'lucide-react';
import { speakTextWebSpeech, stopSpeech } from '@/lib/audioSynth';
import { VoiceModel } from './TTSStudio';

interface SpeechProjectsProps {
  voices: VoiceModel[];
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const SpeechProjects: React.FC<SpeechProjectsProps> = ({ voices, addToast }) => {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeProject, setActiveProject] = useState<any | null>(null);

  // New project modal / inputs
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedVoiceId, setSelectedVoiceId] = useState<number>(voices[0]?.id || 1);

  // Active script blocks in current open project
  const [blocks, setBlocks] = useState<any[]>([]);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      if (data.success) {
        setProjects(data.data);
        if (data.data.length > 0 && !activeProject) {
          setActiveProject(data.data[0]);
          setBlocks(data.data[0].scriptBlocks || []);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleCreateProject = async () => {
    if (!newTitle.trim()) {
      addToast('Título obrigatório', 'Informe o título do seu projeto de áudio.', 'warning');
      return;
    }

    try {
      const initialBlocks = [
        {
          id: 'b-1',
          speaker: voices.find((v) => v.id === selectedVoiceId)?.name || 'Narrador',
          voiceId: selectedVoiceId,
          text: 'Introdução do projeto sintetizada com inteligência artificial.',
          duration: 4.5,
        },
      ];

      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          description: newDesc.trim(),
          voiceId: selectedVoiceId,
          scriptBlocks: initialBlocks,
        }),
      });

      const data = await res.json();
      if (data.success) {
        addToast('Projeto Criado!', `"${newTitle}" foi adicionado.`, 'success');
        setIsCreating(false);
        setNewTitle('');
        setNewDesc('');
        fetchProjects();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddBlock = () => {
    if (!activeProject) return;
    const voiceObj = voices.find((v) => v.id === selectedVoiceId) || voices[0];
    const newBlock = {
      id: `b-${Date.now()}`,
      speaker: voiceObj.name,
      voiceId: voiceObj.id,
      text: 'Novo trecho de fala para o projeto...',
      duration: 3.5,
    };
    setBlocks((prev) => [...prev, newBlock]);
  };

  const handleUpdateBlockText = (id: string, text: string) => {
    setBlocks((prev) =>
      prev.map((b) =>
        b.id === id ? { ...b, text, duration: Math.max(1.5, text.split(' ').length / 3) } : b
      )
    );
  };

  const handleSaveProject = async () => {
    if (!activeProject) return;
    try {
      const res = await fetch(`/api/projects/${activeProject.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: activeProject.title,
          description: activeProject.description,
          scriptBlocks: blocks,
        }),
      });
      const data = await res.json();
      if (data.success) {
        addToast('Projeto Salvo!', 'Alterações registradas com sucesso.', 'success');
        fetchProjects();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const totalDurationSeconds = blocks.reduce((acc, b) => acc + (b.duration || 3), 0);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Produção em Lote
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--purple)] border border-[var(--purple)]/30 font-mono font-bold">
              Multi-Speaker Studio
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Projetos de Áudio
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Organize roteiros de podcasts, audiolivros e locução de vídeos com múltiplos locutores.
          </p>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="btn-primary px-6 py-3 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Novo Projeto de Fala</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Projects Sidebar List */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-sm font-bold font-display uppercase tracking-wider text-[var(--subtle)]">
            Seus Projetos ({projects.length})
          </h3>

          <div className="space-y-2">
            {projects.map((proj) => {
              const isSelected = activeProject?.id === proj.id;
              return (
                <div
                  key={proj.id}
                  onClick={() => {
                    setActiveProject(proj);
                    setBlocks(proj.scriptBlocks || []);
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[var(--lime)] bg-[var(--surface)] shadow-md'
                      : 'border-[var(--border)] bg-[var(--surface2)] hover:border-[var(--subtle)]'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold font-display text-sm text-[var(--text)] mb-1">
                    <span>{proj.title}</span>
                    <span className="text-xs font-mono text-[var(--lime)]">
                      {proj.totalDuration?.toFixed(1)}s
                    </span>
                  </div>
                  <p className="text-xs text-[var(--muted)] line-clamp-1">
                    {proj.description || 'Sem descrição'}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Project Timeline & Editor Column */}
        <div className="lg:col-span-8 space-y-6">
          {activeProject ? (
            <div className="lima-card space-y-6">
              <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
                <div>
                  <h2 className="text-xl font-bold font-display text-[var(--text)]">
                    {activeProject.title}
                  </h2>
                  <p className="text-xs text-[var(--muted)] mt-0.5">
                    {activeProject.description || 'Roteiro de áudio com síntese em linha'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-3 py-1.5 rounded-xl bg-[var(--surface2)] text-[var(--lime)] border border-[var(--border)]">
                    Total: {totalDurationSeconds.toFixed(1)} segundos
                  </span>
                </div>
              </div>

              {/* Blocks Timeline Stream */}
              <div className="space-y-4">
                {blocks.map((block, idx) => (
                  <div
                    key={block.id || idx}
                    className="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)] space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[var(--purple)] text-white font-mono font-bold text-xs flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <span className="text-xs font-bold font-display text-[var(--text)]">
                          Locutor: {block.speaker}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-[var(--subtle)]">
                        ~{block.duration?.toFixed(1)}s
                      </span>
                    </div>

                    <textarea
                      value={block.text}
                      onChange={(e) => handleUpdateBlockText(block.id, e.target.value)}
                      rows={2}
                      className="w-full lima-input resize-none text-sm"
                    />

                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() =>
                          speakTextWebSpeech(block.text, {
                            lang: 'pt-BR',
                            pitch: 0,
                            rate: 1.0,
                          })
                        }
                        className="btn-secondary px-3 py-1.5 rounded-lg text-xs flex items-center gap-1"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Ouvir Bloco</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Actions Footer */}
              <div className="pt-4 border-t border-[var(--border)] flex items-center justify-between">
                <button
                  onClick={handleAddBlock}
                  className="btn-secondary px-4 py-2 rounded-xl text-xs flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Adicionar Bloco de Fala</span>
                </button>

                <button
                  onClick={handleSaveProject}
                  className="btn-primary px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Salvar Alterações do Roteiro</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="lima-card text-center py-16 text-sm text-[var(--muted)]">
              Selecione um projeto na lista lateral ou crie um novo.
            </div>
          )}
        </div>
      </div>

      {/* Modal create project */}
      {isCreating && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 space-y-4">
            <h3 className="text-lg font-bold font-display">Novo Projeto de Áudio</h3>

            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--subtle)] mb-1">
                Título do Projeto
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Ex: Podcast Ep 01 - Inteligência Artificial"
                className="w-full lima-input"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--subtle)] mb-1">
                Descrição
              </label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Roteiro com síntese de voz multi-participantes..."
                rows={2}
                className="w-full lima-input resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--subtle)] mb-1">
                Voz Principal
              </label>
              <select
                value={selectedVoiceId}
                onChange={(e) => setSelectedVoiceId(parseInt(e.target.value, 10))}
                className="w-full lima-input"
              >
                {voices.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.language})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-[var(--border)]">
              <button
                onClick={() => setIsCreating(false)}
                className="btn-secondary px-4 py-2 rounded-xl text-xs"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateProject}
                className="btn-primary px-5 py-2 rounded-xl text-xs font-bold"
              >
                Criar Projeto
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
