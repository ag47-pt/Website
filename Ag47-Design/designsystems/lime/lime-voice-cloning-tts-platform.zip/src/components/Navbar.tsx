'use client';

import React from 'react';
import {
  Wand2,
  Mic,
  BookOpen,
  FolderKanban,
  Code2,
  Palette,
  Search,
  Sun,
  Moon,
  Play,
  Activity,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  onOpenCmdK: () => void;
  onOpenCustomizer: () => void;
  voicesCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  theme,
  setTheme,
  onOpenCmdK,
  onOpenCustomizer,
  voicesCount = 6,
}) => {
  const navItems = [
    { id: 'tts', label: 'Studio TTS', icon: Wand2 },
    { id: 'cloner', label: 'Clonar Voz', icon: Mic, badge: 'Laboratório' },
    { id: 'library', label: 'Vozes', icon: BookOpen, count: voicesCount },
    { id: 'projects', label: 'Projetos', icon: FolderKanban },
    { id: 'developer', label: 'Dev & API', icon: Code2 },
    { id: 'design-system', label: 'Design System', icon: Palette },
  ];

  return (
    <header className="sticky top-0 z-[50] w-full border-b border-[var(--border)] bg-[var(--bg)]/90 backdrop-blur-md transition-colors">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          onClick={() => setActiveTab('tts')}
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="w-9 h-9 rounded-full bg-[var(--lime)] flex items-center justify-center text-black group-hover:scale-105 transition-transform shadow-[0_0_12px_rgba(194,245,0,0.3)]">
            <Play className="w-4 h-4 fill-black translate-x-0.5" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-display font-extrabold text-xl tracking-tight text-[var(--text)]">
                Lima
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[var(--surface2)] text-[var(--lime)] border border-[var(--lime)]/30">
                v1.2 Studio
              </span>
            </div>
            <span className="text-[11px] text-[var(--muted)] -mt-1 hidden sm:block">
              Voice Cloning & TTS Framework
            </span>
          </div>
        </div>

        {/* Navigation Tabs (Horizontal Stepper/Tab Style) */}
        <nav className="hidden md:flex items-center gap-1 bg-[var(--surface)] p-1 rounded-xl border border-[var(--border)]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold font-display transition-all duration-150 ${
                  isActive
                    ? 'bg-[var(--lime)] text-black shadow-sm'
                    : 'text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--surface2)]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-black' : ''}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded font-mono uppercase ${
                      isActive
                        ? 'bg-black/20 text-black'
                        : 'bg-[var(--purple)]/20 text-[var(--purple)]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {item.count !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isActive
                        ? 'bg-black/20 text-black font-bold'
                        : 'bg-[var(--surface2)] text-[var(--text)]'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Controls & Tools */}
        <div className="flex items-center gap-2">
          {/* Status Dot */}
          <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded-full bg-[var(--surface2)] border border-[var(--border)] text-xs text-[var(--muted)]">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[var(--lime)] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[var(--lime)]"></span>
            </span>
            <span className="font-mono text-[11px]">Neural Engine Online</span>
          </div>

          {/* Cmd+K Search Button */}
          <button
            onClick={onOpenCmdK}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--muted)] hover:text-[var(--text)] hover:border-[var(--lime)]/50 transition-colors text-xs"
            aria-label="Buscar comandos (Cmd+K)"
          >
            <Search className="w-3.5 h-3.5 text-[var(--subtle)]" />
            <span className="hidden sm:inline">Buscar</span>
            <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] bg-[var(--surface2)] border border-[var(--border)] rounded font-mono text-[var(--subtle)]">
              ⌘K
            </kbd>
          </button>

          {/* Theme Customizer Icon Button */}
          <button
            onClick={onOpenCustomizer}
            className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:border-[var(--lime)] transition-colors flex items-center justify-center"
            title="Customizar Tema"
            aria-label="Tema & Cores"
          >
            <Palette className="w-4 h-4 text-[var(--lime)]" />
          </button>

          {/* Theme Dark/Light Switch */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:border-[var(--lime)] transition-colors flex items-center justify-center"
            title={theme === 'dark' ? 'Alternar para Modo Claro' : 'Alternar para Modo Escuro'}
            aria-label="Trocar Tema"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-[var(--purple)]" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Nav Scrollable Row */}
      <div className="md:hidden flex items-center gap-1 overflow-x-auto px-4 py-2 bg-[var(--surface)] border-t border-[var(--border)] scrollbar-none">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap font-display transition-colors ${
                isActive
                  ? 'bg-[var(--lime)] text-black font-bold'
                  : 'text-[var(--muted)] hover:text-[var(--text)]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
