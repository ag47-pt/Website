'use client';

import React from 'react';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message?: string;
}

interface ToastContainerProps {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (!toasts.length) return null;

  return (
    <div className="fixed bottom-6 right-6 z-[1100] flex flex-col gap-3 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const icons = {
          success: <CheckCircle2 className="w-5 h-5 text-[#C2F500] shrink-0" />,
          error: <XCircle className="w-5 h-5 text-[#FF463A] shrink-0" />,
          info: <Info className="w-5 h-5 text-[#A855F7] shrink-0" />,
          warning: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
        };

        const borderStyles = {
          success: 'border-[#C2F500]/40',
          error: 'border-[#FF463A]/40',
          info: 'border-[#A855F7]/40',
          warning: 'border-amber-400/40',
        };

        return (
          <div
            key={toast.id}
            role={toast.type === 'error' ? 'alert' : 'status'}
            aria-live={toast.type === 'error' ? 'assertive' : 'polite'}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border bg-[var(--surface)] text-[var(--text)] shadow-lg transition-all duration-200 animate-in fade-in slide-in-from-bottom-3 ${borderStyles[toast.type]}`}
          >
            {icons[toast.type]}
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-[var(--text)] font-display">
                {toast.title}
              </h4>
              {toast.message && (
                <p className="text-xs text-[var(--muted)] mt-0.5 leading-relaxed">
                  {toast.message}
                </p>
              )}
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-[var(--subtle)] hover:text-[var(--text)] p-1 rounded-md transition-colors"
              aria-label="Fechar notificação"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
