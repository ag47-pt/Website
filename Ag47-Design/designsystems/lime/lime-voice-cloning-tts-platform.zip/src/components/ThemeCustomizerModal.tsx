'use client';

import React from 'react';
import { Palette, Check, Sun, Moon, Sparkles, X } from 'lucide-react';

interface ThemeCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  preset: string;
  setPreset: (p: string) => void;
}

export const ThemeCustomizerModal: React.FC<ThemeCustomizerModalProps> = ({
  isOpen,
  onClose,
  theme,
  setTheme,
  preset,
  setPreset,
}) => {
  if (!isOpen) return null;

  const presets = [
    {
      id: 'lima-default',
      name: 'Lima Core (Verde Limão)',
      lime: '#C2F500',
      purple: '#A855F7',
      desc: 'O padrão oficial Lima v1.2 — Alto contraste e máxima energia.',
    },
    {
      id: 'cyber-neon',
      name: 'Cyberpunk Electric',
      lime: '#00FFCC',
      purple: '#FF007F',
      desc: 'Verde ciano vibrante e rosa neon futurista.',
    },
    {
      id: 'gold-amber',
      name: 'Amber Solar',
      lime: '#FFC700',
      purple: '#9333EA',
      desc: 'Dourado brilhante com toques roxos profundos.',
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-[var(--surface)] border border-[var(--border)] rounded-2xl shadow-2xl p-6 text-[var(--text)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[var(--border)] mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--lime)] flex items-center justify-center text-black font-bold">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold font-display">Theme Customizer</h3>
              <p className="text-xs text-[var(--muted)]">Lima Design System Presets v1.2</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[var(--subtle)] hover:text-[var(--text)] p-2 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="mb-6">
          <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--subtle)] mb-2">
            Modo de Exibição (WCAG 2.1 AA)
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setTheme('dark')}
              className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all ${
                theme === 'dark'
                  ? 'border-[var(--lime)] bg-[var(--surface2)] text-[var(--text)] shadow-sm'
                  : 'border-[var(--border)] bg-[var(--bg)] text-[var(--muted)] hover:border-[var(--subtle)]'
              }`}
            >
              <Moon className="w-4 h-4 text-[var(--lime)]" />
              Modo Escuro (Padrão)
            </button>
            <button
              onClick={() => setTheme('light')}
              className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all ${
                theme === 'light'
                  ? 'border-[var(--lime)] bg-[var(--surface2)] text-[var(--text)] shadow-sm'
                  : 'border-[var(--border)] bg-[var(--bg)] text-[var(--muted)] hover:border-[var(--subtle)]'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              Modo Claro
            </button>
          </div>
        </div>

        {/* Presets Grid */}
        <div className="mb-6 space-y-3">
          <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">
            Paleta de Acento & Secundária
          </label>
          {presets.map((p) => {
            const isSelected = preset === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setPreset(p.id)}
                className={`w-full text-left p-4 rounded-xl border transition-all flex items-start justify-between ${
                  isSelected
                    ? 'border-[var(--lime)] bg-[var(--surface2)] shadow-md'
                    : 'border-[var(--border)] bg-[var(--bg)] hover:border-[var(--subtle)]'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 font-semibold text-sm font-display">
                    {p.name}
                    {isSelected && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--lime)] text-black font-bold">
                        Ativo
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[var(--muted)] mt-1">{p.desc}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 ml-3 mt-1">
                  <div
                    className="w-5 h-5 rounded-full border border-black/20 shadow-sm"
                    style={{ backgroundColor: p.lime }}
                  />
                  <div
                    className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
                    style={{ backgroundColor: p.purple }}
                  />
                </div>
              </button>
            );
          })}
        </div>

        {/* Action Footer */}
        <div className="pt-4 border-t border-[var(--border)] flex justify-end">
          <button
            onClick={onClose}
            className="btn-primary px-6 py-2.5 rounded-xl text-sm font-semibold"
          >
            Concluído
          </button>
        </div>
      </div>
    </div>
  );
};
