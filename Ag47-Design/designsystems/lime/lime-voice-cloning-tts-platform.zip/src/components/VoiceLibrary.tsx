'use client';

import React, { useState } from 'react';
import {
  Search,
  Filter,
  Play,
  Pause,
  Trash2,
  Wand2,
  Plus,
  CheckCircle2,
  Shield,
  Volume2,
  Sparkles,
  Square,
} from 'lucide-react';
import { speakTextWebSpeech, stopSpeech } from '@/lib/audioSynth';
import { VoiceModel } from './TTSStudio';

interface VoiceLibraryProps {
  voices: VoiceModel[];
  onSelectVoiceForTTS: (id: number) => void;
  onNavigateToCloner: () => void;
  onRefreshVoices: () => void;
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const VoiceLibrary: React.FC<VoiceLibraryProps> = ({
  voices,
  onSelectVoiceForTTS,
  onNavigateToCloner,
  onRefreshVoices,
  addToast,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLang, setSelectedLang] = useState<string>('all');
  const [playingVoiceId, setPlayingVoiceId] = useState<number | null>(null);

  // Sample sentence preview per language
  const getSampleSentence = (lang: string, name: string) => {
    if (lang.startsWith('en')) {
      return `Hello, I am ${name}. Welcome to the Lima Voice Engine framework.`;
    }
    return `Olá! Meu nome é ${name}. Esta é uma demonstração da minha voz no Lima Engine.`;
  };

  const handleTogglePlaySample = (voice: VoiceModel) => {
    if (playingVoiceId === voice.id) {
      stopSpeech();
      setPlayingVoiceId(null);
    } else {
      stopSpeech();
      setPlayingVoiceId(voice.id);
      const text = getSampleSentence(voice.language, voice.name);
      speakTextWebSpeech(text, {
        lang: voice.language,
        pitch: voice.pitchShiftDefault || 0,
        rate: voice.speedDefault || 1.0,
        onEnd: () => setPlayingVoiceId(null),
      });
    }
  };

  const handleDeleteVoice = async (id: number, name: string) => {
    if (!confirm(`Deseja realmente excluir a voz "${name}"?`)) return;

    try {
      const res = await fetch(`/api/voices/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        addToast('Voz excluída', `A voz "${name}" foi removida.`, 'info');
        onRefreshVoices();
      } else {
        addToast('Erro ao excluir', data.error || 'Não foi possível remover.', 'error');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredVoices = voices.filter((v) => {
    const matchesSearch =
      v.name.toLowerCase().includes(search.toLowerCase()) ||
      v.description.toLowerCase().includes(search.toLowerCase()) ||
      (v.tags && v.tags.some((t) => t.toLowerCase().includes(search.toLowerCase())));

    const matchesCategory = selectedCategory === 'all' || v.category === selectedCategory;
    const matchesLang = selectedLang === 'all' || v.language === selectedLang;

    return matchesSearch && matchesCategory && matchesLang;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Acervo de Modelos
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--text)] font-mono">
              {voices.length} Vozes Ativas
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Biblioteca de Vozes
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Explore modelos de voz padrão e modelos personalizados que você clonou com o framework.
          </p>
        </div>

        <button
          onClick={onNavigateToCloner}
          className="btn-primary px-6 py-3 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Clonar Nova Voz</span>
        </button>
      </div>

      {/* Filter and Search Controls */}
      <div className="lima-card space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-[var(--subtle)] absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por nome de voz, estilo ou tags..."
              className="w-full lima-input pl-10 text-sm"
            />
          </div>

          {/* Category Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full lima-input text-sm"
            >
              <option value="all">Todas as Categorias</option>
              <option value="conversational">Conversacional</option>
              <option value="narrative">Narrativa / Livros</option>
              <option value="dynamic">Dinâmica / Redes</option>
              <option value="cinematic">Cinemática</option>
              <option value="support">Atendimento</option>
            </select>
          </div>

          {/* Language Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="w-full lima-input text-sm"
            >
              <option value="all">Todos os Idiomas</option>
              <option value="pt-BR">Português (Brasil)</option>
              <option value="en-US">English (US)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Voices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVoices.map((voice) => {
          const isPlaying = playingVoiceId === voice.id;

          return (
            <div
              key={voice.id}
              className="lima-card lima-card-interactive flex flex-col justify-between space-y-4 relative group"
            >
              <div>
                {/* Voice Card Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-[var(--purple)] text-white font-bold font-display flex items-center justify-center text-xl overflow-hidden shadow-md shrink-0">
                      {voice.avatarUrl ? (
                        <img
                          src={voice.avatarUrl}
                          alt={voice.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        voice.name.charAt(0).toUpperCase()
                      )}
                    </div>

                    <div>
                      <h3 className="font-bold font-display text-base text-[var(--text)] leading-snug">
                        {voice.name}
                      </h3>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.2 rounded bg-[var(--surface2)] text-[var(--muted)] border border-[var(--border)]">
                          {voice.category}
                        </span>
                        <span className="text-[10px] font-mono text-[var(--subtle)]">
                          {voice.language}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Preset or Custom Badge */}
                  {voice.isPreset ? (
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[var(--lime)] text-black shrink-0">
                      Oficial
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[var(--purple)] text-white shrink-0">
                      Clonada
                    </span>
                  )}
                </div>

                <p className="text-xs text-[var(--muted)] leading-relaxed line-clamp-2 mb-3">
                  {voice.description}
                </p>

                {/* Quality Metrics */}
                <div className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--border)] mb-3 flex items-center justify-between text-xs font-mono">
                  <span className="text-[var(--subtle)]">Clareza:</span>
                  <span className="text-[var(--lime)] font-bold">{voice.clarityScore}%</span>
                  <span className="text-[var(--subtle)]">Ruído:</span>
                  <span className="text-[var(--text)]">{voice.noiseLevel}</span>
                </div>

                {/* Tag Pills */}
                {voice.tags && voice.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {voice.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--subtle)]"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Buttons Footer */}
              <div className="pt-3 border-t border-[var(--border)] flex items-center justify-between gap-2">
                <button
                  onClick={() => handleTogglePlaySample(voice)}
                  className="btn-secondary px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 font-semibold"
                  title="Ouvir amostra de voz"
                >
                  {isPlaying ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-[var(--text)]" />
                      <span>Pausar</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-[var(--text)]" />
                      <span>Ouvir</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  {!voice.isPreset && (
                    <button
                      onClick={() => handleDeleteVoice(voice.id, voice.name)}
                      className="p-2 rounded-xl bg-[var(--surface2)] text-[var(--muted)] hover:text-[var(--red)] hover:bg-[var(--red)]/10 transition-colors"
                      title="Excluir Voz"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => onSelectVoiceForTTS(voice.id)}
                    className="btn-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5"
                  >
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Usar no Studio</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
