'use client';

import React, { useState } from 'react';
import {
  Palette,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  Layers,
  Sparkles,
  Zap,
  Sliders,
  Type,
  LayoutGrid,
  Activity,
  BarChart3,
  Check,
  X,
  Play,
} from 'lucide-react';

export const DesignSystemShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tokens' | 'components' | 'charts' | 'rules'>('tokens');

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Brand Library · v1.2
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--text)] font-mono font-bold">
              WCAG 2.1 AA Compliant
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Lima Design System Showcase
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            High contrast, full energy. Um sistema de design construído sobre verde limão, violeta vibrante e contraste em alto nível.
          </p>
        </div>
      </div>

      {/* Showcase Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-[var(--border)] pb-3">
        {[
          { id: 'tokens', label: 'Cores & Tipografia', icon: Palette },
          { id: 'components', label: 'Componentes UI', icon: LayoutGrid },
          { id: 'charts', label: 'Métricas & Charts', icon: BarChart3 },
          { id: 'rules', label: 'Diretrizes Do & Don\'t', icon: CheckCircle2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold font-display transition-all ${
                isActive
                  ? 'bg-[var(--lime)] text-black'
                  : 'bg-[var(--surface)] text-[var(--muted)] hover:text-[var(--text)] border border-[var(--border)]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: TOKENS, CORES & TIPOGRAFIA */}
      {activeTab === 'tokens' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Colors Matrix */}
          <div className="lima-card space-y-4">
            <h3 className="text-lg font-bold font-display flex items-center gap-2">
              <Palette className="w-5 h-5 text-[var(--lime)]" />
              Paleta Principal de Marca
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
              <div className="p-4 rounded-xl bg-[#C2F500] text-black font-mono space-y-2 shadow-md">
                <div className="text-xs uppercase font-bold">Primary Lime</div>
                <div className="text-lg font-extrabold">#C2F500</div>
                <div className="text-[10px]">CTAs, foco e energia</div>
              </div>

              <div className="p-4 rounded-xl bg-[#A855F7] text-white font-mono space-y-2 shadow-md">
                <div className="text-xs uppercase font-bold">Purple Accent</div>
                <div className="text-lg font-extrabold">#A855F7</div>
                <div className="text-[10px]">Secondary contraste</div>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] text-white border border-[var(--border)] font-mono space-y-2">
                <div className="text-xs uppercase font-bold">Black Base</div>
                <div className="text-lg font-extrabold">#0A0A0A</div>
                <div className="text-[10px]">Background dark</div>
              </div>

              <div className="p-4 rounded-xl bg-[#FFFFFF] text-black font-mono space-y-2 shadow-md">
                <div className="text-xs uppercase font-bold">White Base</div>
                <div className="text-lg font-extrabold">#FFFFFF</div>
                <div className="text-[10px]">Superfície clara / Texto</div>
              </div>

              <div className="p-4 rounded-xl bg-[#FF463A] text-white font-mono space-y-2 shadow-md">
                <div className="text-xs uppercase font-bold">Red Semantic</div>
                <div className="text-lg font-extrabold">#FF463A</div>
                <div className="text-[10px]">Exclusivo alertas/erros</div>
              </div>
            </div>
          </div>

          {/* Typography Scale */}
          <div className="lima-card space-y-4">
            <h3 className="text-lg font-bold font-display flex items-center gap-2">
              <Type className="w-5 h-5 text-[var(--purple)]" />
              Escala Tipográfica (Space Grotesk + Hanken Grotesk)
            </h3>

            <div className="space-y-4 font-body divide-y divide-[var(--border)]">
              <div className="pt-2">
                <span className="text-xs font-mono text-[var(--lime)]">Display (64px) — Space Grotesk 700</span>
                <h1 className="text-5xl font-extrabold font-display tracking-tight text-[var(--text)] mt-1">
                  Lima Voice Engine
                </h1>
              </div>

              <div className="pt-3">
                <span className="text-xs font-mono text-[var(--purple)]">H1 (44px) — Space Grotesk 700</span>
                <h2 className="text-3xl font-bold font-display text-[var(--text)] mt-1">
                  Clonagem de Voz de Alta Fidelidade
                </h2>
              </div>

              <div className="pt-3">
                <span className="text-xs font-mono text-[var(--subtle)]">H2 (32px) & Body Large (19px)</span>
                <p className="text-lg text-[var(--text)] mt-1">
                  Sintetize fonação natural e dinâmica vocal em segundos usando IA avançada.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: COMPONENTS GALLERY */}
      {activeTab === 'components' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Buttons Matrix */}
          <div className="lima-card space-y-4">
            <h3 className="text-lg font-bold font-display">Variantes de Botões</h3>
            <div className="flex flex-wrap gap-3 items-center">
              <button className="btn-primary px-5 py-2.5 rounded-xl text-xs">Primary Lime</button>
              <button className="btn-accent px-5 py-2.5 rounded-xl text-xs">Accent Purple</button>
              <button className="btn-secondary px-5 py-2.5 rounded-xl text-xs">Secondary Surface</button>
              <button className="btn-ghost px-5 py-2.5 rounded-xl text-xs">Ghost Button</button>
              <button className="btn-destructive px-5 py-2.5 rounded-xl text-xs">Destructive Red</button>
              <button className="w-10 h-10 rounded-full bg-[var(--lime)] text-black flex items-center justify-center font-bold">
                <Play className="w-4 h-4 fill-black" />
              </button>
            </div>
          </div>

          {/* Badges Matrix */}
          <div className="lima-card space-y-4">
            <h3 className="text-lg font-bold font-display">Badges e Rotulagem Semântica</h3>
            <div className="flex flex-wrap gap-3">
              <span className="badge-lime text-xs font-bold px-3 py-1 rounded-full">Primary Lime</span>
              <span className="badge-purple text-xs font-bold px-3 py-1 rounded-full">Accent Purple</span>
              <span className="badge-neutral text-xs font-bold px-3 py-1 rounded-full">Neutral Surface</span>
              <span className="badge-red text-xs font-bold px-3 py-1 rounded-full">Critical Red</span>
              <span className="badge-outline-lime text-xs font-bold px-3 py-1 rounded-full">Outline Lime</span>
              <span className="badge-outline-text text-xs font-bold px-3 py-1 rounded-full">Outline Text Token</span>
            </div>
          </div>

          {/* Alerts Matrix */}
          <div className="lima-card space-y-4">
            <h3 className="text-lg font-bold font-display">Alertas Semânticos</h3>

            <div className="space-y-3">
              <div className="p-4 rounded-xl border border-[var(--lime)]/50 bg-[var(--lime)]/10 text-[var(--text)] flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[var(--lime)] shrink-0" />
                <span className="text-sm">Success Alert: Áudio sintetizado e pronto para download!</span>
              </div>

              <div className="p-4 rounded-xl border border-[var(--purple)]/50 bg-[var(--purple)]/10 text-[var(--text)] flex items-center gap-3">
                <Info className="w-5 h-5 text-[var(--purple)] shrink-0" />
                <span className="text-sm">Info Alert: O modelo neural está alinhando formantes e tom.</span>
              </div>

              <div className="p-4 rounded-xl border border-[var(--red)]/50 bg-[var(--red)]/10 text-[var(--text)] flex items-center gap-3">
                <XCircle className="w-5 h-5 text-[var(--red)] shrink-0" />
                <span className="text-sm">Critical Alert: Vermelho é reservado estritamente para falhas.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CHARTS & METRICS */}
      {activeTab === 'charts' && (
        <div className="lima-card space-y-6 animate-in fade-in duration-200">
          <h3 className="text-lg font-bold font-display flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[var(--lime)]" />
            Charts & Visualização de Desempenho
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Usage Bar Chart */}
            <div className="p-5 rounded-2xl bg-[var(--bg)] border border-[var(--border)] space-y-4">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="font-bold text-[var(--text)]">Sínteses por Dia (Minutos)</span>
                <span className="text-[var(--lime)]">+24.8% esta semana</span>
              </div>

              <div className="h-40 flex items-end justify-between gap-2 pt-4 border-b border-[var(--border)]">
                {[
                  { day: 'Seg', val: 40 },
                  { day: 'Ter', val: 65 },
                  { day: 'Qua', val: 80 },
                  { day: 'Qui', val: 95 },
                  { day: 'Sex', val: 70 },
                  { day: 'Sáb', val: 45 },
                  { day: 'Dom', val: 85 },
                ].map((item, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                    <div
                      className="w-full bg-[var(--lime)] rounded-t hover:brightness-110 transition-all"
                      style={{ height: `${item.val}%` }}
                    />
                    <span className="text-[10px] font-mono text-[var(--subtle)]">{item.day}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Loss Spectral Line Chart */}
            <div className="p-5 rounded-2xl bg-[var(--bg)] border border-[var(--border)] space-y-4">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="font-bold text-[var(--text)]">Curva de Perda Neural (Spectral Loss)</span>
                <span className="text-[var(--purple)]">Convergência 0.02</span>
              </div>

              <div className="h-40 flex items-center justify-center p-2">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 200 100">
                  <path
                    d="M 10,20 Q 50,80 100,88 T 190,92"
                    fill="none"
                    stroke="#A855F7"
                    strokeWidth="3"
                  />
                  <path
                    d="M 10,35 Q 50,65 100,92 T 190,95"
                    fill="none"
                    stroke="#C2F500"
                    strokeWidth="3"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: DO & DON'T RULES */}
      {activeTab === 'rules' && (
        <div className="lima-card space-y-6 animate-in fade-in duration-200">
          <h3 className="text-lg font-bold font-display">Diretrizes de Marca & Microcopy (Sentence Case)</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-[var(--lime)]/10 border border-[var(--lime)] space-y-3">
              <div className="flex items-center gap-2 text-[var(--lime)] font-bold text-sm font-display">
                <Check className="w-5 h-5 stroke-[3]" />
                Fazer (DO)
              </div>
              <ul className="text-xs text-[var(--text)] space-y-2 list-disc pl-4 leading-relaxed">
                <li>Use vermelho (#FF463A) **exclusivamente** para erros e avisos de perigo.</li>
                <li>Mantenha CTAs em sentence case: "Salvar alterações", "Gerar áudio".</li>
                <li>Garanta contraste mínimo WCAG 2.1 AA em todos os componentes.</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[var(--red)]/10 border border-[var(--red)] space-y-3">
              <div className="flex items-center gap-2 text-[var(--red)] font-bold text-sm font-display">
                <X className="w-5 h-5 stroke-[3]" />
                Não Fazer (DON'T)
              </div>
              <ul className="text-xs text-[var(--text)] space-y-2 list-disc pl-4 leading-relaxed">
                <li>Nunca use a cor vermelha de forma decorativa ou festiva.</li>
                <li>Evite colocar texto em caixa alta excessiva nos botões (não use "SALVAR").</li>
                <li>Não altere a proporção ou rotação do logo Lima.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
