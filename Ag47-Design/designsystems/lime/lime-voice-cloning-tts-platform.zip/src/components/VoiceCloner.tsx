'use client';

import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Upload,
  Play,
  Pause,
  Sliders,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Activity,
  Cpu,
  RefreshCw,
  Volume2,
  Tag,
  Info,
  Layers,
  Check,
} from 'lucide-react';
import { speakTextWebSpeech, stopSpeech } from '@/lib/audioSynth';

interface VoiceClonerProps {
  onVoiceCreated: () => void;
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const VoiceCloner: React.FC<VoiceClonerProps> = ({ onVoiceCreated, addToast }) => {
  const [currentStep, setCurrentStep] = useState(1);

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('pt-BR');
  const [category, setCategory] = useState('conversational');
  const [gender, setGender] = useState('female');
  const [age, setAge] = useState('adult');
  const [tagsInput, setTagsInput] = useState('Profissional, Natural, Expressiva');

  // Audio Capture State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);

  // Step 2 Clean-up & Metrics
  const [denoiseEnabled, setDenoiseEnabled] = useState(true);
  const [trimSilence, setTrimSilence] = useState(true);
  const [clarityScore, setClarityScore] = useState(98);
  const [noiseLevel, setNoiseLevel] = useState('Ultra Low (-62dB)');

  // Step 3 Training simulation
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);

  // Step 4 Verification & Saving
  const [testText, setTestText] = useState('Olá! Este é um teste com a minha nova voz clonada pelo Lima Engine.');
  const [isPlayingTest, setIsPlayingTest] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Handle live recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        addToast('Áudio gravado!', 'Amostra de voz capturada com sucesso.', 'success');
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error(err);
      addToast('Erro ao acessar microfone', 'Verifique a permissão do seu navegador.', 'error');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((t) => t.stop());
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAudioFile(file);
      const url = URL.createObjectURL(file);
      setAudioUrl(url);
      addToast('Arquivo carregado!', `Amostra: ${file.name}`, 'info');
    }
  };

  // Step 3 Training simulation trigger
  const runNeuralTraining = () => {
    setIsTraining(true);
    setTrainingProgress(0);
    setCurrentEpoch(0);
    setLogs(['[0.0s] Inicializando extrator de ressonância vocal...', '[0.5s] Extraindo características timbrísticas e formantes...']);

    let epoch = 0;
    const interval = setInterval(() => {
      epoch += 1;
      const progress = Math.min(100, Math.floor((epoch / 10) * 100));
      setTrainingProgress(progress);
      setCurrentEpoch(epoch * 10);

      const spectralLoss = (0.85 * Math.pow(0.65, epoch)).toFixed(4);
      setLogs((prev) => [
        ...prev,
        `[Epoch ${epoch * 10}/100] Spectral Loss: ${spectralLoss} | F0 Alignment: ${(92 + epoch * 0.7).toFixed(1)}%`,
      ]);

      if (epoch >= 10) {
        clearInterval(interval);
        setIsTraining(false);
        setLogs((prev) => [...prev, '✓ Treinamento concluído com alta fidelidade timbrística!']);
        addToast('Modelo treinado!', 'Voz clonada pronta para validação.', 'success');
      }
    }, 450);
  };

  // Test voice output
  const handleTestVoice = () => {
    if (isPlayingTest) {
      stopSpeech();
      setIsPlayingTest(false);
    } else {
      setIsPlayingTest(true);
      speakTextWebSpeech(testText, {
        lang: language,
        pitch: gender === 'male' ? -0.2 : 0.1,
        rate: 1.0,
        onEnd: () => setIsPlayingTest(false),
      });
    }
  };

  // Save Cloned Voice into DB
  const handleSaveVoice = async () => {
    if (!name.trim()) {
      addToast('Nome obrigatório', 'Forneça um nome para identificar esta voz.', 'warning');
      return;
    }

    setIsSaving(true);
    try {
      const tagsArray = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const res = await fetch('/api/voices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim() || 'Modelo de voz customizado clonado via Lima Engine.',
          language,
          category,
          gender,
          age,
          tags: tagsArray.length ? tagsArray : ['Clonada', 'Personalizada'],
          sampleAudioUrl: audioUrl,
          qualityScore: clarityScore,
          noiseLevel,
          clarityScore,
        }),
      });

      const data = await res.json();
      if (data.success) {
        addToast('Voz clonada salva!', `A voz "${name}" foi adicionada à sua biblioteca.`, 'success');
        onVoiceCreated();
        setCurrentStep(1);
        setName('');
        setDescription('');
        setAudioUrl(null);
      } else {
        addToast('Erro ao salvar voz', data.error || 'Tente novamente.', 'error');
      }
    } catch (err) {
      console.error(err);
      addToast('Erro de conexão', 'Não foi possível salvar a voz no banco de dados.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const steps = [
    { num: 1, title: 'Captação Base', desc: 'Gravador / Upload' },
    { num: 2, title: 'Análise de Áudio', desc: 'Denoise & Qualidade' },
    { num: 3, title: 'Treino Neural', desc: 'Extração Timbrística' },
    { num: 4, title: 'Ativação', desc: 'Teste & Registro' },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Page Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border)] pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--lime)] font-mono">
              Laboratório de Clonagem
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[var(--surface2)] text-[var(--purple)] border border-[var(--purple)]/30 font-mono font-bold">
              AI Voice Synthesis
            </span>
          </div>
          <h1 className="text-3xl font-bold font-display text-[var(--text)]">
            Clonar Nova Voz
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Forneça pelo menos 10 segundos de áudio limpo para criar um modelo neural ultrarrealista.
          </p>
        </div>
      </div>

      {/* Stepper Navigation */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-[var(--surface)] p-2 rounded-2xl border border-[var(--border)]">
        {steps.map((step) => {
          const isDone = currentStep > step.num;
          const isCurrent = currentStep === step.num;

          return (
            <div
              key={step.num}
              onClick={() => {
                if (isDone) setCurrentStep(step.num);
              }}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                isDone ? 'cursor-pointer hover:bg-[var(--surface2)]' : ''
              } ${
                isCurrent
                  ? 'bg-[var(--surface2)] border border-[var(--lime)] shadow-sm'
                  : 'opacity-70'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-colors shrink-0 ${
                  isDone
                    ? 'bg-[var(--lime)] text-black'
                    : isCurrent
                    ? 'bg-[var(--purple)] text-white'
                    : 'bg-[var(--bg)] text-[var(--muted)] border border-[var(--border)]'
                }`}
              >
                {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : step.num}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold font-display text-[var(--text)] truncate">
                  {step.title}
                </div>
                <div className="text-[10px] text-[var(--muted)] truncate">{step.desc}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* STEP 1: CAPTAÇÃO DE ÁUDIO & METADADOS */}
      {currentStep === 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-200">
          {/* Metadata Card */}
          <div className="lg:col-span-6 lima-card space-y-4">
            <h3 className="text-lg font-bold font-display flex items-center gap-2">
              <Tag className="w-4 h-4 text-[var(--lime)]" />
              1. Identificação da Voz
            </h3>

            <div>
              <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                Nome da Voz *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Amanda - Apresentadora Tech"
                className="w-full lima-input"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                Descrição do Perfil
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Voz jovem, comunicativa, tom entusiasmado e natural."
                rows={2}
                className="w-full lima-input resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                  Idioma Base
                </label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full lima-input"
                >
                  <option value="pt-BR">Português (Brasil)</option>
                  <option value="en-US">English (United States)</option>
                  <option value="es-ES">Español (España)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                  Categoria
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full lima-input"
                >
                  <option value="conversational">Conversacional</option>
                  <option value="narrative">Narrativa / Livros</option>
                  <option value="dynamic">Dinâmica / Redes</option>
                  <option value="cinematic">Cinemática</option>
                  <option value="support">Atendimento</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                  Gênero
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full lima-input"
                >
                  <option value="female">Feminino</option>
                  <option value="male">Masculino</option>
                  <option value="non-binary">Neutro</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                  Faixa Etária
                </label>
                <select
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full lima-input"
                >
                  <option value="young">Jovem (18-30)</option>
                  <option value="adult">Adulta (30-50)</option>
                  <option value="senior">Sênior (50+)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[var(--subtle)] uppercase mb-1">
                Tags (separadas por vírgula)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Ex: Energética, Podcast, Didática"
                className="w-full lima-input"
              />
            </div>
          </div>

          {/* Audio Input Recording Card */}
          <div className="lg:col-span-6 lima-card flex flex-col justify-between space-y-6">
            <div>
              <h3 className="text-lg font-bold font-display flex items-center gap-2 mb-2">
                <Mic className="w-4 h-4 text-[var(--purple)]" />
                2. Capturar Amostra de Voz
              </h3>
              <p className="text-xs text-[var(--muted)] mb-4">
                Grave com seu microfone ou faça upload de um arquivo de áudio de boa qualidade sem ruído de fundo.
              </p>

              {/* Recording controls */}
              <div className="bg-[var(--bg)] p-6 rounded-2xl border border-[var(--border)] text-center flex flex-col items-center justify-center space-y-4">
                {isRecording ? (
                  <div className="flex flex-col items-center space-y-3">
                    <div className="w-16 h-16 rounded-full bg-red-500/20 border-2 border-[var(--red)] flex items-center justify-center animate-pulse">
                      <Mic className="w-8 h-8 text-[var(--red)]" />
                    </div>
                    <div className="font-mono font-bold text-xl text-[var(--red)]">
                      00:{recordingDuration < 10 ? `0${recordingDuration}` : recordingDuration}
                    </div>
                    <p className="text-xs text-[var(--muted)]">Gravando... Fale claramente em voz alta.</p>
                    <button
                      onClick={stopRecording}
                      className="btn-destructive px-6 py-2 rounded-xl text-xs flex items-center gap-2"
                    >
                      <Square className="w-3.5 h-3.5 fill-white" />
                      Parar Gravação
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center space-y-3">
                    <button
                      onClick={startRecording}
                      className="w-16 h-16 rounded-full bg-[var(--lime)] hover:scale-105 transition-transform flex items-center justify-center text-black shadow-lg shadow-[var(--lime)]/20"
                    >
                      <Mic className="w-7 h-7 fill-black" />
                    </button>
                    <div className="text-sm font-semibold text-[var(--text)]">
                      Gravar pelo Microfone
                    </div>
                    <p className="text-xs text-[var(--subtle)]">
                      Dica: Leia uma frase longa de 10 a 20 segundos.
                    </p>
                  </div>
                )}
              </div>

              {/* Upload Alternative */}
              <div className="relative mt-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[var(--border)]" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-[var(--surface)] px-2 text-[var(--subtle)] font-mono">ou</span>
                </div>
              </div>

              <div className="mt-4">
                <label className="flex items-center justify-center gap-2 p-4 rounded-xl border border-dashed border-[var(--border)] bg-[var(--bg)] hover:border-[var(--lime)] cursor-pointer transition-colors text-xs text-[var(--muted)] hover:text-[var(--text)]">
                  <Upload className="w-4 h-4 text-[var(--lime)]" />
                  <span>
                    {audioFile ? `Selecionado: ${audioFile.name}` : 'Upload de arquivo (MP3, WAV, M4A, OGG)'}
                  </span>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Sample audio preview player */}
              {audioUrl && (
                <div className="mt-4 p-3 rounded-xl bg-[var(--surface2)] border border-[var(--lime)]/40 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-[var(--lime)]" />
                    <span className="text-xs font-semibold text-[var(--text)]">Amostra Carregada</span>
                  </div>
                  <audio src={audioUrl} controls className="h-8 max-w-[200px]" />
                </div>
              )}
            </div>

            <div className="flex justify-end pt-4 border-t border-[var(--border)]">
              <button
                onClick={() => {
                  if (!name) {
                    addToast('Preencha o Nome', 'Informe o nome da voz para prosseguir.', 'warning');
                    return;
                  }
                  if (!audioUrl) {
                    addToast('Grave ou envie um áudio', 'Uma amostra sonora é necessária.', 'warning');
                    return;
                  }
                  setCurrentStep(2);
                }}
                className="btn-primary px-6 py-2.5 rounded-xl text-xs flex items-center gap-2"
              >
                <span>Avançar para Análise</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: SPECTRAL ANALYSIS & CLEANUP */}
      {currentStep === 2 && (
        <div className="lima-card space-y-6 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
            <div>
              <h3 className="text-lg font-bold font-display flex items-center gap-2">
                <Activity className="w-5 h-5 text-[var(--lime)]" />
                Análise de Frequência & Limpeza Timbrística
              </h3>
              <p className="text-xs text-[var(--muted)]">
                Filtre ruídos de fundo e garanta alinhamento perfeito de pitch para o modelo neural.
              </p>
            </div>
            <span className="badge-lime text-xs px-3 py-1 font-mono font-bold rounded-full">
              Score: {clarityScore}% Clareza
            </span>
          </div>

          {/* Dynamic Wave Visualizer Spectrum Display */}
          <div className="bg-[var(--bg)] p-6 rounded-2xl border border-[var(--border)] space-y-4">
            <div className="flex items-center justify-between text-xs font-mono text-[var(--subtle)]">
              <span>Espectrograma FF-Transform</span>
              <span className="text-[var(--lime)]">{noiseLevel}</span>
            </div>

            <div className="h-28 flex items-center justify-between gap-1 px-4 bg-[var(--surface2)] rounded-xl border border-[var(--border)] overflow-hidden">
              {Array.from({ length: 48 }).map((_, i) => {
                const heightPct = Math.floor(Math.sin((i + 1) * 0.4) * 40 + 50);
                return (
                  <div
                    key={i}
                    className="w-full bg-[var(--lime)]/80 rounded-t transition-all duration-300 hover:bg-[var(--lime)]"
                    style={{
                      height: `${heightPct}%`,
                      opacity: i % 2 === 0 ? 0.9 : 0.6,
                    }}
                  />
                );
              })}
            </div>
          </div>

          {/* Cleanup Toggles */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div
              onClick={() => setDenoiseEnabled(!denoiseEnabled)}
              className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                denoiseEnabled
                  ? 'border-[var(--lime)] bg-[var(--surface2)]'
                  : 'border-[var(--border)] bg-[var(--bg)]'
              }`}
            >
              <div>
                <div className="font-semibold text-sm font-display text-[var(--text)]">
                  Supressão de Ruído Ativa (Denoise)
                </div>
                <div className="text-xs text-[var(--muted)] mt-0.5">
                  Filtro estático inteligente de fundo (-62dB)
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                  denoiseEnabled ? 'bg-[var(--lime)] border-[var(--lime)] text-black' : 'border-[var(--subtle)]'
                }`}
              >
                {denoiseEnabled && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>

            <div
              onClick={() => setTrimSilence(!trimSilence)}
              className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                trimSilence
                  ? 'border-[var(--purple)] bg-[var(--surface2)]'
                  : 'border-[var(--border)] bg-[var(--bg)]'
              }`}
            >
              <div>
                <div className="font-semibold text-sm font-display text-[var(--text)]">
                  Remoção de Silêncio Inicial/Final
                </div>
                <div className="text-xs text-[var(--muted)] mt-0.5">
                  Ajusta o padding para otimizar latência de síntese
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                  trimSilence ? 'bg-[var(--purple)] border-[var(--purple)] text-white' : 'border-[var(--subtle)]'
                }`}
              >
                {trimSilence && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>
          </div>

          {/* Footer controls */}
          <div className="flex items-center justify-between pt-4 border-t border-[var(--border)]">
            <button
              onClick={() => setCurrentStep(1)}
              className="btn-secondary px-5 py-2.5 rounded-xl text-xs flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
            <button
              onClick={() => {
                setCurrentStep(3);
                runNeuralTraining();
              }}
              className="btn-primary px-6 py-2.5 rounded-xl text-xs flex items-center gap-2"
            >
              <span>Iniciar Treinamento Neural</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: NEURAL TRAINING SIMULATION */}
      {currentStep === 3 && (
        <div className="lima-card space-y-6 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
            <div>
              <h3 className="text-lg font-bold font-display flex items-center gap-2">
                <Cpu className="w-5 h-5 text-[var(--purple)]" />
                Treinamento do Modelo de Voz
              </h3>
              <p className="text-xs text-[var(--muted)]">
                Extração de embeddings de voz e ajuste de pesos da rede neural síntese.
              </p>
            </div>
            <span className="font-mono text-sm font-bold text-[var(--lime)]">
              Epoch {currentEpoch} / 100
            </span>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-xs font-mono mb-2">
              <span className="text-[var(--muted)]">Progresso da Extração</span>
              <span className="text-[var(--text)] font-bold">{trainingProgress}%</span>
            </div>
            <div className="w-full h-3 bg-[var(--surface2)] rounded-full overflow-hidden p-0.5 border border-[var(--border)]">
              <div
                className="h-full bg-gradient-to-r from-[var(--purple)] to-[var(--lime)] rounded-full transition-all duration-300"
                style={{ width: `${trainingProgress}%` }}
              />
            </div>
          </div>

          {/* Loss Terminal Chart Output */}
          <div className="bg-[#0A0A0A] p-4 rounded-xl border border-[var(--border)] font-mono text-xs text-emerald-400 space-y-1 h-48 overflow-y-auto">
            {logs.map((log, index) => (
              <div key={index} className="leading-relaxed">
                {log}
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-[var(--border)]">
            <button
              onClick={() => setCurrentStep(2)}
              disabled={isTraining}
              className="btn-secondary px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 disabled:opacity-50"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
            <button
              onClick={() => setCurrentStep(4)}
              disabled={isTraining || trainingProgress < 100}
              className="btn-primary px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 disabled:opacity-50"
            >
              <span>Validação e Teste Final</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: VERIFICATION & SAVE TO DB */}
      {currentStep === 4 && (
        <div className="lima-card space-y-6 animate-in fade-in duration-200">
          <div className="border-b border-[var(--border)] pb-4">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 className="w-5 h-5 text-[var(--lime)]" />
              <h3 className="text-lg font-bold font-display">
                Voz Clonada Pronta para Teste
              </h3>
            </div>
            <p className="text-xs text-[var(--muted)]">
              Gere um áudio de demonstração com o texto de teste para conferir a naturalidade do seu novo modelo.
            </p>
          </div>

          {/* Voice Summary Badge */}
          <div className="p-4 rounded-xl bg-[var(--surface2)] border border-[var(--border)] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[var(--purple)] text-white flex items-center justify-center font-bold font-display text-base">
                {name.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="text-sm font-bold font-display text-[var(--text)]">{name}</div>
                <div className="text-xs text-[var(--muted)]">{language} • {category} • {gender}</div>
              </div>
            </div>
            <span className="badge-lime text-xs font-bold px-3 py-1 rounded-full">
              Fidelidade: {clarityScore}%
            </span>
          </div>

          {/* Test Sentence Generator */}
          <div>
            <label className="block text-xs font-semibold uppercase text-[var(--subtle)] mb-1">
              Texto de Teste
            </label>
            <textarea
              value={testText}
              onChange={(e) => setTestText(e.target.value)}
              rows={2}
              className="w-full lima-input resize-none"
            />
            <button
              onClick={handleTestVoice}
              className="mt-3 btn-accent px-5 py-2 rounded-xl text-xs flex items-center gap-2"
            >
              {isPlayingTest ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>Pausar Demonstração</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Ouvir Voz Clonada</span>
                </>
              )}
            </button>
          </div>

          {/* Final Action Button */}
          <div className="flex items-center justify-between pt-4 border-t border-[var(--border)]">
            <button
              onClick={() => setCurrentStep(3)}
              className="btn-secondary px-5 py-2.5 rounded-xl text-xs flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Treinamento</span>
            </button>
            <button
              onClick={handleSaveVoice}
              disabled={isSaving}
              className="btn-primary px-8 py-3 rounded-xl text-sm font-bold flex items-center gap-2"
            >
              {isSaving ? (
                <span>Salvando Modelo no Banco...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Salvar Voz na Biblioteca</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
