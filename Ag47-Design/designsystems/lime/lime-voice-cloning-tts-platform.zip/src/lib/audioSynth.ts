// Client-side Web Audio & Speech Synthesis Helper
export function speakTextWebSpeech(
  text: string,
  options: {
    lang?: string;
    pitch?: number;
    rate?: number;
    onEnd?: () => void;
  }
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return false;
  }

  window.speechSynthesis.cancel(); // Stop any current speech

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = options.lang || 'pt-BR';
  
  // Convert pitch range (-1.0 to 1.0) to utterance pitch (0.5 to 1.5)
  const normPitch = 1.0 + (options.pitch || 0);
  utterance.pitch = Math.max(0.5, Math.min(2.0, normPitch));

  // Convert rate/speed
  utterance.rate = Math.max(0.5, Math.min(2.0, options.rate || 1.0));

  // Try to pick a voice matching language if available
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(v => v.lang.startsWith(utterance.lang.substring(0, 2))) || voices[0];
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  if (options.onEnd) {
    utterance.onend = options.onEnd;
    utterance.onerror = options.onEnd;
  }

  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopSpeech() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

// Synthesize a WAV Audio Blob dynamically in browser using Web Audio API offline context
export async function createAudioBlobFromText(text: string, pitchOffset: number = 0, speed: number = 1.0): Promise<Blob> {
  const sampleRate = 44100;
  const duration = Math.max(1.5, Math.min(15, (text.split(' ').length / 3) / speed));
  const totalFrames = Math.floor(sampleRate * duration);

  const offlineContext = new OfflineAudioContext(1, totalFrames, sampleRate);

  // Generate multi-harmonic vocal synth sound representing speech sequence
  const numPhonemes = Math.max(4, Math.floor(text.length / 3));
  const phonemeDur = duration / numPhonemes;

  const masterGain = offlineContext.createGain();
  masterGain.gain.setValueAtTime(0.01, 0);

  // Base frequency tuned by pitchOffset
  const baseFreq = 180 * Math.pow(2, pitchOffset / 12);

  for (let i = 0; i < numPhonemes; i++) {
    const startTime = i * phonemeDur;
    const osc = offlineContext.createOscillator();
    const oscGain = offlineContext.createGain();

    // Alternate harmonic modulation
    const charCode = text.charCodeAt(i % text.length) || 100;
    const freqShift = (charCode % 50) - 25;
    
    osc.type = i % 2 === 0 ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(baseFreq + freqShift, startTime);
    osc.frequency.exponentialRampToValueAtTime(baseFreq + (freqShift * 0.8), startTime + phonemeDur);

    oscGain.gain.setValueAtTime(0.001, startTime);
    oscGain.gain.linearRampToValueAtTime(0.2, startTime + (phonemeDur * 0.2));
    oscGain.gain.exponentialRampToValueAtTime(0.001, startTime + phonemeDur);

    osc.connect(oscGain);
    oscGain.connect(masterGain);

    osc.start(startTime);
    osc.stop(startTime + phonemeDur);
  }

  masterGain.gain.linearRampToValueAtTime(0.3, 0.1);
  masterGain.gain.exponentialRampToValueAtTime(0.001, duration - 0.05);

  masterGain.connect(offlineContext.destination);

  const renderedBuffer = await offlineContext.startRendering();
  
  // Encode AudioBuffer to WAV format
  return bufferToWavBlob(renderedBuffer);
}

function bufferToWavBlob(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  let channels: Float32Array[] = [];
  let sampleRate = buffer.sampleRate;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }

  // write WAVE header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"
  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2); // block-align
  setUint16(16); // 16-bit
  setUint32(0x61746164); // "data" chunk
  setUint32(length - pos - 4); // chunk length

  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (offset < buffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      let sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([out], { type: 'audio/wav' });
}
