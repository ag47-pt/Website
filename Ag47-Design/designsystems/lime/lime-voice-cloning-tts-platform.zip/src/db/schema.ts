import { pgTable, text, serial, integer, real, boolean, timestamp, jsonb } from 'drizzle-orm/pg-core';

export const voices = pgTable('voices', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  category: text('category').notNull().default('conversational'), // narrative, conversational, cinematic, dynamic, support
  language: text('language').notNull().default('pt-BR'), // pt-BR, en-US, es-ES, etc.
  gender: text('gender').notNull().default('female'), // female, male, non-binary
  age: text('age').notNull().default('adult'), // young, adult, senior
  tags: jsonb('tags').$type<string[]>().notNull().default([]),
  isPreset: boolean('is_preset').notNull().default(false),
  avatarUrl: text('avatar_url'),
  sampleAudioUrl: text('sample_audio_url'), // data url or sample audio link
  qualityScore: integer('quality_score').notNull().default(95),
  noiseLevel: text('noise_level').notNull().default('Minimal (-58dB)'),
  clarityScore: integer('clarity_score').notNull().default(98),
  stabilityDefault: integer('stability_default').notNull().default(75),
  similarityDefault: integer('similarity_default').notNull().default(85),
  pitchShiftDefault: real('pitch_shift_default').notNull().default(0),
  speedDefault: real('speed_default').notNull().default(1.0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const generations = pgTable('generations', {
  id: serial('id').primaryKey(),
  voiceId: integer('voice_id').notNull(),
  voiceName: text('voice_name').notNull(),
  text: text('text').notNull(),
  audioUrl: text('audio_url'), // synthesized base64/data url or audio stream
  duration: real('duration').notNull().default(0),
  language: text('language').notNull().default('pt-BR'),
  emotion: text('emotion').notNull().default('neutral'), // neutral, energetic, calm, dramatic, cheerful, serious
  speed: real('speed').notNull().default(1.0),
  pitch: real('pitch').notNull().default(0.0),
  stability: integer('stability').notNull().default(75),
  similarity: integer('similarity').notNull().default(85),
  characterCount: integer('character_count').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const speechProjects = pgTable('speech_projects', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description'),
  voiceId: integer('voice_id').notNull(),
  status: text('status').notNull().default('draft'), // draft, processing, completed
  scriptBlocks: jsonb('script_blocks').$type<Array<{ id: string; speaker: string; voiceId: number; text: string; audioUrl?: string; duration?: number }>>().notNull().default([]),
  totalDuration: real('total_duration').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const apiKeys = pgTable('api_keys', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  key: text('key').notNull(),
  requestsCount: integer('requests_count').notNull().default(0),
  lastUsedAt: timestamp('last_used_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
