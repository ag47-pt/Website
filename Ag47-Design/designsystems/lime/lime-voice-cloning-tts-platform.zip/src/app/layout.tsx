import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Lima Voice Engine · Voice Cloning & TTS Framework v1.2',
  description:
    'Framework de clonagem de voz e conversão de texto para fala de alta fidelidade construído com o Lima Design System v1.2.',
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" data-theme="dark">
      <head>
        <meta name="theme-color" content="#C2F500" />
      </head>
      <body className="antialiased selection:bg-[#C2F500] selection:text-black">
        {children}
      </body>
    </html>
  );
}
