'use client';

import React, { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { TTSStudio, VoiceModel } from '@/components/TTSStudio';
import { VoiceCloner } from '@/components/VoiceCloner';
import { VoiceLibrary } from '@/components/VoiceLibrary';
import { SpeechProjects } from '@/components/SpeechProjects';
import { DeveloperStudio } from '@/components/DeveloperStudio';
import { DesignSystemShowcase } from '@/components/DesignSystemShowcase';
import { ToastContainer, ToastItem } from '@/components/ToastContainer';
import { CmdKModal } from '@/components/CmdKModal';
import { ThemeCustomizerModal } from '@/components/ThemeCustomizerModal';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('tts');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [preset, setPreset] = useState('lima-default');

  // Voices list
  const [voices, setVoices] = useState<VoiceModel[]>([]);
  const [selectedVoiceId, setSelectedVoiceId] = useState<number | undefined>(undefined);
  const [loadingVoices, setLoadingVoices] = useState(true);

  // Modals & Toasts
  const [isCmdKOpen, setIsCmdKOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Add toast helper
  const addToast = (
    title: string,
    message?: string,
    type: 'success' | 'error' | 'info' | 'warning' = 'info'
  ) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast: ToastItem = { id, title, message, type };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Fetch voices list from API
  const fetchVoices = async () => {
    setLoadingVoices(true);
    try {
      const res = await fetch('/api/voices');
      const data = await res.json();
      if (data.success) {
        setVoices(data.data);
        if (!selectedVoiceId && data.data.length > 0) {
          setSelectedVoiceId(data.data[0].id);
        }
      }
    } catch (err) {
      console.error('Error fetching voices:', err);
    } finally {
      setLoadingVoices(false);
    }
  };

  useEffect(() => {
    fetchVoices();
  }, []);

  // Theme persistence
  useEffect(() => {
    const savedTheme = localStorage.getItem('lima-theme') as 'dark' | 'light' | null;
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.setAttribute('data-theme', savedTheme);
    }
  }, []);

  const handleSetTheme = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    localStorage.setItem('lima-theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex flex-col font-body selection:bg-[var(--lime)] selection:text-black transition-colors duration-200">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        setTheme={handleSetTheme}
        onOpenCmdK={() => setIsCmdKOpen(true)}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        voicesCount={voices.length}
      />

      {/* Main Container Content */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'tts' && (
          <TTSStudio
            voices={voices}
            selectedVoiceId={selectedVoiceId}
            onSelectVoice={(id) => setSelectedVoiceId(id)}
            addToast={addToast}
          />
        )}

        {activeTab === 'cloner' && (
          <VoiceCloner
            onVoiceCreated={() => {
              fetchVoices();
              setActiveTab('library');
            }}
            addToast={addToast}
          />
        )}

        {activeTab === 'library' && (
          <VoiceLibrary
            voices={voices}
            onSelectVoiceForTTS={(id) => {
              setSelectedVoiceId(id);
              setActiveTab('tts');
            }}
            onNavigateToCloner={() => setActiveTab('cloner')}
            onRefreshVoices={fetchVoices}
            addToast={addToast}
          />
        )}

        {activeTab === 'projects' && (
          <SpeechProjects voices={voices} addToast={addToast} />
        )}

        {activeTab === 'developer' && <DeveloperStudio addToast={addToast} />}

        {activeTab === 'design-system' && <DesignSystemShowcase />}
      </main>

      {/* Footer */}
      <footer className="border-t border-[var(--border)] bg-[var(--surface)] py-6 px-4">
        <div className="max-w-[1400px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[var(--muted)]">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-[var(--text)]">Lima System</span>
            <span>· v1.2</span>
            <span className="text-[var(--subtle)]">
              High contrast, full energy voice synthesis framework.
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono">
            <button
              onClick={() => setActiveTab('design-system')}
              className="hover:text-[var(--lime)] transition-colors"
            >
              System Guidelines
            </button>
            <button
              onClick={() => setActiveTab('developer')}
              className="hover:text-[var(--lime)] transition-colors"
            >
              API Reference
            </button>
            <span>WCAG 2.1 AA</span>
          </div>
        </div>
      </footer>

      {/* Modals & Overlays */}
      <CmdKModal
        isOpen={isCmdKOpen}
        onClose={() => setIsCmdKOpen(false)}
        onNavigate={(tab) => setActiveTab(tab)}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
      />

      <ThemeCustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        theme={theme}
        setTheme={handleSetTheme}
        preset={preset}
        setPreset={setPreset}
      />

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
