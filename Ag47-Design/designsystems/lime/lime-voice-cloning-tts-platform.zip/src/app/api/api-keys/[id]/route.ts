import { NextResponse } from 'next/server';
import { db } from '@/db';
import { apiKeys } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const keyId = parseInt(id, 10);

    if (isNaN(keyId)) {
      return NextResponse.json({ success: false, error: 'ID inválido.' }, { status: 400 });
    }

    await db.delete(apiKeys).where(eq(apiKeys.id, keyId));
    return NextResponse.json({ success: true, message: 'Chave de API revogada com sucesso.' });
  } catch (error) {
    console.error('Error deleting API key:', error);
    return NextResponse.json({ success: false, error: 'Erro ao revogar chave de API.' }, { status: 500 });
  }
}
