import { NextResponse } from 'next/server';
import { db } from '@/db';
import { apiKeys } from '@/db/schema';
import { desc } from 'drizzle-orm';
import crypto from 'crypto';

export async function GET() {
  try {
    const list = await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt));

    if (list.length === 0) {
      // Seed default dev key
      const keyStr = 'lima_live_' + crypto.randomBytes(16).toString('hex');
      await db.insert(apiKeys).values({
        name: 'Chave do App Principal (Production)',
        key: keyStr,
        requestsCount: 1420,
        lastUsedAt: new Date(),
      });
      const updated = await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt));
      return NextResponse.json({ success: true, data: updated });
    }

    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error('Error fetching API keys:', error);
    return NextResponse.json({ success: false, error: 'Erro ao carregar chaves API.' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name = 'Nova Chave de API' } = body;

    const newKeyStr = 'lima_live_' + crypto.randomBytes(16).toString('hex');

    const created = await db.insert(apiKeys).values({
      name,
      key: newKeyStr,
      requestsCount: 0,
    }).returning();

    return NextResponse.json({ success: true, data: created[0] });
  } catch (error) {
    console.error('Error generating API key:', error);
    return NextResponse.json({ success: false, error: 'Erro ao gerar nova chave de API.' }, { status: 500 });
  }
}
