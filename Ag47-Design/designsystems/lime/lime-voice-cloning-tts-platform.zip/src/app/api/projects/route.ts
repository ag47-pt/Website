import { NextResponse } from 'next/server';
import { db } from '@/db';
import { speechProjects, voices } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';

export async function GET() {
  try {
    const list = await db.select().from(speechProjects).orderBy(desc(speechProjects.updatedAt));

    if (list.length === 0) {
      // Seed default project if empty
      const allVoices = await db.select().from(voices).limit(1);
      const defaultVoiceId = allVoices[0]?.id || 1;

      await db.insert(speechProjects).values({
        title: 'Apresentação de Produto Lima Voice Engine',
        description: 'Projeto de áudio multi-trechos para a campanha de lançamento do framework de clonagem.',
        voiceId: defaultVoiceId,
        status: 'completed',
        scriptBlocks: [
          {
            id: 'block-1',
            speaker: 'Mariana Silva',
            voiceId: defaultVoiceId,
            text: 'Bem-vindo ao Lima Voice Engine, a plataforma definitiva para clonagem de voz e conversão de texto para fala em alta fidelidade.',
            duration: 5.2
          },
          {
            id: 'block-2',
            speaker: 'Professor Carlos',
            voiceId: defaultVoiceId + 1,
            text: 'Com nosso modelo neural de última geração, você consegue sintetizar vozes extremamente naturais em segundos.',
            duration: 6.1
          }
        ],
        totalDuration: 11.3
      });

      const updated = await db.select().from(speechProjects).orderBy(desc(speechProjects.updatedAt));
      return NextResponse.json({ success: true, data: updated });
    }

    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error('Error fetching projects:', error);
    return NextResponse.json({ success: false, error: 'Erro ao listar projetos.' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { title, description, voiceId, scriptBlocks = [] } = body;

    if (!title) {
      return NextResponse.json({ success: false, error: 'Título é obrigatório.' }, { status: 400 });
    }

    const totalDuration = scriptBlocks.reduce((acc: number, b: any) => acc + (b.duration || 3), 0);

    const newProj = await db.insert(speechProjects).values({
      title,
      description,
      voiceId: voiceId || 1,
      status: 'draft',
      scriptBlocks,
      totalDuration,
    }).returning();

    return NextResponse.json({ success: true, data: newProj[0] });
  } catch (error) {
    console.error('Error creating project:', error);
    return NextResponse.json({ success: false, error: 'Erro ao criar projeto.' }, { status: 500 });
  }
}
