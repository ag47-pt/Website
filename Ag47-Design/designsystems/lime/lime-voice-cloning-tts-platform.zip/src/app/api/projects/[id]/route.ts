import { NextResponse } from 'next/server';
import { db } from '@/db';
import { speechProjects } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projId = parseInt(id, 10);

    if (isNaN(projId)) {
      return NextResponse.json({ success: false, error: 'ID inválido.' }, { status: 400 });
    }

    const body = await req.json();
    const { title, description, scriptBlocks, status } = body;

    const totalDuration = scriptBlocks
      ? scriptBlocks.reduce((acc: number, b: any) => acc + (b.duration || 3), 0)
      : 0;

    const updated = await db
      .update(speechProjects)
      .set({
        ...(title ? { title } : {}),
        ...(description !== undefined ? { description } : {}),
        ...(scriptBlocks ? { scriptBlocks, totalDuration } : {}),
        ...(status ? { status } : {}),
        updatedAt: new Date(),
      })
      .where(eq(speechProjects.id, projId))
      .returning();

    return NextResponse.json({ success: true, data: updated[0] });
  } catch (error) {
    console.error('Error updating project:', error);
    return NextResponse.json({ success: false, error: 'Erro ao atualizar projeto.' }, { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projId = parseInt(id, 10);

    if (isNaN(projId)) {
      return NextResponse.json({ success: false, error: 'ID inválido.' }, { status: 400 });
    }

    await db.delete(speechProjects).where(eq(speechProjects.id, projId));
    return NextResponse.json({ success: true, message: 'Projeto removido.' });
  } catch (error) {
    console.error('Error deleting project:', error);
    return NextResponse.json({ success: false, error: 'Erro ao remover projeto.' }, { status: 500 });
  }
}
