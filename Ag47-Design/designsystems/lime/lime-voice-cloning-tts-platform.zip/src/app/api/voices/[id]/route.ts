import { NextResponse } from 'next/server';
import { db } from '@/db';
import { voices } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const voiceId = parseInt(id, 10);

    if (isNaN(voiceId)) {
      return NextResponse.json({ success: false, error: 'ID de voz inválido.' }, { status: 400 });
    }

    // Don't allow deleting presets if user tries
    const target = await db.select().from(voices).where(eq(voices.id, voiceId)).limit(1);
    if (!target.length) {
      return NextResponse.json({ success: false, error: 'Voz não encontrada.' }, { status: 404 });
    }

    if (target[0].isPreset) {
      return NextResponse.json({ success: false, error: 'Não é possível excluir vozes padrão do sistema.' }, { status: 403 });
    }

    await db.delete(voices).where(eq(voices.id, voiceId));

    return NextResponse.json({ success: true, message: 'Voz removida com sucesso.' });
  } catch (error) {
    console.error('Error deleting voice:', error);
    return NextResponse.json({ success: false, error: 'Erro ao excluir voz.' }, { status: 500 });
  }
}
