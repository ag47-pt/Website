import { NextResponse } from 'next/server';
import { db } from '@/db';
import { voices } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';

const INITIAL_PRESET_VOICES = [
  {
    name: 'Mariana Silva',
    description: 'Voz feminina clara, profissional e calorosa. Perfeita para apresentações, treinamentos corporativos e vídeos de produto.',
    category: 'conversational',
    language: 'pt-BR',
    gender: 'female',
    age: 'adult',
    tags: ['Profissional', 'Apresentações', 'Límpida', 'Natural'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    qualityScore: 99,
    noiseLevel: 'Ultra Low (-64dB)',
    clarityScore: 98,
    stabilityDefault: 78,
    similarityDefault: 88,
    pitchShiftDefault: 0,
    speedDefault: 1.0,
  },
  {
    name: 'Professor Carlos',
    description: 'Voz masculina grave, aveludada e bastante articulada. Ideal para audiolivros, tutoriais profundos e documentários.',
    category: 'narrative',
    language: 'pt-BR',
    gender: 'male',
    age: 'adult',
    tags: ['Grave', 'Audiolivros', 'Documentários', 'Educacional'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    qualityScore: 97,
    noiseLevel: 'Minimal (-60dB)',
    clarityScore: 96,
    stabilityDefault: 82,
    similarityDefault: 90,
    pitchShiftDefault: -0.1,
    speedDefault: 0.95,
  },
  {
    name: 'Lucas Creator',
    description: 'Voz jovem, enérgica e envolvente. Projetada para podcasts dinâmicos, anúncios, Reels e TikTok.',
    category: 'dynamic',
    language: 'pt-BR',
    gender: 'male',
    age: 'young',
    tags: ['Energética', 'Podcasts', 'Jovem', 'Anúncios'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    qualityScore: 96,
    noiseLevel: 'Minimal (-58dB)',
    clarityScore: 95,
    stabilityDefault: 70,
    similarityDefault: 82,
    pitchShiftDefault: 0.05,
    speedDefault: 1.05,
  },
  {
    name: 'Elena Vance',
    description: 'Clear, elegant native English female voice with standard accent. Exceptional clarity for global voiceovers.',
    category: 'cinematic',
    language: 'en-US',
    gender: 'female',
    age: 'adult',
    tags: ['English', 'Narrative', 'Elegant', 'Voiceover'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    qualityScore: 98,
    noiseLevel: 'Ultra Low (-62dB)',
    clarityScore: 97,
    stabilityDefault: 80,
    similarityDefault: 86,
    pitchShiftDefault: 0,
    speedDefault: 1.0,
  },
  {
    name: 'Gabriel Santos',
    description: 'Voz masculina conversacional e expressiva, com cadência perfeita para storytelling e gravações emocionais.',
    category: 'conversational',
    language: 'pt-BR',
    gender: 'male',
    age: 'adult',
    tags: ['Storytelling', 'Emocional', 'Atraente', 'Radio'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    qualityScore: 95,
    noiseLevel: 'Minimal (-56dB)',
    clarityScore: 94,
    stabilityDefault: 72,
    similarityDefault: 84,
    pitchShiftDefault: 0,
    speedDefault: 1.0,
  },
  {
    name: 'Sofia Suporte',
    description: 'Voz calma, empática e didática. Criada para assistentes virtuais, URA de atendimento e treinamentos.',
    category: 'support',
    language: 'pt-BR',
    gender: 'female',
    age: 'young',
    tags: ['Assistente', 'Calma', 'Didática', 'Atendimento'],
    isPreset: true,
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    qualityScore: 98,
    noiseLevel: 'Ultra Low (-65dB)',
    clarityScore: 99,
    stabilityDefault: 85,
    similarityDefault: 92,
    pitchShiftDefault: 0.02,
    speedDefault: 1.0,
  },
];

export async function GET() {
  try {
    let list = await db.select().from(voices).orderBy(desc(voices.isPreset), desc(voices.createdAt));

    // If database is empty, seed initial presets
    if (list.length === 0) {
      for (const preset of INITIAL_PRESET_VOICES) {
        await db.insert(voices).values(preset);
      }
      list = await db.select().from(voices).orderBy(desc(voices.isPreset), desc(voices.createdAt));
    }

    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error('Error fetching voices:', error);
    return NextResponse.json({ success: false, error: 'Erro ao buscar vozes.' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      name,
      description,
      category = 'conversational',
      language = 'pt-BR',
      gender = 'female',
      age = 'adult',
      tags = [],
      sampleAudioUrl,
      qualityScore = 96,
      noiseLevel = 'Minimal (-58dB)',
      clarityScore = 95,
      stabilityDefault = 75,
      similarityDefault = 85,
      pitchShiftDefault = 0,
      speedDefault = 1.0,
    } = body;

    if (!name || !description) {
      return NextResponse.json(
        { success: false, error: 'Nome e descrição são obrigatórios.' },
        { status: 400 }
      );
    }

    const newVoice = await db.insert(voices).values({
      name,
      description,
      category,
      language,
      gender,
      age,
      tags,
      isPreset: false,
      sampleAudioUrl: sampleAudioUrl || null,
      qualityScore,
      noiseLevel,
      clarityScore,
      stabilityDefault,
      similarityDefault,
      pitchShiftDefault,
      speedDefault,
    }).returning();

    return NextResponse.json({ success: true, data: newVoice[0] });
  } catch (error) {
    console.error('Error cloning voice:', error);
    return NextResponse.json({ success: false, error: 'Erro ao criar clonagem de voz.' }, { status: 500 });
  }
}
