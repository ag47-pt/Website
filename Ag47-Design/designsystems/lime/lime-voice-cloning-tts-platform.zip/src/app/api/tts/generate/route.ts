import { NextResponse } from 'next/server';
import { db } from '@/db';
import { generations, voices } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      voiceId,
      text,
      language = 'pt-BR',
      emotion = 'neutral',
      speed = 1.0,
      pitch = 0.0,
      stability = 75,
      similarity = 85,
    } = body;

    if (!voiceId || !text || text.trim() === '') {
      return NextResponse.json(
        { success: false, error: 'Por favor, selecione uma voz e insira o texto para gerar o áudio.' },
        { status: 400 }
      );
    }

    const voice = await db.select().from(voices).where(eq(voices.id, Number(voiceId))).limit(1);
    const selectedVoice = voice[0] || { name: 'Voz Sintética' };

    // Calculate approximate speech duration based on text length and speed
    const words = text.trim().split(/\s+/).length;
    const estimatedDurationSec = Math.max(1.2, parseFloat(((words / 3.2) / speed).toFixed(1)));

    const newGen = await db
      .insert(generations)
      .values({
        voiceId: Number(voiceId),
        voiceName: selectedVoice.name,
        text: text.trim(),
        duration: estimatedDurationSec,
        language,
        emotion,
        speed: parseFloat(speed),
        pitch: parseFloat(pitch),
        stability: Number(stability),
        similarity: Number(similarity),
        characterCount: text.trim().length,
      })
      .returning();

    return NextResponse.json({
      success: true,
      data: newGen[0],
      message: 'Áudio sintetizado com sucesso!',
    });
  } catch (error) {
    console.error('TTS Generation error:', error);
    return NextResponse.json(
      { success: false, error: 'Ocorreu um erro ao processar a síntese de voz.' },
      { status: 500 }
    );
  }
}
