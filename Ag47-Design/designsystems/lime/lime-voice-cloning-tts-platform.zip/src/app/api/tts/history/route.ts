import { NextResponse } from 'next/server';
import { db } from '@/db';
import { generations } from '@/db/schema';
import { desc } from 'drizzle-orm';

export async function GET() {
  try {
    const list = await db.select().from(generations).orderBy(desc(generations.createdAt)).limit(50);
    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error('Error fetching TTS history:', error);
    return NextResponse.json({ success: false, error: 'Erro ao carregar histórico.' }, { status: 500 });
  }
}
