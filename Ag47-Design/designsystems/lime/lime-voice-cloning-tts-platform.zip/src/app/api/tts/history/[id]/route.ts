import { NextResponse } from 'next/server';
import { db } from '@/db';
import { generations } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const genId = parseInt(id, 10);

    if (isNaN(genId)) {
      return NextResponse.json({ success: false, error: 'ID de geração inválido.' }, { status: 400 });
    }

    await db.delete(generations).where(eq(generations.id, genId));
    return NextResponse.json({ success: true, message: 'Item excluído do histórico.' });
  } catch (error) {
    console.error('Error deleting generation history:', error);
    return NextResponse.json({ success: false, error: 'Erro ao excluir do histórico.' }, { status: 500 });
  }
}
